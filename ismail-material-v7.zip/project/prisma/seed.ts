/**
 * Idempotent database seed for the Ismail Material e-commerce platform.
 *
 * Run with:   bun run prisma/seed.ts      (or)   bunx prisma db seed
 *
 * Safe to re-run multiple times: every entity is upserted / replaced
 * using a stable natural key (slug, code, email, key, number).
 *
 * Cloudinary is NOT required — product images use placehold.co URLs.
 */

import { db } from '../src/lib/db'
import { hashPassword } from '../src/lib/password'
import type { Prisma } from '@prisma/client'

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const NOW = new Date()

function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

function placeholder(text: string): string {
  const safe = encodeURIComponent(text)
  return `https://placehold.co/800x800/f1f1f1/1a1a1a?text=${safe}`
}

/** Upsert by slug — used for categories, brands. */
async function upsertBySlug<T extends { slug: string }>(
  model: { upsert: (args: Prisma.AnyUpsertArgs) => Promise<T> },
  data: T,
) {
  const m = model as any
  return m.upsert({
    where: { slug: data.slug },
    update: data,
    create: data,
  })
}

// ---------------------------------------------------------------------------
// 1. ROLES
// ---------------------------------------------------------------------------

const ALL_PERMISSIONS = {
  products: ['read', 'write', 'delete'],
  categories: ['read', 'write', 'delete'],
  brands: ['read', 'write', 'delete'],
  orders: ['read', 'write', 'delete'],
  customers: ['read', 'write', 'delete'],
  reviews: ['read', 'write', 'delete'],
  coupons: ['read', 'write', 'delete'],
  pages: ['read', 'write', 'delete'],
  navigation: ['read', 'write', 'delete'],
  media: ['read', 'write', 'delete'],
  settings: ['read', 'write'],
  featureFlags: ['read', 'write'],
  adminUsers: ['read', 'write', 'delete'],
  roles: ['read', 'write', 'delete'],
  auditLogs: ['read'],
  dashboard: ['read'],
}

const ROLES = [
  {
    name: 'Super Admin',
    slug: 'super-admin',
    description: 'Full access to every module and resource.',
    permissions: ALL_PERMISSIONS,
  },
  {
    name: 'Manager',
    slug: 'manager',
    description: 'Read + write access to catalog and orders.',
    permissions: {
      products: ['read', 'write'],
      categories: ['read', 'write'],
      brands: ['read', 'write'],
      orders: ['read', 'write'],
      customers: ['read', 'write'],
      reviews: ['read', 'write'],
      coupons: ['read', 'write'],
      pages: ['read'],
      navigation: ['read'],
      media: ['read', 'write'],
      settings: ['read'],
      dashboard: ['read'],
    },
  },
  {
    name: 'Viewer',
    slug: 'viewer',
    description: 'Read-only access across the admin dashboard.',
    permissions: {
      products: ['read'],
      categories: ['read'],
      brands: ['read'],
      orders: ['read'],
      customers: ['read'],
      reviews: ['read'],
      coupons: ['read'],
      pages: ['read'],
      navigation: ['read'],
      media: ['read'],
      settings: ['read'],
      dashboard: ['read'],
    },
  },
] as const

// ---------------------------------------------------------------------------
// 2. COUNTRIES (Morocco-first)
// ---------------------------------------------------------------------------

const COUNTRIES = [
  {
    code: 'MA',
    name: 'Maroc',
    nameAr: 'المغرب',
    currencyCode: 'MAD',
    currencySymbol: 'DH',
    phonePrefix: '+212',
    locale: 'fr',
    isEnabled: true,
    isDefault: true,
    sortOrder: 1,
    shippingBase: 30,
    shippingPerKg: 5,
    taxRate: 0,
  },
  {
    code: 'DZ',
    name: 'Algérie',
    nameAr: 'الجزائر',
    currencyCode: 'DZD',
    currencySymbol: 'DA',
    phonePrefix: '+213',
    locale: 'fr',
    isEnabled: false,
    isDefault: false,
    sortOrder: 2,
    shippingBase: 50,
    shippingPerKg: 8,
    taxRate: 0,
  },
  {
    code: 'TN',
    name: 'Tunisie',
    nameAr: 'تونس',
    currencyCode: 'TND',
    currencySymbol: 'DT',
    phonePrefix: '+216',
    locale: 'fr',
    isEnabled: false,
    isDefault: false,
    sortOrder: 3,
    shippingBase: 45,
    shippingPerKg: 7,
    taxRate: 0,
  },
  {
    code: 'LY',
    name: 'Libye',
    nameAr: 'ليبيا',
    currencyCode: 'LYD',
    currencySymbol: 'LD',
    phonePrefix: '+218',
    locale: 'fr',
    isEnabled: false,
    isDefault: false,
    sortOrder: 4,
    shippingBase: 60,
    shippingPerKg: 10,
    taxRate: 0,
  },
] as const

// ---------------------------------------------------------------------------
// 3. CATEGORIES
// ---------------------------------------------------------------------------

const CATEGORIES = [
  {
    slug: 'outillage-electroportatif',
    name: 'Outillage électroportatif',
    nameAr: 'أدوات كهربائية محمولة',
    description: 'Perceuses, visseuses, meuleuses et outils sur batterie ou sur fil.',
    sortOrder: 1,
    isVisible: true,
  },
  {
    slug: 'accessoires',
    name: 'Accessoires',
    nameAr: 'ملحقات',
    description: 'Embouts, forets, lames et consommables pour tous vos outils.',
    sortOrder: 2,
    isVisible: true,
  },
  {
    slug: 'mesure',
    name: 'Mesure et traçage',
    nameAr: 'قياس ورسم',
    description: 'Télémètres laser, niveaux, mètres et outils de précision.',
    sortOrder: 3,
    isVisible: true,
  },
  {
    slug: 'securite',
    name: 'Sécurité',
    nameAr: 'السلامة',
    description: 'EPI, casques, gants et équipements de protection individuelle.',
    sortOrder: 4,
    isVisible: true,
  },
  {
    slug: 'soudure',
    name: 'Soudure',
    nameAr: 'لحام',
    description: 'Postes à souder onduleurs, baguettes et accessoires de soudure.',
    sortOrder: 5,
    isVisible: true,
  },
] as const

// ---------------------------------------------------------------------------
// 4. BRANDS
// ---------------------------------------------------------------------------

const BRANDS = [
  {
    slug: 'ingco',
    name: 'Ingco',
    nameAr: 'إنجكو',
    description: 'Marque d\'outillage électroportatif abordable et fiable.',
    countryOfOrigin: 'CN',
    isVisible: true,
    sortOrder: 1,
  },
  {
    slug: 'total-tools',
    name: 'Total Tools',
    nameAr: 'توتال تولز',
    description: 'Outils professionnels pour chantiers exigeants.',
    countryOfOrigin: 'CN',
    isVisible: true,
    sortOrder: 2,
  },
  {
    slug: 'crown',
    name: 'Crown',
    nameAr: 'كراون',
    description: 'Outils robustes pour le secteur industriel et BTP.',
    countryOfOrigin: 'US',
    isVisible: true,
    sortOrder: 3,
  },
  {
    slug: 'wurth',
    name: 'Würth',
    nameAr: 'فورت',
    description: 'Composants, fixations et outillage de précision allemand.',
    countryOfOrigin: 'DE',
    isVisible: true,
    sortOrder: 4,
  },
] as const

// ---------------------------------------------------------------------------
// 5. PRODUCTS
// ---------------------------------------------------------------------------

type Spec = { key: string; value: string }
type SeedProduct = {
  slug: string
  name: string
  shortDescription: string
  description: string
  specifications: Spec[]
  sku: string
  brandSlug: string
  categorySlug: string
  price: number
  compareAtPrice?: number | null
  stockQuantity: number
  isFeatured?: boolean
  isBestSeller?: boolean
  isNewArrival?: boolean
  weightKg?: number
}

const PRODUCTS: SeedProduct[] = [
  {
    slug: 'visseuse-impact-20v-ingco',
    name: 'Visseuse à impact 20V Ingco',
    shortDescription: 'Visseuse à choc 20V avec 2 batteries 4.0Ah et chargeur rapide.',
    description:
      'La visseuse à impact Ingco 20V délivre un couple de serrage jusqu\'à 320 Nm, idéale pour les travaux lourds de vissage et dévissage. Livrée avec deux batteries lithium 4.0Ah, un chargeur rapide, et un embout de qualité industrielle. Mandrin 1/4" à changement rapide. Éclairage LED intégré pour un travail optimal dans les espaces sombres.',
    specifications: [
      { key: 'Tension', value: '20V' },
      { key: 'Couple max', value: '320 Nm' },
      { key: 'Capacité', value: '1/4"' },
      { key: 'Vitesse à vide', value: '0-2900 tr/min' },
      { key: 'Batterie', value: '2x 4.0Ah Li-ion' },
      { key: 'Poids', value: '1.6 kg' },
    ],
    sku: 'ING-VI-20V-001',
    brandSlug: 'ingco',
    categorySlug: 'outillage-electroportatif',
    price: 899,
    compareAtPrice: 1199,
    stockQuantity: 15,
    isFeatured: true,
    isBestSeller: true,
    weightKg: 2.1,
  },
  {
    slug: 'perceuse-sans-fil-18v-ingco',
    name: 'Perceuse sans fil 18V Ingco',
    shortDescription: 'Perceuse-visseuse 18V avec mandrin 13 mm et 2 batteries.',
    description:
      'Perceuse-visseuse sans fil 18V avec mandrin métallique 13 mm. Couple réglable 25+1 positions, vitesse variable 0-1500 tr/min. Equipée d\'une LED de travail et d\'une poignée antidérapante. Batterie lithium longue durée avec indicateur de charge. Idéale pour le perçage du bois, du métal et le vissage général.',
    specifications: [
      { key: 'Tension', value: '18V' },
      { key: 'Mandrin', value: '13 mm auto' },
      { key: 'Couple max', value: '45 Nm' },
      { key: 'Positions de couple', value: '25+1' },
      { key: 'Vitesse max', value: '1500 tr/min' },
      { key: 'Batterie', value: '2x 2.0Ah Li-ion' },
    ],
    sku: 'ING-PE-18V-002',
    brandSlug: 'ingco',
    categorySlug: 'outillage-electroportatif',
    price: 549,
    compareAtPrice: null,
    stockQuantity: 22,
    isBestSeller: true,
    isNewArrival: true,
    weightKg: 1.8,
  },
  {
    slug: 'meuleuse-115mm-total-tools',
    name: 'Meuleuse 115mm Total Tools',
    shortDescription: 'Meuleuse d\'angle 720W, disque 115 mm, vitesse 12000 tr/min.',
    description:
      'Meuleuse d\'angle 115 mm Total Tools avec moteur 720W offrant une vitesse de rotation de 12000 tr/min. Poignée latérale ajustable pour une meilleure ergonomie. Interrupteur de sécurité anti-démarrage intempestif. Carénage de protection orientable. Idéale pour la coupe et le meulage de l\'acier, de l\'inox et de la maçonnerie.',
    specifications: [
      { key: 'Puissance', value: '720W' },
      { key: 'Disque', value: '115 mm' },
      { key: 'Vitesse', value: '12000 tr/min' },
      { key: 'Filetage', value: 'M14' },
      { key: 'Poids', value: '1.4 kg' },
    ],
    sku: 'TTL-MG-115-003',
    brandSlug: 'total-tools',
    categorySlug: 'outillage-electroportatif',
    price: 299,
    compareAtPrice: 349,
    stockQuantity: 8,
    isFeatured: true,
    weightKg: 1.6,
  },
  {
    slug: 'set-embouts-32p-wurth',
    name: "Set d'embouts 32 pièces Würth",
    shortDescription: 'Coffret 32 embouts PH/PZ/Torx + porte-embouts magnétique.',
    description:
      'Coffret Würth de 32 embouts de précision en acier S2 (dureté 60 HRC). Comprend PH, PZ, Torx, Hex, carré et triple crabes. Porte-embouts magnétique 1/4" à boule de retenue. Boîtier compact et empilable avec indexation claire des embouts. Compatible perceuses-visseuses standard du marché.',
    specifications: [
      { key: 'Matériau', value: 'Acier S2' },
      { key: 'Dureté', value: '60 HRC' },
      { key: 'Nombre d\'embouts', value: '32' },
      { key: 'Porte-embouts', value: '1/4" magnétique' },
      { key: 'Boîtier', value: 'Plastique empilable' },
    ],
    sku: 'WUR-EM-32P-004',
    brandSlug: 'wurth',
    categorySlug: 'accessoires',
    price: 189,
    compareAtPrice: 229,
    stockQuantity: 40,
    isBestSeller: true,
    weightKg: 0.5,
  },
  {
    slug: 'marteau-perforateur-sds-crown',
    name: 'Marteau perforateur SDS Crown',
    shortDescription: 'Perforateur SDS-Plus 850W, 3 modes, mèche 26 mm béton.',
    description:
      'Marteau perforateur Crown SDS-Plus 850W avec 3 modes : perçage, perçage + burinage, burinage. Vitesse 0-1100 tr/min et 4300 frappes/min. Mécanisme anti-vibration pour réduire la fatigue. Mèche béton max 26 mm. Livré avec coffret, 2 mèches, burin ciseau et butée de profondeur. Robuste et adapté aux chantiers BTP intensifs.',
    specifications: [
      { key: 'Puissance', value: '850W' },
      { key: 'Emmanchement', value: 'SDS-Plus' },
      { key: 'Modes', value: '3' },
      { key: 'Cadence de frappe', value: '4300 cps/min' },
      { key: 'Capacité béton', value: '26 mm' },
    ],
    sku: 'CRO-MP-SDS-005',
    brandSlug: 'crown',
    categorySlug: 'outillage-electroportatif',
    price: 1290,
    compareAtPrice: 1490,
    stockQuantity: 4,
    isFeatured: true,
    isNewArrival: true,
    weightKg: 5.8,
  },
  {
    slug: 'telemetre-laser-40m-ingco',
    name: 'Télémètre laser 40m Ingco',
    shortDescription: 'Télémètre laser 40m, précision ±2mm, écran LCD rétroéclairé.',
    description:
      'Télémètre laser Ingco 40m avec précision ±2 mm. Mesures de distance, surface, volume, et soustraction de mesures. Mémoire 99 mesures, niveau à bulle intégré. Écran LCD rétroéclairé 2 lignes. Arrêt automatique après 3 minutes. Étui de transport et batteries inclus.',
    specifications: [
      { key: 'Portée', value: '40 m' },
      { key: 'Précision', value: '±2 mm' },
      { key: 'Mémoire', value: '99 mesures' },
      { key: 'Écran', value: 'LCD rétroéclairé' },
      { key: 'Alimentation', value: '2x AAA' },
    ],
    sku: 'ING-TL-40M-006',
    brandSlug: 'ingco',
    categorySlug: 'mesure',
    price: 449,
    compareAtPrice: null,
    stockQuantity: 12,
    isNewArrival: true,
    weightKg: 0.3,
  },
  {
    slug: 'niveau-laser-rotatif-total-tools',
    name: 'Niveau laser rotatif Total Tools',
    shortDescription: 'Niveau laser rotatif auto, portée 30m, rouge 360°.',
    description:
      'Niveau laser rotatif Total Tools à nivellement automatique, faisceau rouge 360° avec portée 30 m. Vitesse 600 tr/min. Détecteur de laser en option pour travaux en extérieur. Trépied et cible incluse. Indicateur batterie faible. Idéal pour terrassement, fondations, carrelage et faux plafonds.',
    specifications: [
      { key: 'Type', value: 'Rotatif auto-nivelant' },
      { key: 'Portée', value: '30 m' },
      { key: 'Précision', value: '±1 mm/5m' },
      { key: 'Vitesse', value: '600 tr/min' },
      { key: 'Alimentation', value: '4x AA' },
    ],
    sku: 'TTL-NL-ROT-007',
    brandSlug: 'total-tools',
    categorySlug: 'mesure',
    price: 1190,
    compareAtPrice: 1390,
    stockQuantity: 0,
    isFeatured: true,
    weightKg: 1.2,
  },
  {
    slug: 'casque-anti-bruit-wurth',
    name: 'Casque anti-bruit Würth',
    shortDescription: 'Casque antibruit NRR 32 dB, coussins PVC, bandeau rembourré.',
    description:
      'Casque antibruit Würth avec atténuation NRR 32 dB. Coussins en mousse PVC remplis de liquide pour un confort prolongé. Bandeau réglable rembourré. Légèreté 280g. Conforme EN 352-1. Idéal pour chantier, atelier, meulage et tonte. Se plie à plat pour le rangement.',
    specifications: [
      { key: 'Atténuation', value: 'NRR 32 dB' },
      { key: 'Norme', value: 'EN 352-1' },
      { key: 'Poids', value: '280 g' },
      { key: 'Bandeau', value: 'Réglable rembourré' },
    ],
    sku: 'WUR-CB-008',
    brandSlug: 'wurth',
    categorySlug: 'securite',
    price: 145,
    compareAtPrice: null,
    stockQuantity: 30,
    weightKg: 0.4,
  },
  {
    slug: 'gants-mecaniciens-crown',
    name: 'Gants mécaniciens Crown',
    shortDescription: 'Gants nitrile mécaniciens, paume antidérapante, taille L.',
    description:
      'Gants mécaniciens Crown en nylon élasthanne avec enduction nitrile sur la paume et les doigts. Paume antidérapante et résistante à l\'huile. Bonne dextérité pour visserie et manipulation de petites pièces. Lavables en machine. Conditionnement : 1 paire. Taille L.',
    specifications: [
      { key: 'Matière', value: 'Nylon + nitrile' },
      { key: 'Taille', value: 'L' },
      { key: 'Enduction', value: 'Nitrile paume + doigts' },
      { key: 'Lavable', value: 'Machine 30°C' },
    ],
    sku: 'CRO-GM-009',
    brandSlug: 'crown',
    categorySlug: 'securite',
    price: 89,
    compareAtPrice: 109,
    stockQuantity: 50,
    isBestSeller: true,
    weightKg: 0.15,
  },
  {
    slug: 'poste-souder-inverter-200a-total-tools',
    name: 'Poste à souder inverter 200A Total Tools',
    shortDescription: 'Inverter MMA 200A IGBT, électrodes 1.6-4.0mm, hot start.',
    description:
      'Poste à souder inverter MMA 200A Total Tools à technologie IGBT. Courant réglable 20-200A. Hot start et arc force intégrés. Fonction anti-adhérence pour un démarrage facile. Ventilation forcée pour usage intensif. Électrodes compatibles rutile, basique et inox (1.6 à 4.0 mm). Livré avec pince de masse, pince porte-électrode, câbles et brosse.',
    specifications: [
      { key: 'Type', value: 'Inverter MMA IGBT' },
      { key: 'Courant', value: '20-200A' },
      { key: 'Électrodes', value: '1.6 - 4.0 mm' },
      { key: 'Fonctions', value: 'Hot start / Arc force / Anti-stick' },
      { key: 'Alimentation', value: '230V' },
    ],
    sku: 'TTL-PS-200A-010',
    brandSlug: 'total-tools',
    categorySlug: 'soudure',
    price: 1890,
    compareAtPrice: 2190,
    stockQuantity: 6,
    isFeatured: true,
    isNewArrival: true,
    weightKg: 4.5,
  },
]

// ---------------------------------------------------------------------------
// 6. SITE SETTINGS
// ---------------------------------------------------------------------------

const SITE_SETTINGS: Array<{
  key: string
  value: string
  type?: string
  group?: string
  isPublic?: boolean
}> = [
  { key: 'site_name', value: 'Ismail Material', type: 'text', group: 'general', isPublic: true },
  { key: 'site_tagline', value: 'Outillage Électroportatif Pro au Maroc', type: 'text', group: 'general', isPublic: true },
  {
    key: 'site_description',
    value: "Boutique marocaine d'outillage électroportatif et équipement professionnel — perceuses, visseuses, meuleuses, niveaux laser et plus. Marques fiables (INGCO, Total Tools, Crown, Würth), paiement à la livraison, expédition 24–72h partout au Maroc.",
    type: 'text',
    group: 'general',
    isPublic: true,
  },
  { key: 'support_phone', value: '+212 522 000 000', type: 'text', group: 'general', isPublic: true },
  { key: 'whatsapp', value: '+212661234567', type: 'text', group: 'general', isPublic: true },
  { key: 'support_email', value: 'contact@ismailmaterial.ma', type: 'text', group: 'general', isPublic: true },
  {
    key: 'address',
    value: '12 Rue des Industriels, Zone Sidi Ghanem, Marrakech 40000, Maroc',
    type: 'text',
    group: 'general',
    isPublic: true,
  },
  {
    key: 'announcement_bar',
    value: 'Livraison gratuite à partir de 500 DH • Paiement à la livraison partout au Maroc',
    type: 'text',
    group: 'homepage',
    isPublic: true,
  },
  { key: 'default_country', value: 'MA', type: 'text', group: 'general', isPublic: true },
  { key: 'currency_code', value: 'MAD', type: 'text', group: 'general', isPublic: true },
  { key: 'maintenance_mode', value: 'false', type: 'boolean', group: 'general', isPublic: true },
  { key: 'primary_color', value: '#0f172a', type: 'text', group: 'general', isPublic: true },
  { key: 'accent_color', value: '#ea580c', type: 'text', group: 'general', isPublic: true },
  { key: 'show_announcement', value: 'true', type: 'boolean', group: 'homepage', isPublic: true },
]

// ---------------------------------------------------------------------------
// 7. FEATURE FLAGS
// ---------------------------------------------------------------------------

const FEATURE_FLAGS: Array<{
  key: string
  label: string
  description?: string
  isEnabled: boolean
}> = [
  { key: 'reviews', label: 'Avis produits', description: 'Permet aux clients de noter et commenter les produits.', isEnabled: true },
  { key: 'coupons', label: 'Codes promo', description: 'Active la réduction par code promo au panier.', isEnabled: true },
  { key: 'wishlist', label: 'Liste de souhaits', description: 'Permet aux visiteurs de sauvegarder des produits favoris.', isEnabled: false },
  { key: 'online_payments', label: 'Paiement en ligne', description: 'Active les paiements par carte bancaire en ligne.', isEnabled: false },
  { key: 'cod', label: 'Paiement à la livraison', description: 'Active le paiement en espèces à la réception.', isEnabled: true },
  { key: 'multi_country', label: 'Multi-pays', description: 'Active la vente vers plusieurs pays (MA, DZ, TN, LY).', isEnabled: true },
  { key: 'maintenance_mode', label: 'Mode maintenance', description: 'Désactive la boutique publique pour travaux.', isEnabled: false },
  { key: 'ai_assistant', label: 'Assistant IA', description: 'Assistant de vente IA côté vitrine.', isEnabled: false },
]

// ---------------------------------------------------------------------------
// SEED MAIN
// ---------------------------------------------------------------------------

async function main() {
  console.log('\n🌱  Ismail Material — DB seed starting...\n')

  // 1. Roles ----------------------------------------------------------------
  console.log('→ Seeding roles...')
  const roleBySlug: Record<string, { id: string }> = {}
  for (const role of ROLES) {
    const created = await db.role.upsert({
      where: { slug: role.slug },
      update: { name: role.name, description: role.description, permissions: role.permissions as Prisma.InputJsonValue },
      create: {
        name: role.name,
        slug: role.slug,
        description: role.description,
        permissions: role.permissions as Prisma.InputJsonValue,
      },
    })
    roleBySlug[role.slug] = { id: created.id }
  }
  console.log(`   ✓ ${ROLES.length} roles (super-admin, manager, viewer)`)

  // 2. Admin user -----------------------------------------------------------
  console.log('→ Seeding bootstrap admin user...')
  const adminEmail = 'admin@ismailmaterial.ma'
  const passwordHash = await hashPassword('admin12345')
  const superAdminRole = roleBySlug['super-admin']
  await db.adminUser.upsert({
    where: { email: adminEmail },
    update: { passwordHash, fullName: 'Ismail Material Super Admin', roleId: superAdminRole.id, status: 'ACTIVE' },
    create: {
      email: adminEmail,
      passwordHash,
      fullName: 'Ismail Material Super Admin',
      roleId: superAdminRole.id,
      status: 'ACTIVE',
    },
  })
  console.log(`   ✓ admin user "${adminEmail}" (password: admin12345) — role: super-admin`)

  // 3. Countries ------------------------------------------------------------
  console.log('→ Seeding countries...')
  const countryByCode: Record<string, { id: string }> = {}
  for (const c of COUNTRIES) {
    const created = await db.country.upsert({
      where: { code: c.code },
      update: {
        name: c.name,
        nameAr: c.nameAr,
        currencyCode: c.currencyCode,
        currencySymbol: c.currencySymbol,
        phonePrefix: c.phonePrefix,
        locale: c.locale,
        isEnabled: c.isEnabled,
        isDefault: c.isDefault,
        sortOrder: c.sortOrder,
        shippingBase: c.shippingBase,
        shippingPerKg: c.shippingPerKg,
        taxRate: c.taxRate,
      },
      create: { ...c },
    })
    countryByCode[c.code] = { id: created.id }
  }
  console.log(`   ✓ ${COUNTRIES.length} countries (MA default, DZ/TN/LY disabled)`)

  // 4. Categories ------------------------------------------------------------
  console.log('→ Seeding categories...')
  const categoryBySlug: Record<string, { id: string }> = {}
  for (const cat of CATEGORIES) {
    const created = await upsertBySlug(db.category, cat as unknown as { slug: string })
    categoryBySlug[cat.slug] = { id: created.id }
  }
  console.log(`   ✓ ${CATEGORIES.length} categories`)

  // 5. Brands ----------------------------------------------------------------
  console.log('→ Seeding brands...')
  const brandBySlug: Record<string, { id: string }> = {}
  for (const b of BRANDS) {
    const created = await upsertBySlug(db.brand, b as unknown as { slug: string })
    brandBySlug[b.slug] = { id: created.id }
  }
  console.log(`   ✓ ${BRANDS.length} brands`)

  // 6. Products + images ----------------------------------------------------
  console.log('→ Seeding products + placeholder images...')
  const productBySlug: Record<string, { id: string; name: string; price: number; sku: string; imageUrl: string | null }> = {}
  for (const p of PRODUCTS) {
    const categoryId = categoryBySlug[p.categorySlug].id
    const brandId = brandBySlug[p.brandSlug].id
    const specs = p.specifications as unknown as Prisma.InputJsonValue

    const product = await db.product.upsert({
      where: { slug: p.slug },
      update: {
        name: p.name,
        shortDescription: p.shortDescription,
        description: p.description,
        specifications: specs,
        sku: p.sku,
        brandId,
        categoryId,
        status: 'PUBLISHED',
        price: p.price,
        compareAtPrice: p.compareAtPrice ?? null,
        currencyCode: 'MAD',
        stockQuantity: p.stockQuantity,
        lowStockThreshold: 5,
        trackInventory: true,
        allowBackorder: false,
        isFeatured: p.isFeatured ?? false,
        isBestSeller: p.isBestSeller ?? false,
        isNewArrival: p.isNewArrival ?? false,
        weightKg: p.weightKg ?? null,
        publishedAt: NOW,
      },
      create: {
        slug: p.slug,
        name: p.name,
        shortDescription: p.shortDescription,
        description: p.description,
        specifications: specs,
        sku: p.sku,
        brandId,
        categoryId,
        status: 'PUBLISHED',
        price: p.price,
        compareAtPrice: p.compareAtPrice ?? null,
        currencyCode: 'MAD',
        stockQuantity: p.stockQuantity,
        lowStockThreshold: 5,
        trackInventory: true,
        allowBackorder: false,
        isFeatured: p.isFeatured ?? false,
        isBestSeller: p.isBestSeller ?? false,
        isNewArrival: p.isNewArrival ?? false,
        weightKg: p.weightKg ?? null,
        publishedAt: NOW,
      },
    })

    // Idempotency for images: wipe placeholder images for this product, recreate.
    await db.productImage.deleteMany({
      where: { productId: product.id, publicId: { startsWith: 'placeholder/' } },
    })

    const publicId = `placeholder/${p.slug}`
    const url = placeholder(p.name)
    await db.productImage.create({
      data: {
        productId: product.id,
        publicId,
        secureUrl: url,
        url,
        width: 800,
        height: 800,
        format: 'png',
        altText: p.name,
        sortOrder: 0,
        isMain: true,
      },
    })

    productBySlug[p.slug] = {
      id: product.id,
      name: product.name,
      price: Number(product.price),
      sku: product.sku,
      imageUrl: url,
    }
  }
  console.log(`   ✓ ${PRODUCTS.length} products with 1 placeholder image each`)

  // 7. Site settings --------------------------------------------------------
  console.log('→ Seeding site settings...')
  for (const s of SITE_SETTINGS) {
    await db.siteSetting.upsert({
      where: { key: s.key },
      update: {
        value: s.value,
        type: s.type ?? 'text',
        group: s.group ?? 'general',
        isPublic: s.isPublic ?? true,
      },
      create: {
        key: s.key,
        value: s.value,
        type: s.type ?? 'text',
        group: s.group ?? 'general',
        isPublic: s.isPublic ?? true,
      },
    })
  }
  console.log(`   ✓ ${SITE_SETTINGS.length} site settings`)

  // 8. Feature flags --------------------------------------------------------
  console.log('→ Seeding feature flags...')
  for (const f of FEATURE_FLAGS) {
    await db.featureFlag.upsert({
      where: { key: f.key },
      update: {
        label: f.label,
        description: f.description ?? null,
        isEnabled: f.isEnabled,
      },
      create: {
        key: f.key,
        label: f.label,
        description: f.description ?? null,
        isEnabled: f.isEnabled,
      },
    })
  }
  console.log(`   ✓ ${FEATURE_FLAGS.length} feature flags`)

  // 9. Sample order ---------------------------------------------------------
  console.log('→ Seeding sample order (COD)...')
  const orderNumber = 'ORD-2025-00001'
  const morocco = countryByCode['MA']

  // 2 items: 1x visseuse (899) + 2x gants mécaniciens (89 each)
  const item1Product = productBySlug['visseuse-impact-20v-ingco']
  const item2Product = productBySlug['gants-mecaniciens-crown']

  const item1Qty = 1
  const item2Qty = 2
  const item1Line = item1Qty * item1Product.price
  const item2Line = item2Qty * item2Product.price
  const subtotal = item1Line + item2Line
  const shippingCost = 30 // Morocco shippingBase
  const total = subtotal + shippingCost

  // Idempotency: delete existing order with this number (cascades items+history),
  // then create a fresh one.
  await db.order.deleteMany({ where: { number: orderNumber } }).catch(() => {})

  await db.order.create({
    data: {
      number: orderNumber,
      customerFullName: 'Youssef Amrani',
      customerPhone: '+212661234567',
      customerEmail: null,
      countryId: morocco.id,
      shippingCity: 'Casablanca',
      shippingAddress: '12 Rue des Orangers, Maârif',
      shippingPostalCode: '20000',
      notes: 'Livrer en soirée après 18h si possible.',
      subtotal,
      shippingCost,
      discountTotal: 0,
      taxTotal: 0,
      total,
      currencyCode: 'MAD',
      status: 'NEW',
      paymentMethod: 'COD',
      paymentStatus: 'UNPAID',
      placedAt: NOW,
      items: {
        create: [
          {
            productId: item1Product.id,
            productName: item1Product.name,
            productSku: item1Product.sku,
            productImage: item1Product.imageUrl,
            unitPrice: item1Product.price,
            quantity: item1Qty,
            lineTotal: item1Line,
          },
          {
            productId: item2Product.id,
            productName: item2Product.name,
            productSku: item2Product.sku,
            productImage: item2Product.imageUrl,
            unitPrice: item2Product.price,
            quantity: item2Qty,
            lineTotal: item2Line,
          },
        ],
      },
      statusHistory: {
        create: {
          status: 'NEW',
          note: 'Commande passée depuis la vitrine (seed).',
        },
      },
    },
  })
  console.log(`   ✓ order ${orderNumber} — Youssef Amrani — subtotal ${subtotal} DH + ${shippingCost} DH shipping = ${total} DH`)

  console.log('\n✅  Seed completed successfully.\n')
}

main()
  .catch((err) => {
    console.error('\n❌  Seed failed:', err)
    process.exitCode = 1
  })
  .finally(async () => {
    await db.$disconnect()
  })
