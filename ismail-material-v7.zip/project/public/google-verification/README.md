# Google Search Console — Static HTML Verification Files (OPTIONAL)

This folder is for the **static HTML file** verification method (Google's
recommended approach when you don't want to use the dynamic route).

## How it works

Two methods are supported. Pick **one** — both produce a working
verification on `/google*.html`:

1. **Dynamic (default, recommended)** — managed from the admin panel
   at `/admin/seo → الدومين والنشر → طريقة 2: HTML File Verification`.
   You paste the file content, the app serves it via `/api/gsc-verify`
   (rewritten from `/google*.html` by `src/proxy.ts`). Super-admin only.
   No file in this folder is needed.

2. **Static (this folder)** — drop the actual `googleXXXXXXXX.html` file
   that Google gives you in this folder. Next.js serves it directly from
   `/googleXXXXXXXX.html`. This is the most portable option because it
   works even if the Next.js serverless function is cold-starting or
   if you migrate to a different host later.

## Static method — step-by-step

1. In Google Search Console, add a property of type "URL prefix" with
   your production URL (e.g. `https://mon-magasin.ma`).
2. Choose the "HTML file" verification method.
3. Download the file Google gives you — it has a name like
   `google1234567890abcdef.html`.
4. Drop that file into THIS folder (`public/google-verification/`).
   The path inside `public/` matters — the file MUST be at
   `public/google-verification/googleXXXXXXXX.html` so that the
   final public URL is `/google-verification/googleXXXXXXXX.html`.
5. **Important**: tell Google the correct URL when you click "Verify" —
   use `https://YOUR-DOMAIN/google-verification/googleXXXXXXXX.html`,
   NOT `https://YOUR-DOMAIN/googleXXXXXXXX.html`. The latter is served
   dynamically by the Next.js route (method 1), so do NOT use both
   methods at the same time for the same filename.
6. Redeploy on Netlify. After deploy, the file is reachable at the
   URL above. Click "Verify" in Google Search Console.

## Conflict between methods

If both methods are configured for the same filename:

- The **static file** wins (Next.js serves static files from `public/`
  before invoking the dynamic route handler in `src/proxy.ts`).
- The dynamic route is bypassed for that specific filename.

This is the safest fallback — if Google ever fails to verify via the
dynamic route, dropping the file here will work.

## Security

- Files in `public/` are **publicly accessible**. Only put Google
  verification files here — never secrets, credentials, or customer
  data.
- The file content is plain text starting with
  `google-site-verification: google…`. It contains no secrets.
- The folder is gitignored from any other static-asset pipeline; only
  files matching `google*.html` should be placed here.

## Empty folder

This folder ships empty (only this README). The `.gitkeep` ensures the
folder exists in source control. Add your `google*.html` file here
when you're ready to verify.
