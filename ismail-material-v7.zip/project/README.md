# Ismail Material — Production-Ready E-Commerce Platform

A modern, mobile-first, SEO-friendly e-commerce platform built with **Next.js 16 + TypeScript + PostgreSQL (Neon) + Cloudinary**, designed to be **deployable to Netlify** and **extensible to Android/iOS** via a clean REST API.

> Morocco-first (COD, MAD, +212) but multi-country / multi-currency ready from day one.

---

## ✨ Highlights

- **Storefront** — homepage with hero, categories, featured products, best-sellers, new arrivals, promo banner, benefits, FAQ; product detail page with gallery, breadcrumbs, structured data, related products, reviews.
- **Cart** — persisted client cart (Zustand), drawer + full cart page, server-side price & stock re-validation at checkout.
- **Checkout** — Cash On Delivery, **no account required**, order creation, customer/address snapshot, inventory decrement, success confirmation page.
- **Admin Dashboard** — protected with secure session cookies. Dashboard KPIs, product CRUD with multi-image upload, order management with status timeline, settings (site, SEO, social, countries, feature flags), categories/brands/countries/audit-logs.
- **Secret admin access** — click the logo 20× to reveal the login page (obfuscation only — real security is the authentication).
- **SEO** — dynamic sitemap (`/sitemap.xml`) with **automatic Sitemap Index when over 50K URLs**, dynamic `robots.txt`, per-page metadata, JSON-LD (Organization, WebSite, Product, BreadcrumbList, FAQPage), clean slug URLs.
- **Production Domain (Single Source of Truth)** — every absolute URL (sitemap, robots, OG, canonical, structured data) reads from one centralized function `getProductionDomain()` with documented priority + validation.
- **Google Search Console** — supports both HTML meta tag verification and HTML file verification (dynamic via `/api/gsc-verify` OR static via `public/google-verification/`).
- **Architecture** — clear separation: `lib/` (db, auth, cloudinary, utils) · `services/` (business logic) · `app/api/` (REST, mobile-ready) · `app/(storefront)` and `app/admin` UI layers.
- **Security** — scrypt password hashing, HttpOnly Secure SameSite cookies, brute-force lockout, server-side price recompute, input validation (zod), audit logs, RBAC-ready roles, HTML sanitization, magic-byte image verification, SSRF protection, open-redirect protection, redirect loop detection, rate limiting, security headers.
- **Multi-country / multi-currency** — `countries` table drives currency, phone prefix, shipping, tax.
- **Feature flags** — reviews, coupons, wishlist, online payments, COD, multi-country, maintenance mode, AI assistant.

---

## 🧱 Tech Stack

| Layer | Tech |
|---|---|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Database | PostgreSQL via **Neon** (Prisma ORM) |
| Images | **Cloudinary** (signed server-side upload; graceful fallback when not configured) |
| Auth | Custom session-cookie auth (scrypt hashing, no third-party dep) |
| State | Zustand (cart) |
| Validation | Zod |
| Icons | lucide-react |
| Notifications | sonner |
| Charts | recharts |

---

## 🚀 Quick Start (Local)

```bash
# 1. Install deps
bun install

# 2. Configure environment
cp .env.example .env
#   → fill DATABASE_URL (Neon), AUTH_SECRET, Cloudinary, NEXT_PUBLIC_SITE_URL

# 3. Push schema to your Neon database
bunx prisma db push --accept-data-loss

# 4. Seed initial data (admin user, countries, categories, sample products)
bun run db:seed
#   → creates admin: admin@ismailmaterial.ma / admin12345  (CHANGE IN PRODUCTION)

# 5. Start dev server
bun run dev
#   → http://localhost:3000
```

**Admin access:** click the logo 20× → `/admin/login` → `admin@ismailmaterial.ma` / `admin12345`.

> ⚠️ **Rotate the admin password before production.** Create a new admin from the dashboard, or update the seed script, or change the password via the settings later.

---

## 🔐 Environment Variables

Copy `.env.example` to `.env` and fill in real values. **Never commit `.env`.**

| Variable | Scope | Purpose |
|---|---|---|
| `DATABASE_URL` | server | Neon PostgreSQL connection string (pooler) |
| `DIRECT_DATABASE_URL` | server | (optional) direct connection for migrations |
| `AUTH_SECRET` | server | 32+ random chars to sign session cookies (`openssl rand -base64 48`) |
| `CLOUDINARY_CLOUD_NAME` | server | Cloudinary cloud name |
| `CLOUDINARY_API_KEY` | server | Cloudinary API key |
| `CLOUDINARY_API_SECRET` | server | **NEVER expose to the browser** |
| `NEXT_PUBLIC_SITE_URL` | public | Canonical production URL (no trailing slash). Override-able from the admin SEO panel (super-admin only). |
| `NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME` | public | So the browser can build image URLs |
| `ADMIN_LOGO_CLICKS` | server | Number of logo clicks to reveal admin login (default 20) |

---

## 🗄️ Database Schema

The full schema lives in `prisma/schema.prisma`. Core tables:

- **Auth** — `roles`, `admin_users`, `admin_sessions`
- **Customers** — `customers`, `customer_addresses`
- **Geo** — `countries` (multi-country + currency + shipping + tax)
- **Catalog** — `categories`, `brands`, `products`, `product_images`, `product_variants`
- **Orders** — `orders`, `order_items`, `order_status_history`
- **Engagement** — `reviews`, `coupons`
- **CMS** — `pages`, `navigation_items`, `media_assets`
- **Config** — `site_settings`, `feature_flags`, `audit_logs`, `redirects`

Indexed on: `slug`, `sku`, `email`, `order.status`, `product.status`, `category`, `created_at`.

**Migrations:** use `bunx prisma db push` (dev) or `bunx prisma migrate deploy` (production). Schema is idempotent-friendly via the seed script.

---

## 🌐 REST API (mobile-app ready)

Every storefront and admin action has a stable REST endpoint so a future Android/iOS app can consume the same API:

```
# Public
GET    /api/products?filter=featured|best|new&q=
GET    /api/products/[slug]
GET    /api/categories
GET    /api/brands
GET    /api/countries
GET    /api/search?q=
POST   /api/orders              # COD checkout (validates price server-side)
POST   /api/cart/validate       # recompute cart from DB

# Admin auth
POST   /api/admin/auth/login    # sets HttpOnly cookie
POST   /api/admin/auth/logout
GET    /api/admin/auth/session

# Admin (cookie required)
GET    /api/admin/dashboard
GET    /api/admin/products      POST   (create)
GET    /api/admin/products/[id] PUT    PATCH   DELETE  (archive)
GET    /api/admin/orders        GET
GET    /api/admin/orders/[id]   PATCH  (status change)
GET    /api/admin/settings      PUT    (super-admin for site_url / GSC)
GET    /api/admin/categories    POST
GET    /api/admin/brands        POST
GET    /api/admin/countries     POST   PATCH
GET    /api/admin/audit-logs
POST   /api/admin/upload        # multipart, Cloudinary signed
POST   /api/admin/seo/revalidate  # force-refresh sitemap/robots/catalog cache
GET    /api/admin/seo/sitemap-status  # see what will be in the sitemap
```

All admin endpoints require a valid `adm_session` cookie (HttpOnly, Secure in prod, SameSite=Lax, 7-day TTL, brute-force lockout after 5 failed attempts).

---

## 🖼️ Cloudinary

- Server-side signed upload only — **`CLOUDINARY_API_SECRET` never ships to the browser.**
- The `media_assets` table stores `public_id`, `secure_url`, `width`, `height`, `format`, `alt_text`, `tags`.
- Product images attach via `product_images` (with `is_main`, `sort_order`).
- **Graceful fallback:** if Cloudinary env vars are missing, the admin upload still works (stores a placeholder URL) so you can develop/preview without Cloudinary configured.

---

## 🌍 Multi-Country & Multi-Currency

The default country is **Morocco** (MAD, +212, COD). Algeria, Tunisia, Libya are seeded but **disabled**. From the admin → Settings → Pays tab you can:

- Enable/disable a country (disabled → checkout rejects orders from it)
- Set default country
- Configure currency, phone prefix, shipping base, tax rate

---

## 📦 Netlify Deployment — Full Guide

### Method A: Deploy from the ZIP (drag-and-drop)

1. **Unzip the project ZIP** to a clean folder on your machine.
   ```bash
   unzip frontend-final.zip -d ismailmaterial
   cd ismailmaterial
   ```
   The ZIP contains the **complete source code** (no `node_modules`, no `.env`, no `.next`).

2. **Verify structure** — you should see `package.json`, `bun.lock`, `prisma/`, `src/`, `public/`, `netlify.toml`, `.env.example`, `README.md`.

3. **Set up your Neon database** (if you haven't already):
   - Go to https://neon.tech → create a project.
   - Copy the pooled connection string (`DATABASE_URL`) — you'll need it in step 5.

4. **Set up Cloudinary** (if you haven't already):
   - Go to https://cloudinary.com → create an account.
   - From the dashboard, copy `Cloud Name`, `API Key`, `API Secret`.

5. **Push schema to Neon + seed** (run locally against your production Neon):
   ```bash
   bun install                                    # or npm install
   bunx prisma db push --accept-data-loss         # creates all tables
   bun run db:seed                                # creates admin + sample data
   ```
   > The seed creates admin: `admin@ismailmaterial.ma` / `admin12345`. Change this immediately after first login.

6. **Deploy to Netlify**:
   - Go to https://app.netlify.com → "Add a new site" → "Deploy manually" (drag-and-drop).
   - Drag-and-drop the **entire unzipped folder** (the one containing `package.json`).
   - Netlify auto-detects Next.js, installs dependencies, and runs `bun run build`.
   - Wait for the build to complete (~2-5 min).

7. **Configure environment variables on Netlify**:
   - Site settings → Environment variables → add ALL keys from `.env.example`:
     ```
     DATABASE_URL=postgresql://...         (your Neon pooled string)
     AUTH_SECRET=...                       (32+ random chars)
     CLOUDINARY_CLOUD_NAME=...
     CLOUDINARY_API_KEY=...
     CLOUDINARY_API_SECRET=...
     NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=...
     NEXT_PUBLIC_SITE_URL=https://YOUR-NETLIFY-DOMAIN.netlify.app
     ```
   - Save → Trigger a new deploy (Deploys → "Trigger deploy" → "Deploy site").

8. **Set your real production domain**:
   - Once your DNS + Netlify domain is set up (Netlify → Domain settings → Add custom domain),
   - Log in to `/admin` as super-admin → **SEO والروابط → الدومين والنشر**.
   - Set `site_url` to `https://YOUR-PRODUCTION-DOMAIN.com` → Save → "تحديث Sitemap فوراً".
   - This is the **Single Source of Truth** — all sitemap URLs, OG tags, canonical, and structured data will use this domain.

### Method B: Deploy from Git (recommended for ongoing updates)

1. Push the unzipped project to a GitHub repo.
2. In Netlify: "Add a new site" → "Import an existing project" → pick the GitHub repo.
3. Build command is auto-detected (`bun run build`). Publish directory is `.next`.
4. Add the same environment variables as in step 7 above.
5. Every push to `main` triggers a new deploy automatically.

---

## 🌐 Production Domain (Single Source of Truth)

All absolute URLs in the project (sitemap, robots.txt, OG tags, canonical, structured data) come from **one place**: the `getProductionDomain()` helper in `src/services/settings.ts`.

### Priority order (highest → lowest)

1. **DB value** — `site_settings.site_url` (super-admin only, editable at `/admin/seo` → "الدومين والنشر" tab)
2. **Env var** — `NEXT_PUBLIC_SITE_URL`
3. **Dev fallback** — `http://localhost:3000` (only when `NODE_ENV !== 'production'`)

When none is set/valid in production, `getProductionDomain()` returns `null` and **all SEO-critical paths skip the URL entirely** (sitemap returns empty, robots.txt omits the `Sitemap:` directive, structured data is omitted). We **never** fabricate a domain — and we **never** use `Host` or `X-Forwarded-Host` headers from requests (those would leak Netlify preview URLs into the production sitemap).

### Validation rules

The domain is validated before being saved:
- Must be `https://` in production (`http://` only for localhost)
- No path, no query string, no fragment, no credentials
- No raw IP addresses in production (must be a hostname)
- Netlify preview deployments use the env var (typically set to the production URL), so they DON'T pollute the sitemap

### Setting it in the admin

1. Log in to `/admin` as a super-admin (the seed creates one).
2. Navigate to **SEO والروابط → الدومين والنشر**.
3. Enter your production domain (e.g. `https://mon-magasin.ma`).
4. Click "حفظ الدومين الرسمي".
5. Click "تحديث Sitemap فوراً" to force-refresh the sitemap and robots.txt caches.
6. Verify by visiting `/sitemap.xml` and `/robots.txt` — both should now contain your production domain.

### Difference between DB domain and Netlify-bound domain

Changing the domain in the admin panel **does NOT**:
- Update DNS records at your registrar
- Provision or update SSL certificates
- Update the Netlify site's `production` deploy URL or domain aliases

Those must be configured at your DNS provider AND in Netlify's "Domain settings". The DB setting only tells the application code what URL to use when generating absolute links for SEO purposes. Once DNS + Netlify point to your domain, the DB setting ensures the sitemap uses the correct URL.

---

## 🗺️ Sitemap (`/sitemap.xml`)

- **Dynamic** — generated from the live DB on each request, cached for 1 hour via `unstable_cache`.
- **Production Domain only** — when the domain is not set/valid, the sitemap is **empty** (no fabricated URLs).
- **Includes** — static routes (/, /produits, /categories, /contact, /aide), published products (status = `PUBLISHED`, `noindex = false`), visible categories / brands, visible CMS pages.
- **Excludes** — `/admin/*`, `/api/*`, `/cart`, `/checkout`, `/confirmation`, `/recherche`, draft / archived products, noindex products, hidden categories / brands / pages.
- **De-duplicated** — by absolute URL string.
- **`lastmod`** — uses the actual `updatedAt` (or `publishedAt` if available) from the DB — never a fabricated timestamp.
- **Multi-file + Sitemap Index** — when the URL count exceeds Google's 50K limit, Next.js automatically splits the sitemap into chunks and serves a sitemap index at `/sitemap.xml`. The public URL stays the same.
- **Cache invalidation** — `revalidateTag('sitemap')` and `revalidateTag('catalog')` are called by:
  - `/api/admin/seo/revalidate` (manual button)
  - Product / category / brand / page CRUD admin endpoints

---

## 🤖 robots.txt (`/robots.txt`)

- **Dynamic** — `src/app/robots.ts`, generated on each request, cached for 60 seconds.
- **Sitemap directive** — points to `${PRODUCTION_DOMAIN}/sitemap.xml` automatically. When the domain changes, the directive updates within ~60 seconds.
- **Host directive** — same as the production domain.
- **Allow rules** — `/` (everything not explicitly blocked).
- **Disallow rules** — `/admin`, `/api`, `/cart`, `/checkout`, `/confirmation`, `/recherche`, search-query URLs (`/*?*q=`), paginated listings (`/*?*page=`) to avoid duplicate content.
- **Special user-agents** — explicit `Googlebot` and `Googlebot-Image` rules; CSS / JS / images are allowed everywhere.

---

## 🎨 Site Identity (Single Source of Truth)

All identity fields are centralized in the `getBranding()` helper in `src/services/branding.ts`:

| Field | Setting key in DB | Used by |
|---|---|---|
| Store name | `site_name` | Header, footer, title template, OG, structured data |
| Tagline | `site_tagline` | Homepage hero, OG description fallback |
| Description | `site_description` | Meta description default, structured data |
| Logo (main) | `site_logo_url` | Header, footer, OG image fallback |
| Logo (light bg) | `logo_light_url` | Header on light theme |
| Logo (dark bg) | `logo_dark_url` | Header on dark theme |
| Logo (mobile) | `logo_mobile_url` | Mobile header |
| Favicon | `favicon_url` | Browser tab, app icon |
| Primary color | `primary_color` | Theme accent |
| Accent color | `accent_color` | Theme accent |
| Support phone | `support_phone` | Header announcement, footer, structured data |
| WhatsApp | `whatsapp` | Header announcement |
| Support email | `support_email` | Footer, structured data |
| Address | `address` | Footer, structured data |
| Working hours | `working_hours` | Contact page |
| Facebook / Instagram / TikTok / YouTube | `social_facebook`, `social_instagram`, `social_tiktok`, `social_youtube` | Footer |
| OG default image | `og_default_image` | Open Graph fallback |
| OG default title | `og_default_title` | Open Graph fallback |
| SEO title | `seo_title` | Meta title default |
| SEO description | `seo_description` | Meta description default |
| GSC verification (meta) | `gsc_verification_token` | `<meta name="google-site-verification">` in `<head>` |
| GSC verification (file) | `gsc_verification_file_content` | Served dynamically at `/google*.html` via `/api/gsc-verify` |

### Priority rules

1. **Page-specific SEO** > product-specific SEO > branding defaults > `src/config/site.ts` code defaults.
2. The DB value is always preferred over the code default. Empty DB → falls back to code default (except for `support_phone` and `whatsapp`, which return empty string and the UI hides the element).

### Cache & revalidation

- `getBranding()` is wrapped in `unstable_cache` (60s revalidate, tagged `'settings'`).
- Every settings PUT calls `revalidateTag('settings')` → changes propagate within ~60 seconds.
- The admin "تحديث Sitemap فوراً" button also invalidates `'settings'` so branding changes show up instantly.

---

## 🌐 Browser Tab — Title, Favicon, App Icons

Handled by `generateMetadata()` in `src/app/layout.tsx`:

- **Title template** — `%s | ${siteName}` — so `meta title` becomes `Product Name | Store Name`.
- **Default title** — `${siteName} — ${tagline}` for the homepage.
- **Favicon** — `favicon_url` from branding if set, else falls back to `/logo.svg`.
- **Apple touch icon** — same as favicon.
- **Shortcut icon** — same as favicon.
- **Manifest** — none in this version (PWA-ready for future).

### File format support

- **PNG, ICO, SVG, WebP** — all supported via the `<link rel="icon">` tag.
- **SVG safety** — the admin upload route validates magic bytes; SVG files are stored as-is on Cloudinary (which serves them with `Content-Type: image/svg+xml`). For maximum safety when using SVG favicons, ensure the SVG does not contain `<script>` tags (the project's default `/public/logo.svg` is clean).
- **Recommended sizes** — for the best cross-browser experience, upload a 512×512 PNG to Cloudinary and use it as the `favicon_url`. Browsers will downscale automatically. ICO format (multi-resolution) is also supported for legacy browsers.

### Cache busting

- Browsers cache favicons aggressively. To force a refresh:
  - Change `favicon_url` in the admin → "الهوية البصرية".
  - The URL changes (Cloudinary `public_id` includes a version hash), so the browser fetches the new icon.
  - On the storefront, the `<link rel="icon">` `href` changes too → no stale cache.

---

## 🔍 Google Search Console Verification

Two methods are supported. Pick **one** — both are configured in `/admin/seo → الدومين والنشر`:

### Method 1: HTML Meta Tag (recommended)

1. In Google Search Console, add a property of type "URL prefix" with your production URL.
2. Choose the "HTML tag" verification method.
3. Google gives you a tag like `<meta name="google-site-verification" content="google1234567890abcdef.html" />`.
4. Copy just the `content` value (`google-site-verification=google1234567890abcdef.html`).
5. Paste it in the "طريقة 1: Meta Tag Verification" field in `/admin/seo`.
6. Save and re-deploy.
7. Click "Verify" in Google Search Console.

The meta tag is rendered directly in the `<head>` of the root layout (`src/app/layout.tsx`), guaranteeing Google sees it on the homepage.

### Method 2: HTML File Upload (dynamic, default)

1. In Google Search Console, choose the "HTML file" verification method.
2. Google gives you a file like `google1234567890abcdef.html` to download.
3. Open the file — it contains one line like `google-site-verification: google1234567890abcdef.html`.
4. Paste that line in the "طريقة 2: HTML File Verification" field in `/admin/seo`.
5. Save and re-deploy.
6. Verify by visiting `https://YOUR-DOMAIN/google1234567890abcdef.html` — you should see the verification string.
7. Click "Verify" in Google Search Console.

The file is served dynamically via a rewrite rule in `src/proxy.ts` → `src/app/api/gsc-verify/route.ts`. No static file needs to be placed in `public/`. The setting is super-admin only.

### Method 3: HTML File Upload (static, optional fallback)

If you prefer to drop the actual file Google gives you (instead of pasting the content in the admin), use the `public/google-verification/` folder:

1. Download the `googleXXXXXXXX.html` file from Google Search Console.
2. Drop it in `public/google-verification/googleXXXXXXXX.html`.
3. Redeploy on Netlify.
4. The file is served at `https://YOUR-DOMAIN/google-verification/googleXXXXXXXX.html`.
5. Tell Google the URL is `https://YOUR-DOMAIN/google-verification/googleXXXXXXXX.html` when you click "Verify".

If both Method 2 and Method 3 are configured for the same filename, the **static file wins** (Next.js serves static files from `public/` before invoking the dynamic route). Use only one method per filename.

### Important caveats

- Generating the verification file or meta tag does NOT automatically confirm ownership — Google decides the final result when you click "Verify".
- The verification values are stored in Neon as private settings (`isPublic=false`) — they're never exposed via the public settings endpoint.
- If you change your production domain, you'll need to re-verify with Google.
- The DNS TXT verification method is documented in Google's help — this app does not attempt to manage DNS records automatically; configure those at your DNS provider.

---

## 🔒 Security Checklist

- [x] Passwords hashed with scrypt (64-byte key, 16-byte salt)
- [x] HttpOnly + Secure + SameSite=Lax session cookies
- [x] Brute-force lockout (5 fails → 15 min)
- [x] Server-side price recomputation at checkout (client prices never trusted)
- [x] Stock validation before order creation
- [x] Disabled-country rejection
- [x] zod validation on every API input
- [x] Audit log for admin actions
- [x] `robots.txt` blocks `/admin`, `/cart`, `/checkout`, `/api`, `/recherche`, plus pagination & search-query URLs
- [x] `noindex` per-product override + admin/API `X-Robots-Tag: noindex` header
- [x] Secret keys never shipped to the browser
- [x] HTML sanitization on rich-text fields (defeats XSS even from a compromised admin account)
- [x] Magic-byte verification on uploaded images
- [x] SSRF protection on external image URL imports
- [x] Open-redirect protection on redirects (only relative paths or same-origin https allowed)
- [x] Rate limiting on login (10/15min), order creation (10/10min)
- [x] Loop detection on redirects (depth-20 walk)
- [x] RBAC enforcement on settings — `site_url` and GSC keys are super-admin only
- [x] Security headers — CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy
- [x] Audit script — `python3 scripts/security-audit.py` scans for committed secrets

---

## ✅ Post-Deployment Verification Checklist

After deploying to Netlify, run through this checklist BEFORE you announce the site is live:

1. **Build succeeds** — Netlify deploy log shows "Build succeeded" with no errors.
2. **ZIP integrity** — if you deployed via ZIP, verify the unzipped folder contained `package.json`, `prisma/`, `src/`, `public/`, `netlify.toml`, `.env.example`.
3. **Sitemap works** — `https://YOUR-DOMAIN/sitemap.xml` returns XML with your production domain (NOT a Netlify preview URL).
4. **robots.txt works** — `https://YOUR-DOMAIN/robots.txt` shows `Sitemap: https://YOUR-DOMAIN/sitemap.xml`.
5. **Sitemap has no preview URLs** — open the sitemap, search for `netlify.app` — should return ZERO matches.
6. **Production domain propagates** — change `site_url` in `/admin/seo` → click "تحديث Sitemap فوراً" → reload sitemap → URLs should use the new domain.
7. **Site name + logo + description** — visit homepage, check `<title>`, `<meta name="description">`, `<meta property="og:title">`, header logo, footer logo.
8. **Favicon + meta tags** — browser tab shows the correct favicon (DB-configured or `/logo.svg` fallback). View page source → confirm `<meta name="google-site-verification">` is present if you configured GSC.
9. **GSC verification** — `https://YOUR-DOMAIN/googleXXXXXXXX.html` returns the verification string (Method 2 dynamic) OR `https://YOUR-DOMAIN/google-verification/googleXXXXXXXX.html` returns the file (Method 3 static).
10. **Product / category / 404 / redirect routes** — visit a product page, a category page, `/this-page-does-not-exist` (404), and a redirect source path.
11. **Neon data persists** — products / orders / settings created before the deploy are still there (Neon is the source of truth, not the filesystem).
12. **No secrets in browser** — view page source of the homepage, search for `CLOUDINARY_API_SECRET` / `AUTH_SECRET` / `DATABASE_URL` — should return ZERO matches.

> If you cannot test the production domain yet (because you haven't pointed DNS), you can still test points 7-12 on the Netlify preview URL — but **never use the preview URL as your `site_url`**. Configure `NEXT_PUBLIC_SITE_URL` to your real production domain on Netlify env vars, then re-deploy.

---

## 🧪 Verified Flows

- ✅ Homepage renders products, categories, brands, hero, benefits, FAQ
- ✅ Product detail page with JSON-LD (Product, BreadcrumbList, FAQPage), gallery, add-to-cart
- ✅ Cart drawer opens on add, quantity controls, remove, subtotal
- ✅ Checkout COD creates order, decrements stock, shows confirmation
- ✅ 20× logo click → admin login
- ✅ Admin login (scrypt verify) → dashboard KPIs (orders, sales, products, low stock)
- ✅ Admin product CRUD with image upload (with magic-byte validation)
- ✅ Admin order status change with history timeline
- ✅ Admin settings (site, SEO, social, countries, feature flags) with permission-gated saves
- ✅ Dynamic sitemap (`/sitemap.xml`) + robots.txt — both pull site URL from DB
- ✅ Sitemap auto-splits + index when URLs > 50K (Google official limit)
- ✅ Edge proxy enforces DB-defined 301/302 redirects at the edge
- ✅ SEO admin panel at `/admin/seo` — redirects CRUD, slug conflict detection, OG preview, sitemap status, GSC onboarding guide
- ✅ HTML sanitization defeats XSS even from compromised admin accounts
- ✅ Health endpoint at `/api/health` for uptime monitors
- ✅ Lint clean (0 errors, 0 warnings)
- ✅ Build succeeds (`bun run build`)

---

## 🛣️ Roadmap Hooks (already architected)

- **Online payments** — `payment_method`, `payment_status`, `transaction_id` fields exist on `orders`; add a gateway without touching the order schema.
- **Shipping carriers** — `shipping_zones`/`shipping_rates` pattern ready (currently flat `shipping_base` per country).
- **Search** — `searchProducts` uses Postgres ILIKE; swap in Meilisearch/Algolia by replacing one function.
- **Mobile apps** — the entire `/api/*` surface is mobile-ready (cookie or bearer token); no UI-coupled business logic.

---

## 📄 License

Proprietary — built for Ismail Material. Adapt freely for your own deployment.
