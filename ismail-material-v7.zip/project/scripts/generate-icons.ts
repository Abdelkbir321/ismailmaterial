/**
 * Generate favicon + app icons + OG image from the existing logo.svg.
 *
 * This script runs ONCE during project setup. It reads `public/logo.svg`,
 * renders it to PNG at multiple sizes, and writes the PNG files + an ICO
 * multi-resolution file + an OG image to `public/`.
 *
 * Run with:   bun run scripts/generate-icons.ts
 *
 * Why PNGs (and not just the SVG)?
 * --------------------------------
 * - Browser tab favicons need to be either .ico or .png — SVG works in
 *   modern Chrome/Firefox but iOS Safari and many Android browsers
 *   still need PNG. We ship both.
 * - apple-touch-icon MUST be PNG (180×180).
 * - OG image MUST be PNG/JPG, minimum 1200×630, max 8MB.
 *
 * The original `public/logo.svg` is LEFT UNTOUCHED. We generate derived
 * PNGs from a cleaned copy (without the breathing animation, since static
 * icons don't animate anyway).
 */

import sharp from 'sharp'
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const PUBLIC_DIR = join(process.cwd(), 'public')
const LOGO_SVG_PATH = join(PUBLIC_DIR, 'logo.svg')

if (!existsSync(LOGO_SVG_PATH)) {
  console.error(`✗ ${LOGO_SVG_PATH} not found. Run this from the project root.`)
  process.exit(1)
}

// Read the original logo and strip the breathing animation for static renders.
// (The animation only makes sense in the live HTML — PNGs are static.)
const originalSvg = readFileSync(LOGO_SVG_PATH, 'utf-8')
const staticSvg = originalSvg
  // Remove the .z-breathe CSS class so the inner shape is at full opacity.
  .replace(/\.z-breathe\s*\{[^}]*\}/g, '')
  .replace(/@keyframes breathe \{[\s\S]*?\}/g, '')
  // Remove the class attribute on the <g> so it doesn't reference a missing class.
  .replace(/ class="z-breathe"/g, '')

// We'll render the SVG at high resolution first, then downscale to each
// target size. sharp's Lanczos3 resampling produces clean, sharp icons.
const SIZES = [
  { name: 'favicon-16x16.png', size: 16 },
  { name: 'favicon-32x32.png', size: 32 },
  { name: 'favicon-48x48.png', size: 48 },
  { name: 'apple-touch-icon.png', size: 180 },
  { name: 'android-chrome-192x192.png', size: 192 },
  { name: 'android-chrome-512x512.png', size: 512 },
  { name: 'icon-192x192.png', size: 192 },
  { name: 'icon-512x512.png', size: 512 },
] as const

// Background color for icons. The original logo is a dark rounded square
// (#2D2D2D) with white Z — we keep that look so the icons look identical
// to the logo when displayed in the browser tab.
const ICON_BG = '#2D2D2D'

async function renderPng(size: number): Promise<Buffer> {
  // The SVG viewBox is 0 0 30 30. We re-render it onto a `size` × `size`
  // canvas with a solid background (the SVG has a transparent background
  // by default — we need to composite it on the dark square so it shows
  // up on white browser tabs).
  return await sharp(Buffer.from(staticSvg))
    .resize(size, size, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .composite([{ input: { create: { width: size, height: size, channels: 4, background: ICON_BG } }, blend: 'dest-over' }])
    .png({ quality: 90, compressionLevel: 9 })
    .toBuffer()
}

async function renderOgImage(): Promise<Buffer> {
  // OG image: 1200×630, with the logo centered + site name.
  // White background so it's visible on dark UIs (Twitter dark mode,
  // Facebook, WhatsApp dark mode).
  const W = 1200
  const H = 630
  const PADDING = 80
  // Render the SVG at 360×360 (logo area)
  const logoSize = 360
  const logoPng = await sharp(Buffer.from(staticSvg))
    .resize(logoSize, logoSize, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .composite([{ input: { create: { width: logoSize, height: logoSize, channels: 4, background: ICON_BG } }, blend: 'dest-over' }])
    .png()
    .toBuffer()

  // Build the OG image as a composite:
  // 1. White background
  // 2. Logo centered horizontally, slightly above center vertically
  // 3. (No text — we don't have a font rasterizer handy; the logo alone
  //    is professional enough for OG and avoids font rendering issues
  //    in production.)
  const canvas = await sharp({
    create: {
      width: W,
      height: H,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 },
    },
  })
    .png()
    .toBuffer()

  const logoX = Math.floor((W - logoSize) / 2)
  const logoY = Math.floor((H - logoSize) / 2 - 40) // slightly above center

  const composed = await sharp(canvas)
    .composite([
      {
        input: logoPng,
        left: logoX,
        top: logoY,
      },
    ])
    .png({ quality: 90, compressionLevel: 9 })
    .toBuffer()

  return composed
}

/**
 * Write a multi-resolution ICO file containing 16, 32, 48.
 * ICO format:
 *   - ICONDIR (6 bytes): reserved(2)=0, type(2)=1, count(2)=N
 *   - ICONDIRENTRY[N] (16 bytes each): width(1), height(1), colors(1)=0,
 *       reserved(1)=0, planes(2), bitcount(2), bytesize(4), offset(4)
 *   - IMAGE DATA (PNG payloads, since Vista+ supports PNG-in-ICO)
 */
function buildIco(pngs: { '16': Buffer; '32': Buffer; '48': Buffer }): Buffer {
  const sizes: Array<{ w: number; png: Buffer }> = [
    { w: 16, png: pngs[16] },
    { w: 32, png: pngs[32] },
    { w: 48, png: pngs[48] },
  ]
  // Header is 6 bytes; each directory entry is 16 bytes.
  const headerSize = 6
  const dirSize = 16 * sizes.length
  let offset = headerSize + dirSize
  // Build directory
  const dirBufs: Buffer[] = []
  for (const s of sizes) {
    const b = Buffer.alloc(16)
    b.writeUInt8(s.w === 256 ? 0 : s.w, 0) // width (0 = 256)
    b.writeUInt8(s.w === 256 ? 0 : s.w, 1) // height
    b.writeUInt8(0, 2) // colors (0 = no palette)
    b.writeUInt8(0, 3) // reserved
    b.writeUInt16LE(1, 4) // planes
    b.writeUInt16LE(32, 6) // bits per pixel
    b.writeUInt32LE(s.png.length, 8) // image size
    b.writeUInt32LE(offset, 12) // image offset
    dirBufs.push(b)
    offset += s.png.length
  }
  // Header
  const header = Buffer.alloc(6)
  header.writeUInt16LE(0, 0) // reserved
  header.writeUInt16LE(1, 2) // type (1 = icon)
  header.writeUInt16LE(sizes.length, 4) // count
  return Buffer.concat([header, ...dirBufs, ...sizes.map((s) => s.png)])
}

async function main() {
  console.log('→ Generating icons from public/logo.svg')
  const pngCache: Record<number, Buffer> = {}

  for (const { name, size } of SIZES) {
    if (!pngCache[size]) pngCache[size] = await renderPng(size)
    const outPath = join(PUBLIC_DIR, name)
    writeFileSync(outPath, pngCache[size])
    console.log(`  ✓ ${name} (${size}×${size})`)
  }

  // Multi-resolution ICO
  const icoPath = join(PUBLIC_DIR, 'favicon.ico')
  writeFileSync(
    icoPath,
    buildIco({
      '16': pngCache[16],
      '32': pngCache[32],
      '48': pngCache[48],
    }),
  )
  console.log(`  ✓ favicon.ico (16/32/48 multi-resolution)`)

  // OG image
  const ogPath = join(PUBLIC_DIR, 'og-image.png')
  const ogBuf = await renderOgImage()
  writeFileSync(ogPath, ogBuf)
  console.log(`  ✓ og-image.png (1200×630)`)

  // PWA manifest
  const manifest = {
    name: 'Ismail Material',
    short_name: 'Ismail Material',
    description:
      "Outillage électroportatif, accessoires et équipement professionnel au Maroc. Paiement à la livraison — livraison partout au Maroc sous 24–72h.",
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#2D2D2D',
    icons: [
      { src: '/icon-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icon-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icon-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'maskable' },
      { src: '/icon-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  }
  writeFileSync(join(PUBLIC_DIR, 'manifest.json'), JSON.stringify(manifest, null, 2))
  console.log(`  ✓ manifest.json (PWA manifest)`)

  console.log('\n✅ All icons generated in public/.')
}

main().catch((e) => {
  console.error('✗ Failed:', e)
  process.exit(1)
})
