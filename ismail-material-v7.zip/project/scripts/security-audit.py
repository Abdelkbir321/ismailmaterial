#!/usr/bin/env python3
"""
Security audit script — scans the project for exposed secrets & suspicious code.

USAGE
-----
    python3 scripts/security-audit.py

CHECKS
------
1. Source files for hard-coded connection strings / API keys / passwords.
2. .env files committed to git (should be in .gitignore).
3. Suspicious patterns: `eval(`, `new Function(`, `child_process.exec(`, `dangerouslySetInnerHTML` without sanitization.
4. Next.js config leaks: API routes that don't enforce auth.
5. Dependency vulnerabilities via `bun audit` (informational).

EXIT CODES
----------
0 = no issues found
1 = issues found (review required)

This script is safe to run in CI. It NEVER prints the secret VALUES —
only the file:line where the pattern was detected.
"""

import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Patterns that indicate a hard-coded secret.
# We use capture groups only for line detection; values are NEVER printed.
SECRET_PATTERNS = [
    (r'postgresql://[^:\s]+:[^@\s]+@', 'PostgreSQL connection string with credentials'),
    (r'mysql://[^:\s]+:[^@\s]+@', 'MySQL connection string with credentials'),
    (r'mongodb(\+srv)?://[^:\s]+:[^@\s]+@', 'MongoDB connection string with credentials'),
    (r'api[_-]?secret\s*[=:]\s*["\'][^"\']{8,}', 'Cloudinary API secret'),
    (r'cloudinary_api_secret\s*[=:]\s*["\'][^"\']{8,}', 'Cloudinary API secret'),
    (r'sk_live_[a-zA-Z0-9]{16,}', 'Stripe live secret key'),
    (r'rk_live_[a-zA-Z0-9]{16,}', 'Stripe live restricted key'),
    (r'AIza[a-zA-Z0-9_-]{35}', 'Google API key'),
    (r'eyJ[a-zA-Z0-9_-]{10,}\.eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}', 'JWT token'),
    (r'gh[pousr]_[a-zA-Z0-9]{36,}', 'GitHub personal access token'),
    (r'AKIA[0-9A-Z]{16}', 'AWS access key ID'),
    (r'-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----', 'Private key'),
]

# Suspicious code patterns that warrant a manual review.
CODE_PATTERNS = [
    (r'\beval\s*\(', 'eval() — code execution from data'),
    (r'new\s+Function\s*\(', 'new Function() — code execution from data'),
    (r'child_process\.exec(?:Sync)?\s*\(', 'shell command execution'),
    (r'child_process\.execFile(?:Sync)?\s*\(', 'shell command execution'),
    (r'\brequire\s*\(\s*[^\'"]', 'dynamic require() — possible code injection'),
    (r'dangerouslySetInnerHTML\s*=\s*\{\{[^}]*__html\s*:', 'dangerouslySetInnerHTML — verify sanitization'),
]

# Files we should NEVER scan (false positives / vendor code).
SKIP_DIRS = {
    'node_modules', '.next', '.git', 'dist', 'build',
    'tool-results', 'tests', 'mini-services', 'examples', 'public/products',
}
SKIP_FILES = {'tsconfig.tsbuildinfo', 'bun.lock', 'package-lock.json', 'yarn.lock'}
EXTENSIONS = {'.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.json', '.toml', '.yml', '.yaml', '.env', '.sh', '.md'}

issues: list[tuple[str, int, str, str]] = []

def scan_file(path: Path):
    rel = str(path.relative_to(ROOT))
    try:
        content = path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return
    for lineno, line in enumerate(content.splitlines(), start=1):
        # Skip comment lines (very rough)
        stripped = line.lstrip()
        if stripped.startswith('//') or stripped.startswith('#') or stripped.startswith('/*') or stripped.startswith('*'):
            # but do scan env files / config even if they look like comments
            if not rel.endswith('.env') and not rel.endswith('.toml'):
                continue
        for pattern, label in SECRET_PATTERNS:
            if re.search(pattern, line):
                issues.append((rel, lineno, label, 'SECRET'))
                return  # one issue per file is enough for secrets
        for pattern, label in CODE_PATTERNS:
            if re.search(pattern, line):
                # Skip the sanitize.ts file (it deliberately mentions these patterns in comments/tests)
                if 'sanitize.ts' in rel or 'security-audit' in rel:
                    continue
                issues.append((rel, lineno, label, 'CODE'))

def scan_env_committed():
    """Check if .env or .env.local is NOT in .gitignore."""
    gi = ROOT / '.gitignore'
    if not gi.exists():
        return
    gi_content = gi.read_text(encoding='utf-8', errors='ignore')
    has_env = '.env' in gi_content
    # If .env exists but is not gitignored
    env_path = ROOT / '.env'
    if env_path.exists() and not has_env:
        issues.append(('.env', 0, '.env file present but not in .gitignore', 'SECRET'))
    env_local = ROOT / '.env.local'
    if env_local.exists() and '.env.local' not in gi_content:
        issues.append(('.env.local', 0, '.env.local file present but not in .gitignore', 'SECRET'))

def main():
    for root, dirs, files in os.walk(ROOT):
        # prune skipped dirs in-place
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            ext = Path(f).suffix.lower()
            if ext not in EXTENSIONS and not f.startswith('.env'):
                continue
            if f in SKIP_FILES:
                continue
            path = Path(root) / f
            scan_file(path)
    scan_env_committed()

    if not issues:
        print('[security-audit] No issues found.')
        return 0

    secrets = [i for i in issues if i[3] == 'SECRET']
    code_issues = [i for i in issues if i[3] == 'CODE']

    print('=' * 70)
    if secrets:
        print(f'[security-audit] {len(secrets)} SECRET issue(s) found:')
        for path, lineno, label, _ in secrets:
            loc = f'{path}:{lineno}' if lineno else path
            print(f'  {loc}  →  {label}')
        print()
    if code_issues:
        print(f'[security-audit] {len(code_issues)} suspicious code pattern(s) found (review manually):')
        for path, lineno, label, _ in code_issues[:50]:  # cap output
            print(f'  {path}:{lineno}  →  {label}')
        if len(code_issues) > 50:
            print(f'  ... and {len(code_issues) - 50} more')

    print('=' * 70)
    return 1 if secrets else 0  # code issues are warnings, secrets are failures

if __name__ == '__main__':
    sys.exit(main())
