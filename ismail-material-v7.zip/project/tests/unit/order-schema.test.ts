/**
 * Focused test for the dynamic baseSchema logic in /api/orders/route.ts.
 *
 * Run with: bun test tests/unit/order-schema.test.ts
 *
 * Verifies the FIX for the "المرجو تصحيح الحقول المشار إليها بالأحمر." bug
 * where deactivated OrderFields still blocked checkout.
 *
 * We extract the schema-building logic from the route handler so it can be
 * tested without a DB. The route handler now uses this same logic (refactored
 * into src/lib/order-schema.ts).
 */

import { describe, it, expect } from 'bun:test'
import { z } from 'zod'
import type { OrderField } from '@prisma/client'
import { buildOrderSchemaFromFields } from '@/lib/order-schema'

const baseRow = (key: string, overrides: Partial<OrderField> = {}): OrderField => ({
  id: `id_${key}`,
  key,
  type: 'text',
  labelAr: key,
  labelFr: key,
  labelEn: key,
  placeholderAr: null,
  placeholderFr: null,
  placeholderEn: null,
  helpTextAr: null,
  helpTextFr: null,
  helpTextEn: null,
  options: [],
  required: true,
  isActive: true,
  sortOrder: 0,
  defaultValue: null,
  width: 'full',
  minLength: null,
  maxLength: null,
  countryCodes: [],
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides,
})

describe('buildOrderSchemaFromFields — dynamic checkout schema', () => {
  it('accepts a complete valid order with all default fields active', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { type: 'text', required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('email', { type: 'email', required: false }),
      baseRow('country', { type: 'select', required: true }),
      baseRow('city', { type: 'text', required: true }),
      baseRow('address', { type: 'textarea', required: true }),
      baseRow('postal_code', { type: 'text', required: false }),
      baseRow('notes', { type: 'textarea', required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'محمد العامل',
      customerPhone: '+212 6 12 34 56 78',
      customerEmail: '',
      countryId: 'country-1',
      shippingCity: 'الدار البيضاء',
      shippingAddress: 'حي المعاريف، شارع الحسن الثاني، رقم 45',
      shippingPostalCode: '',
      notes: '',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('accepts order with optional fields empty (email, postal_code, notes)', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('email', { type: 'email', required: false }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
      baseRow('postal_code', { required: false }),
      baseRow('notes', { required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Said',
      customerPhone: '0612345678',
      customerEmail: '',
      countryId: 'c1',
      shippingCity: 'Rabat',
      shippingAddress: 'Hassan, Rabat, Morocco',
      shippingPostalCode: '',
      notes: '',
      items: [{ productId: 'p1', variantId: null, quantity: 2 }],
    })
    expect(result.success).toBe(true)
  })

  it('FIX: accepts order when structured field is DEACTIVATED (isActive=false)', async () => {
    // User deactivated `phone` and `email` from the admin panel.
    // Form doesn't render them → user can't fill them → server must NOT
    // require them. This was the original "Veuillez corriger..." bug.
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true, isActive: false }),
      baseRow('email', { type: 'email', required: false, isActive: false }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
      baseRow('postal_code', { required: false }),
      baseRow('notes', { required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Youssef',
      customerPhone: '',            // phone field deactivated — not in form
      customerEmail: '',            // email field deactivated
      countryId: 'c1',
      shippingCity: 'Marrakech',
      shippingAddress: 'Gueliz, Marrakech',
      shippingPostalCode: '',
      notes: '',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('FIX: accepts order when structured field is ACTIVE but required=false (admin made it optional)', async () => {
    // Admin set `phone` to required=false (still showing it in the form,
    // but not requiring it).
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: false }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Karim',
      customerPhone: '',            // empty — should be accepted because required=false
      countryId: 'c1',
      shippingCity: 'Fès',
      shippingAddress: 'Medina, Fès',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('rejects order when REQUIRED structured field is empty (still enforced)', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: '',         // ← missing required full_name
      customerPhone: '+212600000000',
      countryId: 'c1',
      shippingCity: 'Tanger',
      shippingAddress: 'Route de Rabat',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      const issueKeys = result.error.issues.map((i) => i.path.join('.'))
      expect(issueKeys).toContain('customerFullName')
    }
  })

  it('rejects malformed phone when required and field is active', async () => {
    const fields: OrderField[] = [
      baseRow('phone', { type: 'phone', required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerPhone: 'abc-not-a-phone',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(false)
  })

  it('rejects empty cart', async () => {
    const fields: OrderField[] = []
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Test',
      customerPhone: '',
      countryId: 'c1',
      shippingCity: 'Test',
      shippingAddress: 'Test Address 12345',
      items: [],                    // ← empty cart
    })
    expect(result.success).toBe(false)
  })

  it('accepts order with custom (admin-defined) field outside the structured set', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
      baseRow('preferred_delivery_time', { type: 'text', required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Hassan',
      customerPhone: '+212666666666',
      countryId: 'c1',
      shippingCity: 'Agadir',
      shippingAddress: 'Quartier residentiel',
      customFields: { preferred_delivery_time: 'morning' },
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })
})
