/**
 * Central site configuration. Defaults live here; runtime overrides come from
 * the `site_settings` table and the `feature_flags` table (admin-managed).
 *
 * Identity:
 *   - name: "Ismail Material" — the user's actual brand at
 *     ismailmaterial.netlify.app. "Material" reflects the construction /
 *     outillage trade (materials + tools + equipment for the Moroccan
 *     contractor & DIYer).
 *   - tagline: clearer, more action-oriented, mentions the COD + Maroc
 *     delivery that's actually shipped.
 *   - description: keyword-rich, still truthful to the actual catalog
 *     (INGCO, Total Tools, Crown, Würth — power tools).
 *
 * Nothing in the DB schema, design, or login flow changes. The runtime
 * getBranding() service still reads site_name/site_tagline/site_description
 * from the DB if the admin sets them — this file is just the fallback.
 */
export const siteConfig = {
  name: 'Ismail Material',
  tagline: 'Outillage & Matériel Pro au Maroc',
  description:
    "Ismail Material — boutique marocaine d'outillage électroportatif et équipement professionnel. Perceuses, visseuses, meuleuses, niveaux laser et plus. Marques fiables (INGCO, Total Tools, Crown, Würth), paiement à la livraison, expédition 24–72h partout au Maroc.",
  locale: 'fr',
  // Number of logo clicks to reveal hidden admin login (overridable via ADMIN_LOGO_CLICKS env)
  adminLogoClicks: Number(process.env.ADMIN_LOGO_CLICKS) || 20,
  support: {
    phone: '+212 600 000 000',
    whatsapp: '+212600000000',
    email: 'contact@ismailmaterial.ma',
    address: 'Casablanca, Maroc',
  },
  social: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    youtube: '',
    tiktok: '',
  },
  defaultCountry: 'MA',
  defaultCurrency: { code: 'MAD', symbol: 'DH', locale: 'fr-MA' },
}

export type SiteConfig = typeof siteConfig
