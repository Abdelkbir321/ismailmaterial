import { getCurrentAdmin } from './auth'
import { db } from './db'
import type { AdminUser } from '@prisma/client'

export async function requireAdmin(): Promise<AdminUser | null> {
  return getCurrentAdmin()
}

export async function audit(
  adminUserId: string | null,
  action: string,
  entity: string,
  entityId?: string | null,
  metadata: Record<string, unknown> = {},
  meta: { ip?: string; userAgent?: string } = {},
) {
  try {
    await db.auditLog.create({
      data: {
        adminUserId,
        action,
        entity,
        entityId: entityId ?? null,
        metadata: metadata as object,
        ip: meta.ip,
        userAgent: meta.userAgent,
      },
    })
  } catch (e) {
    console.error('[audit] failed to log', action, e)
  }
}

export function clientMeta(req: Request) {
  const forwarded = req.headers.get('x-forwarded-for')
  const ip = forwarded?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || undefined
  const userAgent = req.headers.get('user-agent') || undefined
  return { ip, userAgent }
}

export function jsonError(message: string, status = 400, fieldErrors?: Record<string, string>) {
  return Response.json({ ok: false, error: message, fieldErrors }, { status })
}

export function jsonOk(data: unknown, status = 200) {
  return Response.json({ ok: true, ...data }, { status })
}
