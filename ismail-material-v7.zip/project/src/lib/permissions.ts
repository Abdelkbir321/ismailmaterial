import { db } from './db'
import { getCurrentAdmin } from './auth'
import type { AdminUser, Role } from '@prisma/client'

/**
 * Fine-grained RBAC — sections × actions.
 *
 * Each section has a set of actions. A permission is `{ section: [action, ...] }`.
 * Stored on `Role.permissions` as JSON. Evaluated server-side by `hasPermission`
 * and enforced by `requirePermission` (401 unauth / 403 forbidden).
 */

export type PermissionAction = 'view' | 'create' | 'edit' | 'delete' | 'publish' | 'manage_settings'

export interface PermissionSection {
  key: string
  label: string
  labelAr: string
  actions: PermissionAction[]
}

/** All manageable sections + their allowed actions. */
export const PERMISSION_SECTIONS: PermissionSection[] = [
  { key: 'dashboard', label: 'Dashboard & Stats', labelAr: 'الرئيسية والإحصائيات', actions: ['view'] },
  { key: 'products', label: 'Products', labelAr: 'المنتجات', actions: ['view', 'create', 'edit', 'delete', 'publish'] },
  { key: 'media', label: 'Images & Media', labelAr: 'الصور والوسائط', actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'categories', label: 'Categories & Brands', labelAr: 'التصنيفات والماركات', actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'inventory', label: 'Inventory', labelAr: 'المخزون', actions: ['view', 'edit'] },
  { key: 'orders', label: 'Orders', labelAr: 'الطلبات', actions: ['view', 'edit', 'delete'] },
  { key: 'customers', label: 'Customers', labelAr: 'العملاء', actions: ['view', 'edit'] },
  { key: 'countries', label: 'Countries & Currencies', labelAr: 'الدول والعملات', actions: ['view', 'create', 'edit'] },
  { key: 'order_fields', label: 'Order Fields', labelAr: 'حقول الطلب', actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'pages', label: 'Pages & Content', labelAr: 'المحتوى والصفحات', actions: ['view', 'create', 'edit', 'delete', 'publish'] },
  { key: 'homepage', label: 'Homepage Sections', labelAr: 'الصفحة الرئيسية', actions: ['view', 'edit', 'manage_settings'] },
  { key: 'languages', label: 'Languages & Translations', labelAr: 'اللغات والترجمات', actions: ['view', 'edit'] },
  { key: 'contact_info', label: 'Contact Information', labelAr: 'معلومات التواصل', actions: ['view', 'manage_settings'] },
  { key: 'store_settings', label: 'Store Settings & Visual Identity', labelAr: 'إعدادات المتجر والهوية البصرية', actions: ['view', 'manage_settings'] },
  { key: 'seo', label: 'SEO', labelAr: 'تحسين محركات البحث', actions: ['view', 'manage_settings'] },
  { key: 'coupons', label: 'Marketing & Coupons', labelAr: 'التسويق والكوبونات', actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'reports', label: 'Reports', labelAr: 'التقارير', actions: ['view'] },
  { key: 'admin_users', label: 'Administrators', labelAr: 'المسؤولون', actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'permissions', label: 'Permissions', labelAr: 'الصلاحيات', actions: ['view', 'manage_settings'] },
  { key: 'audit_logs', label: 'Audit Logs', labelAr: 'سجلات التدقيق', actions: ['view'] },
  { key: 'security', label: 'Security Settings', labelAr: 'إعدادات الأمان', actions: ['view', 'manage_settings'] },
]

/** Super-admin permission = all sections × all actions. */
export function superAdminPermissions(): Record<string, PermissionAction[]> {
  const out: Record<string, PermissionAction[]> = {}
  for (const s of PERMISSION_SECTIONS) out[s.key] = [...s.actions]
  return out
}

/** Default role permission sets. */
export const ROLE_PERMISSIONS: Record<string, Record<string, PermissionAction[]>> = {
  'super-admin': superAdminPermissions(),
  'store-manager': {
    dashboard: ['view'],
    products: ['view', 'create', 'edit'],
    media: ['view', 'create', 'edit'],
    categories: ['view', 'edit'],
    inventory: ['view', 'edit'],
    orders: ['view', 'edit'],
    customers: ['view', 'edit'],
    countries: ['view'],
    order_fields: ['view'],
    pages: ['view', 'edit'],
    homepage: ['view'],
    coupons: ['view', 'create', 'edit'],
    reports: ['view'],
  },
  'products-manager': {
    dashboard: ['view'],
    products: ['view', 'create', 'edit', 'publish'],
    media: ['view', 'create', 'edit'],
    categories: ['view', 'edit'],
    inventory: ['view', 'edit'],
  },
  'orders-manager': {
    dashboard: ['view'],
    orders: ['view', 'edit'],
    customers: ['view'],
  },
  'content-seo-manager': {
    dashboard: ['view'],
    pages: ['view', 'create', 'edit', 'publish'],
    homepage: ['view', 'edit', 'manage_settings'],
    seo: ['view', 'manage_settings'],
    media: ['view', 'create', 'edit'],
    store_settings: ['view', 'manage_settings'],
  },
  'support-agent': {
    dashboard: ['view'],
    orders: ['view'],
    customers: ['view', 'edit'],
  },
}

/**
 * Check if an admin has a specific permission.
 * Super-admin (role slug 'super-admin') always has ALL permissions.
 */
export function hasPermission(
  admin: (AdminUser & { role: Role }) | null,
  section: string,
  action: PermissionAction = 'view',
): boolean {
  if (!admin) return false
  if (admin.status !== 'ACTIVE') return false
  // super-admin bypass
  if (admin.role.slug === 'super-admin') return true
  const perms = admin.role.permissions as Record<string, string[]>
  const sectionPerms = perms[section]
  if (!sectionPerms || !Array.isArray(sectionPerms)) return false
  return sectionPerms.includes(action)
}

/**
 * Server-side guard for API routes. Returns the admin if allowed, or a Response
 * (401 / 403) if not. Usage:
 *
 *   const admin = await requirePermission('products', 'create')
 *   if (admin instanceof Response) return admin
 *   // admin is now (AdminUser & { role: Role })
 */
export async function requirePermission(
  section: string,
  action: PermissionAction = 'view',
): Promise<(AdminUser & { role: Role }) | Response> {
  const admin = await getCurrentAdmin()
  if (!admin) {
    return new Response(JSON.stringify({ ok: false, error: 'غير مصرّح — سجّل الدخول' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    })
  }
  if (!hasPermission(admin, section, action)) {
    return new Response(
      JSON.stringify({ ok: false, error: 'ممنوع — ماعندكش الصلاحية لهذه العملية' }),
      { status: 403, headers: { 'Content-Type': 'application/json' } },
    )
  }
  return admin
}

/** Is this admin a super-admin? */
export function isSuperAdmin(admin: (AdminUser & { role: Role }) | null): boolean {
  return !!admin && admin.role.slug === 'super-admin'
}

/** Count active super-admins (for "can't delete/disable last super-admin" rule). */
export async function countActiveSuperAdmins(): Promise<number> {
  const superRole = await db.role.findUnique({ where: { slug: 'super-admin' } })
  if (!superRole) return 0
  return db.adminUser.count({ where: { roleId: superRole.id, status: 'ACTIVE' } })
}
