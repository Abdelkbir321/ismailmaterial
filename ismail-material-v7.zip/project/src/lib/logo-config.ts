/**
 * Logo types + defaults — shared between client + server.
 *
 * WHY THIS FILE EXISTS
 * --------------------------------------------------------------------------
 * The branding.ts service is a server-side file (it reads from the DB via
 * `getPublicSettings`). The Logo component is a CLIENT component (it uses
 * the Web Animations API). Importing `DEFAULT_LOGO_MOTION` directly from
 * `branding.ts` into the client would drag the entire branding service
 * (including its server-only imports) into the client bundle, which
 * Turbopack refuses to bundle.
 *
 * By extracting the types + defaults into this pure-types-and-constants
 * file, both the server service and the client component can safely
 * import from here without bundler issues.
 *
 * ==========================================================================
 * EXPANDED CONFIG (this version)
 * --------------------------------------------------------------------------
 * The original config only had 5 motion types (breathe/float/rotate/pulse/none)
 * with 3 speed + 3 intensity options. The admin requested much more control:
 *   - 3D rotation (rotate3d) with X/Y/Z axis + perspective
 *   - 3D tilt animation
 *   - Shadow / glow / border / background / border-radius controls
 *   - Mobile-specific settings (independent disable, separate size)
 *   - Restore defaults
 *
 * All new fields are OPTIONAL and backward-compatible — old `logo_motion`
 * JSON in the DB (without the new fields) still parses correctly and falls
 * back to defaults.
 * ==========================================================================
 */

// === MOTION TYPES ===

export type LogoMotionType =
  | 'breathe'   // opacity pulse (original)
  | 'float'     // translateY (original)
  | 'rotate'    // 2D Z-axis rotation (original)
  | 'pulse'     // scale pulse (original)
  | 'rotate3d'  // NEW: 3D rotation with perspective (X/Y/Z axes)
  | 'tilt'      // NEW: 3D tilt (rotateX + rotateY oscillation)
  | 'none'      // static

export interface LogoMotion {
  /** Animation type. Default: 'breathe' (matches the original SVG behavior) */
  type: LogoMotionType
  /** Speed multiplier: 0.5 (slow), 1 (normal), 2 (fast). Default: 1 */
  speed: 0.5 | 1 | 2
  /** Intensity multiplier: 0.3 (subtle), 0.5 (normal), 0.8 (strong). Default: 0.5 */
  intensity: 0.3 | 0.5 | 0.8
  // === NEW: 3D rotation axis controls (used by rotate3d + tilt) ===
  /** Rotation around X axis (degrees, 0-360). Default: 0 */
  rotateX?: number
  /** Rotation around Y axis (degrees, 0-360). Default: 0 */
  rotateY?: number
  /** Rotation around Z axis (degrees, 0-360). Default: 0 (used by rotate3d for full spin) */
  rotateZ?: number
  /** 3D perspective in px (300-2000). Default: 600 */
  perspective?: number
  /** Tilt direction for 'tilt': 'horizontal' | 'vertical' | 'both'. Default: 'both' */
  tiltDirection?: 'horizontal' | 'vertical' | 'both'
}

export interface LogoSize {
  /** Width in px (8-200). Default: 36 */
  width: number
  /** Height in px (8-200). Default: 36 */
  height: number
  /** Whether to preserve aspect ratio when resizing. Default: true */
  maintainAspectRatio: boolean
}

// === NEW: Visual effects (shadow, glow, border, background) ===

export interface LogoVisual {
  /** Drop shadow. null = none. Default: null */
  shadow: LogoShadow | null
  /** Glow (box-shadow with color). null = none. Default: null */
  glow: LogoGlow | null
  /** Border around the logo container. null = none. Default: null */
  border: LogoBorder | null
  /** Background behind the logo (the "card" the logo sits on). null = transparent. Default: null */
  background: LogoBackground | null
  /** Border radius of the logo container in px (0-50). Default: 8 */
  borderRadius: number
  /** Padding around the logo in px (0-20). Default: 4 */
  padding: number
}

export interface LogoShadow {
  /** Shadow color (hex or rgba). Default: 'rgba(0,0,0,0.15)' */
  color: string
  /** Blur in px (0-30). Default: 6 */
  blur: number
  /** X offset in px (-10 to 10). Default: 0 */
  offsetX: number
  /** Y offset in px (-10 to 10). Default: 2 */
  offsetY: number
}

export interface LogoGlow {
  /** Glow color (hex or rgba). Default: '#EA580C' */
  color: string
  /** Blur/spread in px (0-40). Default: 12 */
  blur: number
  /** Intensity 0-1 (opacity of the glow). Default: 0.5 */
  intensity: number
}

export interface LogoBorder {
  /** Border color (hex). Default: '#E5E5E5' */
  color: string
  /** Width in px (0-5). Default: 1 */
  width: number
  /** Border style. Default: 'solid' */
  style: 'solid' | 'dashed' | 'dotted'
}

export interface LogoBackground {
  /** Background color (hex or 'transparent'). Default: 'transparent' */
  color: string
  /** Opacity 0-1. Default: 1 */
  opacity: number
}

// === NEW: Mobile-specific settings ===

export interface LogoMobile {
  /** Whether to disable animation on mobile entirely. Default: false */
  disableAnimation: boolean
  /** Separate size for mobile (null = use desktop size). Default: null */
  size: LogoSize | null
  /** Mobile breakpoint in px (below this = mobile). Default: 768 */
  breakpoint: number
}

// === DEFAULTS ===

export const DEFAULT_LOGO_SIZE: LogoSize = {
  width: 36,
  height: 36,
  maintainAspectRatio: true,
}

export const DEFAULT_LOGO_MOTION: LogoMotion = {
  type: 'breathe',
  speed: 1,
  intensity: 0.5,
}

export const DEFAULT_LOGO_VISUAL: LogoVisual = {
  shadow: null,
  glow: null,
  border: null,
  background: null,
  borderRadius: 8,
  padding: 4,
}

export const DEFAULT_LOGO_MOBILE: LogoMobile = {
  disableAnimation: false,
  size: null,
  breakpoint: 768,
}

// === SELECTOR OPTIONS (for admin UI) ===

export const LOGO_MOTION_OPTIONS: Array<{
  type: LogoMotionType
  label: string
  desc: string
}> = [
  { type: 'breathe', label: 'تنفس (opacity)', desc: 'الأنيميشن الأصلي' },
  { type: 'float', label: 'تعويم', desc: 'translateY' },
  { type: 'rotate', label: 'تدوير 2D', desc: 'دوران حول المحور Z' },
  { type: 'pulse', label: 'نبض', desc: 'scale' },
  { type: 'rotate3d', label: 'تدوير 3D', desc: 'دوران ثلاثي الأبعاد' },
  { type: 'tilt', label: 'إمالة 3D', desc: 'إمالة X/Y' },
  { type: 'none', label: 'بدون', desc: 'ثابت' },
]

export const LOGO_MOTION_SPEED_OPTIONS: Array<{ v: 0.5 | 1 | 2; label: string }> = [
  { v: 0.5, label: 'بطيء' },
  { v: 1, label: 'عادي' },
  { v: 2, label: 'سريع' },
]

export const LOGO_MOTION_INTENSITY_OPTIONS: Array<{ v: 0.3 | 0.5 | 0.8; label: string }> = [
  { v: 0.3, label: 'خفيفة' },
  { v: 0.5, label: 'عادية' },
  { v: 0.8, label: 'قوية' },
]

export const LOGO_TILT_DIRECTION_OPTIONS: Array<{ v: LogoMotion['tiltDirection']; label: string }> = [
  { v: 'both', label: 'كلا الاتجاهين' },
  { v: 'horizontal', label: 'أفقي فقط' },
  { v: 'vertical', label: 'عمودي فقط' },
]
