import crypto from 'node:crypto'

/**
 * Password hashing using Node's scrypt (no extra deps).
 * Format: `scrypt$<saltHex>$<hashHex>$<N>$<r>$<p>`
 */

const N = 16384
const r = 8
const p = 1
const keyLen = 64

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16)
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, keyLen, { N, r, p, maxmem: 64 * 1024 * 1024 }, (err, key) => {
      if (err) return reject(err)
      resolve(`scrypt$${salt.toString('hex')}$${key.toString('hex')}$${N}$${r}$${p}`)
    })
  })
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  try {
    const parts = stored.split('$')
    if (parts.length !== 6 || parts[0] !== 'scrypt') return false
    const salt = Buffer.from(parts[1], 'hex')
    const expectedKey = Buffer.from(parts[2], 'hex')
    const sN = Number(parts[3])
    const sr = Number(parts[4])
    const sp = Number(parts[5])
    return new Promise((resolve) => {
      crypto.scrypt(password, salt, keyLen, { N: sN, r: sr, p: sp, maxmem: 64 * 1024 * 1024 }, (err, key) => {
        if (err) return resolve(false)
        resolve(crypto.timingSafeEqual(key, expectedKey))
      })
    })
  } catch {
    return false
  }
}

export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex')
}

export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex')
}
