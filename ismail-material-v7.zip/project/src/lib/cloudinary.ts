/**
 * Cloudinary helper. All signing happens server-side — the API secret is
 * never shipped to the browser.
 *
 * Supports TWO upload modes:
 *  1. Server-side buffer upload (buffer → Cloudinary SDK → media row)
 *  2. Signed upload params returned to the browser for direct-to-Cloudinary
 *     upload (bypasses Netlify function body size limits for large files)
 *
 * Also validates EXTERNAL image URLs (must point to a real image, not just
 * any https URL).
 *
 * When Cloudinary is NOT configured, uploads gracefully fall back to a
 * placeholder so the admin UI stays functional in dev/preview.
 */

export interface CloudinaryConfig {
  cloudName: string
  apiKey: string
  apiSecret: string
}

export function getCloudinaryConfig(): CloudinaryConfig | null {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME || process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME
  const apiKey = process.env.CLOUDINARY_API_KEY
  const apiSecret = process.env.CLOUDINARY_API_SECRET
  if (!cloudName || !apiKey || !apiSecret) return null
  return { cloudName, apiKey, apiSecret }
}

export function isCloudinaryConfigured(): boolean {
  return getCloudinaryConfig() !== null
}

/** Public-facing delivery URL builder (uses NEXT_PUBLIC cloud name). */
export function cloudinaryUrl(
  publicId: string,
  options: { width?: number; height?: number; format?: string; quality?: string | number } = {},
): string {
  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME || process.env.CLOUDINARY_CLOUD_NAME
  if (!cloudName || !publicId) return ''
  const transforms: string[] = []
  if (options.width) transforms.push(`w_${options.width}`)
  if (options.height) transforms.push(`h_${options.height}`)
  if (options.quality) transforms.push(`q_${options.quality}`)
  transforms.push('c_limit', 'f_auto')
  const t = transforms.length ? `${transforms.join(',')}/` : ''
  return `https://res.cloudinary.com/${cloudName}/image/upload/${t}${publicId}`
}

/**
 * Server-side buffer upload to Cloudinary (uses the official SDK if installed).
 * Used by the admin upload route for normal-sized images.
 */
export async function uploadBuffer(
  buffer: Buffer,
  folder: string,
  publicId?: string,
): Promise<{
  publicId: string
  secureUrl: string
  url: string
  width?: number
  height?: number
  format?: string
  bytes?: number
} | null> {
  const cfg = getCloudinaryConfig()
  if (!cfg) return null
  try {
    const Cloudinary = (await import('cloudinary')).v2 as typeof import('cloudinary').v2
    Cloudinary.config({
      cloud_name: cfg.cloudName,
      api_key: cfg.apiKey,
      api_secret: cfg.apiSecret,
      secure: true,
    })
    const res = await Cloudinary.uploader.upload(buffer, {
      folder,
      public_id: publicId,
      resource_type: 'image',
    })
    return {
      publicId: res.public_id,
      secureUrl: res.secure_url,
      url: res.url,
      width: res.width,
      height: res.height,
      format: res.format,
      bytes: res.bytes,
    }
  } catch {
    return null
  }
}

/**
 * Generate a signed upload signature + params for DIRECT browser-to-Cloudinary
 * upload. Returns the API key, timestamp, signature, and cloud name so the
 * browser can POST the file directly to Cloudinary (bypassing our function
 * body-size limit). The API secret NEVER leaves the server.
 */
export function signDirectUpload(folder: string, maxFileSizeBytes?: number): {
  cloudName: string
  apiKey: string
  timestamp: number
  signature: string
  folder: string
  uploadPreset?: string
  maxFileSizeBytes?: number
} | null {
  const cfg = getCloudinaryConfig()
  if (!cfg) return null
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const crypto = require('node:crypto')
  const timestamp = Math.floor(Date.now() / 1000)
  const paramsToSign: Record<string, string> = { folder, timestamp: String(timestamp) }
  if (process.env.CLOUDINARY_UPLOAD_PRESET) {
    paramsToSign.upload_preset = process.env.CLOUDINARY_UPLOAD_PRESET
  }
  const sorted = Object.keys(paramsToSign).sort()
  const toSign = sorted.map((k) => `${k}=${paramsToSign[k]}`).join('&')
  const signature = crypto.createHash('sha256').update(toSign + cfg.apiSecret).digest('hex')
  return {
    cloudName: cfg.cloudName,
    apiKey: cfg.apiKey,
    timestamp,
    signature,
    folder,
    uploadPreset: process.env.CLOUDINARY_UPLOAD_PRESET || undefined,
    maxFileSizeBytes,
  }
}

/**
 * Validate an external image URL — FAST and NON-BLOCKING.
 *
 * ROOT CAUSE of the previous "خطأ في الشبكة" (network error): the old code did
 * a server-side `fetch()` to the external URL with a 12s timeout. On Netlify
 * serverless functions (10s default timeout), this fetch could time out the
 * ENTIRE function → the browser saw the POST to /api/admin/upload itself fail
 * → "network error". External hosts also often block datacenter IPs (hotlink
 * protection), making the fetch fail even when the URL is perfectly valid.
 *
 * NEW approach (fixes the root cause):
 *  1. Synchronous format validation (http/https only) — instant.
 *  2. SSRF protection — block localhost, private IPs, cloud metadata, .local.
 *  3. BEST-EFFORT HEAD check with a SHORT 4s timeout. If it succeeds and
 *     returns image/* content-type → fully verified. If it FAILS (timeout,
 *     blocked, non-image) → we STILL ACCEPT the URL but mark it
 *     `verified: false`. The browser verifies rendering via <img onError>.
 *     This way a slow/blocking external host never fails the upload.
 *
 * We do NOT trust the URL just because it starts with https — but we also
 * don't REJECT it just because our server can't reach it (the user's browser
 * might still render it fine).
 */
export async function validateExternalImageUrl(
  url: string,
  _opts: { maxBytes?: number; timeoutMs?: number } = {},
): Promise<{ ok: boolean; verified: boolean; error?: string; contentType?: string; bytes?: number }> {
  // 1. format validation (synchronous)
  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    return { ok: false, verified: false, error: 'رابط غير صالح (URL invalide).' }
  }
  if (!/^https?:$/.test(parsed.protocol)) {
    return { ok: false, verified: false, error: 'الرابط لازم يبدأ بـ http(s)://' }
  }

  // 2. SSRF protection — block internal/private/metadata hosts
  const host = parsed.hostname.toLowerCase()
  const ssrfBlocked = isSsrfBlocked(host)
  if (ssrfBlocked) {
    return { ok: false, verified: false, error: 'هاد الرابط محظور لأسباب أمنية (SSRF protection).' }
  }

  // 3. BEST-EFFORT HEAD check (short, non-blocking). Failure does NOT reject.
  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 4000)
    const res = await fetch(url, {
      method: 'HEAD',
      signal: controller.signal,
      redirect: 'follow',
    })
    clearTimeout(timer)
    const contentType = (res.headers.get('content-type') || '').toLowerCase()
    const bytes = Number(res.headers.get('content-length') || 0) || undefined
    if (res.ok && contentType.startsWith('image/')) {
      return { ok: true, verified: true, contentType, bytes }
    }
    // Non-image content-type OR non-200 — still accept but warn (some servers
    // return wrong content-type on HEAD, or block HEAD but allow GET).
    return { ok: true, verified: false, contentType: contentType || undefined, bytes }
  } catch {
    // Fetch failed (timeout, blocked, DNS, etc.) — accept anyway, browser verifies.
    return { ok: true, verified: false }
  }
}

/** SSRF protection — block private/internal/metadata hosts. */
function isSsrfBlocked(host: string): boolean {
  // localhost variants
  if (host === 'localhost' || host === 'localhost.' || host.endsWith('.localhost')) return true
  // IPv4/IPv6 loopback
  if (host === '127.0.0.1' || host === '::1' || host === '[::1]') return true
  // "any" / broadcast
  if (host === '0.0.0.0' || host === '0' || host === '[::]') return true
  // private ranges (10.x, 172.16-31.x, 192.168.x)
  if (/^10\./.test(host)) return true
  if (/^192\.168\./.test(host)) return true
  if (/^172\.(1[6-9]|2[0-9]|3[01])\./.test(host)) return true
  // link-local (169.254.x — includes AWS/GCP/Azure cloud metadata 169.254.169.254)
  if (/^169\.254\./.test(host)) return true
  // carrier-grade NAT
  if (/^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\./.test(host)) return true
  // IPv6 link-local / unique-local
  if (/^fe[89ab][0-9a-f]:/i.test(host) || /^fc[0-9a-f]{2}:/i.test(host) || /^fd[0-9a-f]{2}:/i.test(host)) return true
  // internal TLDs
  if (host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.lan')) return true
  // metadata host aliases used by some clouds
  if (host === 'metadata' || host === 'metadata.google.internal') return true
  // raw IP that's not public (defensive — the regexes above catch private; this is a backstop)
  return false
}

const ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif', 'image/svg+xml']

export function validateImageFile(file: { type: string; size: number; name?: string }): {
  ok: boolean
  error?: string
} {
  if (!ALLOWED_MIME.includes(file.type)) {
    return { ok: false, error: 'نوع الصورة غير مدعوم. استعمل JPG, PNG, WEBP, GIF, AVIF أو SVG.' }
  }
  // No hard 5MB cap — Cloudinary handles large files. We cap at 25MB to be sane.
  if (file.size > 25 * 1024 * 1024) {
    return { ok: false, error: 'الصورة كبيرة بزاف (الحد الأقصى 25 MB).' }
  }
  return { ok: true }
}

/**
 * Magic-byte verification — does NOT trust the browser-supplied MIME type or
 * file extension. Reads the first few bytes of the buffer and matches them
 * against the known signatures of the allowed image formats.
 *
 * Returns true when the buffer looks like one of the allowed image types.
 * False positives are essentially impossible; false negatives can happen
 * only if the buffer is tiny or truncated.
 */
const MAGIC_SIGNATURES: Array<{ mime: string; bytes: number[]; offset: number }> = [
  { mime: 'image/jpeg', bytes: [0xff, 0xd8, 0xff], offset: 0 },
  { mime: 'image/png', bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], offset: 0 },
  { mime: 'image/gif', bytes: [0x47, 0x49, 0x46, 0x38], offset: 0 }, // GIF8
  { mime: 'image/webp', bytes: [0x52, 0x49, 0x46, 0x46], offset: 0 }, // RIFF + WEBP at offset 8
  { mime: 'image/avif', bytes: [0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70, 0x61, 0x76, 0x69, 0x66], offset: 0 }, // ....ftypavif
  // SVG is text-based — no magic bytes; we accept it when validateImageFile says so
]

export function verifyImageMagicBytes(buffer: Buffer): { ok: boolean; mime?: string } {
  if (!buffer || buffer.length < 4) return { ok: false }
  // Check SVG: starts with `<?xml` or `<svg`
  const head = buffer.slice(0, 16).toString('utf8').trimStart().toLowerCase()
  if (head.startsWith('<?xml') || head.startsWith('<svg')) {
    // Defensive: reject if it contains a <script> tag — browsers won't execute
    // scripts inside <img> but if someone loads it directly the script would
    // run in the browser origin.
    if (head.includes('<script') || buffer.toString('utf8').slice(0, 4096).toLowerCase().includes('<script')) {
      return { ok: false }
    }
    return { ok: true, mime: 'image/svg+xml' }
  }
  for (const sig of MAGIC_SIGNATURES) {
    let match = true
    for (let i = 0; i < sig.bytes.length; i++) {
      if (buffer[sig.offset + i] !== sig.bytes[i]) {
        match = false
        break
      }
    }
    if (match) {
      // For WebP, also confirm "WEBP" appears at offset 8
      if (sig.mime === 'image/webp') {
        const tag = buffer.slice(8, 12).toString('latin1')
        if (tag !== 'WEBP') return { ok: false }
      }
      return { ok: true, mime: sig.mime }
    }
  }
  return { ok: false }
}
