import { db } from '@/lib/db'
import { unstable_cache } from 'next/cache'

const SETTINGS_CACHE_TAG = 'settings'

export const getSetting = unstable_cache(
  async (key: string): Promise<string | null> => {
    const row = await db.siteSetting.findUnique({ where: { key } })
    return row?.value ?? null
  },
  ['setting-single'],
  { revalidate: 60, tags: [SETTINGS_CACHE_TAG] },
)

export const getPublicSettings = unstable_cache(
  async (): Promise<Record<string, string>> => {
    const rows = await db.siteSetting.findMany({ where: { isPublic: true } })
    const map: Record<string, string> = {}
    for (const r of rows) map[r.key] = r.value
    return map
  },
  ['settings-public'],
  { revalidate: 60, tags: [SETTINGS_CACHE_TAG] },
)

export const getAllSettings = unstable_cache(
  async (): Promise<Record<string, string>> => {
    const rows = await db.siteSetting.findMany()
    const map: Record<string, string> = {}
    for (const r of rows) map[r.key] = r.value
    return map
  },
  ['settings-all'],
  { revalidate: 60, tags: [SETTINGS_CACHE_TAG] },
)

export async function setSetting(key: string, value: string, group = 'general', type = 'text', isPublic = true) {
  // Sensitive keys that must NEVER be exposed to the public (browser).
  // They're only readable server-side via getAllSettings (admin auth required).
  const PRIVATE_KEYS = new Set([
    'gsc_verification_token',
    'gsc_verification_file_content',
    'maintenance_mode', // internal flag, not for browser
  ])
  const actualPublic = PRIVATE_KEYS.has(key) ? false : isPublic
  await db.siteSetting.upsert({
    where: { key },
    create: { key, value, group, type, isPublic: actualPublic },
    update: { value, group, type, isPublic: actualPublic },
  })
  return true
}

export async function setSettingsBulk(items: Array<{ key: string; value: string; group?: string; type?: string; isPublic?: boolean }>) {
  await Promise.all(items.map((i) => setSetting(i.key, i.value, i.group, i.type, i.isPublic)))
  return true
}

export const getFeatureFlags = unstable_cache(
  async (): Promise<Record<string, boolean>> => {
    const rows = await db.featureFlag.findMany()
    const map: Record<string, boolean> = {}
    for (const r of rows) map[r.key] = r.isEnabled
    return map
  },
  ['feature-flags'],
  { revalidate: 60, tags: [SETTINGS_CACHE_TAG] },
)

export async function isFeatureEnabled(key: string): Promise<boolean> {
  const flags = await getFeatureFlags()
  return flags[key] === true
}

export async function getSettingBool(key: string, fallback = false): Promise<boolean> {
  const v = await getSetting(key)
  if (v === null || v === undefined) return fallback
  return v === 'true' || v === '1'
}

export async function getSettingJson<T = unknown>(key: string, fallback: T): Promise<T> {
  const v = await getSetting(key)
  if (!v) return fallback
  try {
    return JSON.parse(v) as T
  } catch {
    return fallback
  }
}

export function revalidateSettings() {
  // caller can use revalidateTag(SETTINGS_CACHE_TAG)
}

// =========================================================================
// PRODUCTION DOMAIN — Single Source of Truth
// =========================================================================
//
// Priority order (HIGHEST → LOWEST):
//   1. `site_url` in `site_settings` table (super-admin editable via /admin/seo)
//   2. `NEXT_PUBLIC_SITE_URL` environment variable
//   3. fallback to `http://localhost:3000` (dev only — NEVER used in production)
//
// IMPORTANT RULES:
//   - The DB value ALWAYS wins over the env var when both are present and
//     valid. This lets you change the domain post-deploy without rebuilding.
//   - When neither is set/valid, this function returns null and callers
//     MUST NOT generate absolute URLs (sitemap, OG, canonical). They should
//     fall back to relative paths or skip the URL entirely. We never
//     fabricate a domain.
//   - We NEVER use `window.location.origin`, `Host`, or `X-Forwarded-Host`
//     to determine the production domain — those headers come from
//     untrusted requests and would leak Netlify preview URLs into the
//     sitemap. Only the DB value or env var is trusted.
//   - In Netlify preview deployments, the env var typically equals the
//     production URL (set in Netlify site settings), so previews DON'T
//     pollute the production sitemap. If the env var is set to a preview
//     URL by mistake, the DB value (if set) overrides it.
//   - The DB value is validated to be a clean HTTPS URL: protocol must be
//     https in production (http allowed only on localhost), no path, no
//     query, no fragment, no credentials.
//
// USAGE:
//   const siteUrl = await getProductionDomain()
//   if (!siteUrl) return Response.json({ error: 'Production domain not configured' }, { status: 503 })
//   // build absolute URLs with `${siteUrl}/produits/${slug}`

export async function getProductionDomain(): Promise<string | null> {
  // 1) DB value (highest priority)
  try {
    const row = await getSetting('site_url')
    if (row) {
      const cleaned = normalizeDomain(row)
      if (cleaned) return cleaned
    }
  } catch {
    // ignore — fall through to env
  }
  // 2) Env var
  const envUrl = process.env.NEXT_PUBLIC_SITE_URL
  if (envUrl) {
    const cleaned = normalizeDomain(envUrl)
    if (cleaned) return cleaned
  }
  // 3) Dev fallback — only when explicitly on localhost
  if (process.env.NODE_ENV !== 'production') {
    return 'http://localhost:3000'
  }
  // Production + no valid config → return null (callers must handle gracefully)
  return null
}

/**
 * Validate & normalize a production domain.
 * Accepts:
 *   - https://example.com
 *   - https://www.example.com
 *   - http://localhost:3000 (dev only — rejected in production)
 * Rejects:
 *   - non-https URLs in production
 *   - URLs with paths, queries, fragments, credentials, ports (except localhost)
 *   - URLs with IP addresses (must be a hostname)
 *   - URLs with paths like /path
 *   - javascript:, data:, file: protocols
 */
function normalizeDomain(input: string): string | null {
  if (!input || typeof input !== 'string') return null
  const trimmed = input.trim()
  if (!trimmed) return null
  let parsed: URL
  try {
    parsed = new URL(trimmed)
  } catch {
    return null
  }
  // Protocol check
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null
  // In production, require https (allow http only for localhost)
  const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1'
  if (process.env.NODE_ENV === 'production' && parsed.protocol !== 'https:' && !isLocalhost) {
    return null
  }
  // Block paths, queries, fragments, credentials
  if (parsed.pathname !== '/' && parsed.pathname !== '') return null
  if (parsed.search) return null
  if (parsed.hash) return null
  if (parsed.username || parsed.password) return null
  // Block raw IPs in production (must be a hostname)
  if (process.env.NODE_ENV === 'production' && /^\d{1,3}(\.\d{1,3}){3}$/.test(parsed.hostname) && !isLocalhost) {
    return null
  }
  // Strip trailing slash
  return `${parsed.protocol}//${parsed.host}`.replace(/\/+$/, '')
}

/**
 * Same as getProductionDomain but never returns null — falls back to a
 * relative root URL. Use ONLY for non-critical UI (e.g. canonical links
 * on error pages where the sitemap is already correct).
 *
 * For SEO-critical paths (sitemap, robots.txt, structured data), ALWAYS
 * use `getProductionDomain()` and skip the URL if it returns null.
 */
export async function getProductionDomainOrEmpty(): Promise<string> {
  return (await getProductionDomain()) || ''
}

