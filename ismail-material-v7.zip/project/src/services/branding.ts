import { getPublicSettings, getSetting } from '@/services/settings'
import { siteConfig } from '@/config/site'
// Types + defaults are in a shared file so they can be imported from
// BOTH the server (here) and the client (Logo component) without dragging
// server-side DB imports into the client bundle.
import {
  DEFAULT_LOGO_MOBILE,
  DEFAULT_LOGO_MOTION,
  DEFAULT_LOGO_SIZE,
  DEFAULT_LOGO_VISUAL,
  type LogoMobile,
  type LogoMotion,
  type LogoMotionType,
  type LogoSize,
  type LogoVisual,
} from '@/lib/logo-config'

// Re-export so consumers of branding.ts still see the same types/defaults
export type { LogoMobile, LogoMotion, LogoMotionType, LogoSize, LogoVisual } from '@/lib/logo-config'
export { DEFAULT_LOGO_MOBILE, DEFAULT_LOGO_MOTION, DEFAULT_LOGO_SIZE, DEFAULT_LOGO_VISUAL } from '@/lib/logo-config'

export interface Branding {
  siteName: string
  tagline: string
  description: string
  logoUrl: string | null
  logoAlt: string
  faviconUrl: string | null
  /** Cache-bust version for the favicon — appended as ?v=... to bypass browser cache */
  faviconCacheBust: string | null
  primaryColor: string
  accentColor: string
  /** Parsed logo size settings (null = use code defaults) */
  logoSize: LogoSize | null
  /** Parsed logo motion settings (null = use code defaults) */
  logoMotion: LogoMotion | null
  /** Parsed logo visual effects (shadow/glow/border/background). null = defaults */
  logoVisual: LogoVisual | null
  /** Parsed logo mobile settings (independent disable, separate size). null = defaults */
  logoMobile: LogoMobile | null
  /** 3D hero scene settings (null = use defaults / scene not configured) */
  heroScene: HeroSceneSettings | null
  supportPhone: string
  whatsapp: string
  supportEmail: string
  address: string
  workingHours: string
  social: {
    facebook: string
    instagram: string
    tiktok: string
    youtube: string
  }
  /** raw settings map for anything else */
  raw: Record<string, string>
}

/**
 * Default logo size — applied when no DB setting exists.
 * Matches the original <img> height in the header (h-9 = 36px).
 * (Re-exported from @/lib/logo-config — see file for the actual definition.)
 */

/**
 * Unified branding — reads everything from site_settings (DB) with env/code
 * fallbacks. Used by header, footer, contact page, help page, 404, SEO.
 * Cached via the settings service (unstable_cache, 60s revalidate).
 *
 * Priority: page-specific SEO > product-specific SEO > branding defaults > siteConfig.
 * This function returns the "branding defaults" layer.
 */
export async function getBranding(): Promise<Branding> {
  let s: Record<string, string> = {}
  try {
    s = await getPublicSettings()
  } catch {
    // DB unreachable — use code defaults
  }
  return {
    siteName: s.site_name || siteConfig.name,
    tagline: s.site_tagline || siteConfig.tagline,
    description: s.site_description || siteConfig.description,
    logoUrl: s.site_logo_url || null,
    logoAlt: s.site_name || siteConfig.name,
    faviconUrl: s.favicon_url || null,
    faviconCacheBust: s.favicon_cache_bust || null,
    primaryColor: s.primary_color || '#EA580C',
    accentColor: s.accent_color || '#15803D',
    logoSize: parseLogoSize(s.logo_size),
    logoMotion: parseLogoMotion(s.logo_motion),
    logoVisual: parseLogoVisual(s.logo_visual),
    logoMobile: parseLogoMobile(s.logo_mobile),
    heroScene: parseHeroScene(s.hero_scene),
    // IMPORTANT: phone & whatsapp come ONLY from the DB (`support_phone`, `whatsapp`).
    // We do NOT fall back to `siteConfig.support.phone` — that's the
    // hardcoded developer placeholder that was showing in production
    // instead of the admin-configured number. When the DB value is empty,
    // we return an empty string and let the UI component hide itself.
    supportPhone: s.support_phone || '',
    whatsapp: s.whatsapp || '',
    supportEmail: s.support_email || siteConfig.support.email,
    address: s.address || siteConfig.support.address,
    workingHours: s.working_hours || 'Lun–Sam 9h–19h',
    social: {
      facebook: s.social_facebook || siteConfig.social.facebook,
      instagram: s.social_instagram || siteConfig.social.instagram,
      tiktok: s.social_tiktok || '',
      youtube: s.social_youtube || siteConfig.social.youtube,
    },
    raw: s,
  }
}

/**
 * Parse the logo_size JSON setting. Returns null on any error so the
 * caller falls back to DEFAULT_LOGO_SIZE.
 */
function parseLogoSize(raw: string | undefined): LogoSize | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    if (typeof parsed !== 'object' || parsed === null) return null
    return {
      width: typeof parsed.width === 'number' ? clamp(parsed.width, 8, 200) : DEFAULT_LOGO_SIZE.width,
      height: typeof parsed.height === 'number' ? clamp(parsed.height, 8, 200) : DEFAULT_LOGO_SIZE.height,
      maintainAspectRatio: typeof parsed.maintainAspectRatio === 'boolean' ? parsed.maintainAspectRatio : true,
    }
  } catch {
    return null
  }
}

/**
 * Parse the logo_motion JSON setting. Returns null on any error.
 */
function parseLogoMotion(raw: string | undefined): LogoMotion | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    if (typeof parsed !== 'object' || parsed === null) return null
    const validTypes: LogoMotionType[] = ['breathe', 'float', 'rotate', 'pulse', 'rotate3d', 'tilt', 'none']
    const result: LogoMotion = {
      type: validTypes.includes(parsed.type) ? parsed.type : DEFAULT_LOGO_MOTION.type,
      speed: [0.5, 1, 2].includes(parsed.speed) ? parsed.speed : DEFAULT_LOGO_MOTION.speed,
      intensity: [0.3, 0.5, 0.8].includes(parsed.intensity) ? parsed.intensity : DEFAULT_LOGO_MOTION.intensity,
    }
    // Optional 3D fields
    if (typeof parsed.rotateX === 'number') result.rotateX = clamp(parsed.rotateX, 0, 360)
    if (typeof parsed.rotateY === 'number') result.rotateY = clamp(parsed.rotateY, 0, 360)
    if (typeof parsed.rotateZ === 'number') result.rotateZ = clamp(parsed.rotateZ, 0, 360)
    if (typeof parsed.perspective === 'number') result.perspective = clamp(parsed.perspective, 300, 2000)
    if (['horizontal', 'vertical', 'both'].includes(parsed.tiltDirection)) result.tiltDirection = parsed.tiltDirection
    return result
  } catch {
    return null
  }
}

/**
 * Parse the logo_visual JSON setting (shadow/glow/border/background/radius/padding).
 * Returns null on any error so the caller falls back to DEFAULT_LOGO_VISUAL.
 */
function parseLogoVisual(raw: string | undefined): LogoVisual | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    if (typeof parsed !== 'object' || parsed === null) return null
    const v: LogoVisual = {
      shadow: null,
      glow: null,
      border: null,
      background: null,
      borderRadius: typeof parsed.borderRadius === 'number' ? clamp(parsed.borderRadius, 0, 50) : DEFAULT_LOGO_VISUAL.borderRadius,
      padding: typeof parsed.padding === 'number' ? clamp(parsed.padding, 0, 20) : DEFAULT_LOGO_VISUAL.padding,
    }
    if (parsed.shadow && typeof parsed.shadow === 'object') {
      v.shadow = {
        color: typeof parsed.shadow.color === 'string' ? parsed.shadow.color : 'rgba(0,0,0,0.15)',
        blur: typeof parsed.shadow.blur === 'number' ? clamp(parsed.shadow.blur, 0, 30) : 6,
        offsetX: typeof parsed.shadow.offsetX === 'number' ? clamp(parsed.shadow.offsetX, -10, 10) : 0,
        offsetY: typeof parsed.shadow.offsetY === 'number' ? clamp(parsed.shadow.offsetY, -10, 10) : 2,
      }
    }
    if (parsed.glow && typeof parsed.glow === 'object') {
      v.glow = {
        color: typeof parsed.glow.color === 'string' ? parsed.glow.color : '#EA580C',
        blur: typeof parsed.glow.blur === 'number' ? clamp(parsed.glow.blur, 0, 40) : 12,
        intensity: typeof parsed.glow.intensity === 'number' ? clamp(parsed.glow.intensity, 0, 1) : 0.5,
      }
    }
    if (parsed.border && typeof parsed.border === 'object') {
      v.border = {
        color: typeof parsed.border.color === 'string' ? parsed.border.color : '#E5E5E5',
        width: typeof parsed.border.width === 'number' ? clamp(parsed.border.width, 0, 5) : 1,
        style: ['solid', 'dashed', 'dotted'].includes(parsed.border.style) ? parsed.border.style : 'solid',
      }
    }
    if (parsed.background && typeof parsed.background === 'object') {
      v.background = {
        color: typeof parsed.background.color === 'string' ? parsed.background.color : 'transparent',
        opacity: typeof parsed.background.opacity === 'number' ? clamp(parsed.background.opacity, 0, 1) : 1,
      }
    }
    return v
  } catch {
    return null
  }
}

/**
 * Parse the logo_mobile JSON setting (independent animation disable, separate size).
 * Returns null on any error so the caller falls back to DEFAULT_LOGO_MOBILE.
 */
function parseLogoMobile(raw: string | undefined): LogoMobile | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    if (typeof parsed !== 'object' || parsed === null) return null
    const m: LogoMobile = {
      disableAnimation: typeof parsed.disableAnimation === 'boolean' ? parsed.disableAnimation : false,
      size: null,
      breakpoint: typeof parsed.breakpoint === 'number' ? clamp(parsed.breakpoint, 320, 1024) : 768,
    }
    if (parsed.size && typeof parsed.size === 'object') {
      m.size = {
        width: typeof parsed.size.width === 'number' ? clamp(parsed.size.width, 8, 200) : DEFAULT_LOGO_SIZE.width,
        height: typeof parsed.size.height === 'number' ? clamp(parsed.size.height, 8, 200) : DEFAULT_LOGO_SIZE.height,
        maintainAspectRatio: typeof parsed.size.maintainAspectRatio === 'boolean' ? parsed.size.maintainAspectRatio : true,
      }
    }
    return m
  } catch {
    return null
  }
}

/**
 * Parse the hero_scene JSON setting (3D scene controls for the homepage).
 * Returns null on any error so the caller falls back to defaults.
 */
function parseHeroScene(raw: string | undefined): HeroSceneSettings | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    if (typeof parsed !== 'object' || parsed === null) return null
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : true,
      enabledMobile: typeof parsed.enabledMobile === 'boolean' ? parsed.enabledMobile : false,
      rotationSpeed: typeof parsed.rotationSpeed === 'number' ? clamp(parsed.rotationSpeed, 0, 3) : 0.4,
      autoRotate: typeof parsed.autoRotate === 'boolean' ? parsed.autoRotate : true,
      showZMark: typeof parsed.showZMark === 'boolean' ? parsed.showZMark : true,
      showBearing: typeof parsed.showBearing === 'boolean' ? parsed.showBearing : true,
      showBillet: typeof parsed.showBillet === 'boolean' ? parsed.showBillet : true,
      showHexNut: typeof parsed.showHexNut === 'boolean' ? parsed.showHexNut : true,
      showWasher: typeof parsed.showWasher === 'boolean' ? parsed.showWasher : true,
      zMarkColor: typeof parsed.zMarkColor === 'string' ? parsed.zMarkColor : '#1A1410',
      brassColor: typeof parsed.brassColor === 'string' ? parsed.brassColor : '#9A6A1E',
      clayColor: typeof parsed.clayColor === 'string' ? parsed.clayColor : '#B23A0E',
      creamColor: typeof parsed.creamColor === 'string' ? parsed.creamColor : '#FFFCF7',
      backgroundColor: typeof parsed.backgroundColor === 'string' ? parsed.backgroundColor : 'transparent',
      ambientIntensity: typeof parsed.ambientIntensity === 'number' ? clamp(parsed.ambientIntensity, 0, 2) : 0.35,
      keyLightIntensity: typeof parsed.keyLightIntensity === 'number' ? clamp(parsed.keyLightIntensity, 0, 4) : 1.8,
      scale: typeof parsed.scale === 'number' ? clamp(parsed.scale, 0.3, 2) : 1,
      cameraDistance: typeof parsed.cameraDistance === 'number' ? clamp(parsed.cameraDistance, 3, 10) : 5.5,
      // === NEW: texture, position, opacity, rotation ===
      zMarkTextureUrl: typeof parsed.zMarkTextureUrl === 'string' ? parsed.zMarkTextureUrl : '',
      positionX: typeof parsed.positionX === 'number' ? clamp(parsed.positionX, -3, 3) : 0,
      positionY: typeof parsed.positionY === 'number' ? clamp(parsed.positionY, -3, 3) : 0,
      opacity: typeof parsed.opacity === 'number' ? clamp(parsed.opacity, 0.1, 1) : 1,
      initialRotationY: typeof parsed.initialRotationY === 'number' ? clamp(parsed.initialRotationY, -180, 180) : -25,
    }
  } catch {
    return null
  }
}

/**
 * 3D hero scene settings — stored as JSON in site_settings.hero_scene.
 * All fields are optional with defaults; partial JSON is valid.
 */
export interface HeroSceneSettings {
  enabled: boolean
  enabledMobile: boolean
  rotationSpeed: number
  autoRotate: boolean
  showZMark: boolean
  showBearing: boolean
  showBillet: boolean
  showHexNut: boolean
  showWasher: boolean
  zMarkColor: string
  brassColor: string
  clayColor: string
  creamColor: string
  backgroundColor: string
  ambientIntensity: number
  keyLightIntensity: number
  scale: number
  cameraDistance: number
  // === NEW fields ===
  /** Optional texture image URL applied to the Z mark. Empty = solid color. */
  zMarkTextureUrl: string
  /** Scene horizontal offset (-3 to 3). Default 0 */
  positionX: number
  /** Scene vertical offset (-3 to 3). Default 0 */
  positionY: number
  /** Overall scene opacity (0.1 to 1). Default 1 */
  opacity: number
  /** Initial Y rotation of the Z mark in degrees (-180 to 180). Default -25 */
  initialRotationY: number
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n))
}

/**
 * Google Search Console verification meta tag — read from DB (private setting).
 * Returns null when not configured. Used in root layout to inject the
 * `<meta name="google-site-verification">` tag.
 *
 * Note: this setting is `isPublic=false` (it never gets returned by
 * `getPublicSettings`), so we read it directly via `getSetting` here.
 * The meta tag value itself is NOT a secret — Google publishes it in the
 * verification HTML — but we keep it server-side to avoid exposing it as
 * part of the public settings bundle.
 */
export async function getGscVerificationToken(): Promise<string | null> {
  try {
    return await getSetting('gsc_verification_token')
  } catch {
    return null
  }
}
