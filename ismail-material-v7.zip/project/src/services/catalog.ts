import { db } from '@/lib/db'
import type { ProductCard, ProductDetail } from '@/types'
import { unstable_cache } from 'next/cache'

// In-memory cache for catalog reads (cheap, server-only).
// Revalidate tag used for on-demand invalidation from admin writes.
const listCache = unstable_cache(
  async (opts: { take: number; featured?: boolean; bestSeller?: boolean; newArrival?: boolean; categoryId?: string }) => {
    const where = {
      status: 'PUBLISHED' as const,
      ...(opts.categoryId ? { categoryId: opts.categoryId } : {}),
      ...(opts.featured ? { isFeatured: true } : {}),
      ...(opts.bestSeller ? { isBestSeller: true } : {}),
      ...(opts.newArrival ? { isNewArrival: true } : {}),
    }
    const products = await db.product.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: opts.take,
      include: {
        brand: { select: { id: true, slug: true, name: true } },
        category: { select: { id: true, slug: true, name: true } },
        images: { where: { isMain: true }, take: 1, orderBy: { sortOrder: 'asc' } },
      },
    })
    return products.map(toCard)
  },
  ['catalog-list'],
  { revalidate: 60, tags: ['catalog'] },
)

export async function getFeaturedProducts(take = 8): Promise<ProductCard[]> {
  return listCache({ take, featured: true })
}

export async function getBestSellers(take = 8): Promise<ProductCard[]> {
  return listCache({ take, bestSeller: true })
}

export async function getNewArrivals(take = 8): Promise<ProductCard[]> {
  return listCache({ take, newArrival: true })
}

export async function getAllProducts(take = 24): Promise<ProductCard[]> {
  return listCache({ take })
}

export async function getProductsByCategory(slug: string, take = 24): Promise<ProductCard[]> {
  const category = await db.category.findUnique({ where: { slug }, select: { id: true } })
  if (!category) return []
  return listCache({ take, categoryId: category.id })
}

export async function searchProducts(query: string, take = 24): Promise<ProductCard[]> {
  const q = query.trim()
  if (!q) return []
  const products = await db.product.findMany({
    where: {
      status: 'PUBLISHED',
      OR: [
        { name: { contains: q, mode: 'insensitive' } },
        { nameAr: { contains: q, mode: 'insensitive' } },
        { sku: { contains: q, mode: 'insensitive' } },
        { shortDescription: { contains: q, mode: 'insensitive' } },
      ],
    },
    orderBy: [{ salesCount: 'desc' }, { createdAt: 'desc' }],
    take,
    include: {
      brand: { select: { id: true, slug: true, name: true } },
      category: { select: { id: true, slug: true, name: true } },
      images: { where: { isMain: true }, take: 1, orderBy: { sortOrder: 'asc' } },
    },
  })
  return products.map(toCard)
}

export async function getProductBySlug(slug: string): Promise<ProductDetail | null> {
  const product = await db.product.findUnique({
    where: { slug },
    include: {
      images: { orderBy: { sortOrder: 'asc' } },
      brand: true,
      category: true,
      variants: { where: { isActive: true } },
      reviews: { where: { status: 'APPROVED' }, orderBy: { createdAt: 'desc' }, take: 20 },
    },
  })
  if (!product) return null
  // increment view count (fire and forget)
  db.product.update({ where: { id: product.id }, data: { viewCount: { increment: 1 } } }).catch(() => {})
  return product as ProductDetail
}

export async function getRelatedProducts(productId: string, take = 4): Promise<ProductCard[]> {
  const product = await db.product.findUnique({
    where: { id: productId },
    select: { categoryId: true, relatedIds: true },
  })
  if (!product) return []
  const relatedIds = Array.isArray(product.relatedIds) ? (product.relatedIds as string[]) : []
  if (relatedIds.length) {
    const related = await db.product.findMany({
      where: { id: { in: relatedIds }, status: 'PUBLISHED' },
      take,
      include: {
        brand: { select: { id: true, slug: true, name: true } },
        category: { select: { id: true, slug: true, name: true } },
        images: { where: { isMain: true }, take: 1, orderBy: { sortOrder: 'asc' } },
      },
    })
    return related.map(toCard)
  }
  // fallback: same category, exclude self
  const sameCat = await db.product.findMany({
    where: { categoryId: product.categoryId, status: 'PUBLISHED', NOT: { id: productId } },
    take,
    orderBy: { salesCount: 'desc' },
    include: {
      brand: { select: { id: true, slug: true, name: true } },
      category: { select: { id: true, slug: true, name: true } },
      images: { where: { isMain: true }, take: 1, orderBy: { sortOrder: 'asc' } },
    },
  })
  return sameCat.map(toCard)
}

export async function getCategories() {
  return unstable_cache(
    async () => {
      return db.category.findMany({
        where: { isVisible: true },
        orderBy: { sortOrder: 'asc' },
        select: {
          id: true,
          slug: true,
          name: true,
          nameAr: true,
          description: true,
          imageUrl: true,
          parentId: true,
          sortOrder: true,
          _count: { select: { products: { where: { status: 'PUBLISHED' } } } },
        },
      })
    },
    ['categories-list'],
    { revalidate: 60, tags: ['catalog'] },
  )()
}

export async function getBrands() {
  return unstable_cache(
    async () => {
      return db.brand.findMany({
        where: { isVisible: true },
        orderBy: { sortOrder: 'asc' },
        select: {
          id: true,
          slug: true,
          name: true,
          logoUrl: true,
          _count: { select: { products: { where: { status: 'PUBLISHED' } } } },
        },
      })
    },
    ['brands-list'],
    { revalidate: 60, tags: ['catalog'] },
  )()
}

export async function getCountries() {
  return unstable_cache(
    async () => {
      return db.country.findMany({
        where: { isEnabled: true },
        orderBy: [{ isDefault: 'desc' }, { sortOrder: 'asc' }],
      })
    },
    ['countries-list'],
    { revalidate: 60, tags: ['catalog'] },
  )()
}

export async function getDefaultCountry() {
  return unstable_cache(
    async () => {
      return (
        (await db.country.findFirst({ where: { isDefault: true } })) ??
        (await db.country.findFirst({ where: { code: 'MA' } }))
      )
    },
    ['default-country'],
    { revalidate: 60, tags: ['catalog'] },
  )()
}

// ---- helpers ----
function toCard(p: any): ProductCard {
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    sku: p.sku,
    price: Number(p.price),
    compareAtPrice: p.compareAtPrice ? Number(p.compareAtPrice) : null,
    currencyCode: p.currencyCode,
    stockQuantity: p.stockQuantity,
    trackInventory: p.trackInventory,
    allowBackorder: p.allowBackorder,
    isFeatured: p.isFeatured,
    isBestSeller: p.isBestSeller,
    isNewArrival: p.isNewArrival,
    rating: p.rating ? Number(p.rating) : null,
    reviewCount: p.reviewCount,
    shortDescription: p.shortDescription,
    mainImage: p.images?.[0]
      ? {
          url: p.images[0].url,
          secureUrl: p.images[0].secureUrl,
          publicId: p.images[0].publicId,
          altText: p.images[0].altText,
        }
      : null,
    brand: p.brand ? { id: p.brand.id, slug: p.brand.slug, name: p.brand.name } : null,
    category: p.category ? { id: p.category.id, slug: p.category.slug, name: p.category.name } : null,
  }
}

export { toCard }
