import { db } from '@/lib/db'
import type { CartItemInput, CartLine, CreateOrderInput, OrderResult } from '@/types'
import { nextOrderNumber } from '@/lib/format'
import { revalidateTag } from 'next/cache'

/**
 * Server-side price/stock validation. Never trust client-provided prices.
 * Resolves each cart line from the DB, recomputes unit price, enforces stock.
 */
export async function resolveCartLines(
  items: CartItemInput[],
): Promise<{ ok: true; lines: CartLine[] } | { ok: false; error: string }> {
  if (!items?.length) return { ok: false, error: 'Panier vide.' }
  const productIds = items.map((i) => i.productId)
  const products = await db.product.findMany({
    where: { id: { in: productIds }, status: 'PUBLISHED' },
    include: { images: { where: { isMain: true }, take: 1 } },
  })

  const lines: CartLine[] = []
  for (const item of items) {
    const product = products.find((p) => p.id === item.productId)
    if (!product) return { ok: false, error: `Produit introuvable: ${item.productId}` }

    let unitPrice = Number(product.price)
    let variantName: string | undefined
    let stockQuantity = product.stockQuantity
    let trackInventory = product.trackInventory
    let allowBackorder = product.allowBackorder

    if (item.variantId) {
      const variant = await db.productVariant.findUnique({ where: { id: item.variantId } })
      if (!variant || !variant.isActive) {
        return { ok: false, error: 'Variante indisponible.' }
      }
      unitPrice = Number(product.price) + Number(variant.priceDelta ?? 0)
      variantName = variant.name
      stockQuantity = variant.stockQuantity
    }

    if (trackInventory && !allowBackorder && item.quantity > stockQuantity) {
      return {
        ok: false,
        error: `Stock insuffisant pour « ${product.name} » (disponible: ${stockQuantity}).`,
      }
    }

    lines.push({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      sku: product.sku,
      variantId: item.variantId ?? null,
      variantName: variantName ?? null,
      unitPrice,
      quantity: item.quantity,
      lineTotal: unitPrice * item.quantity,
      image: product.images[0]?.secureUrl ?? product.images[0]?.url ?? null,
      stockQuantity,
      trackInventory,
      allowBackorder,
      currencyCode: product.currencyCode,
    })
  }
  return { ok: true, lines }
}

export async function createOrder(
  input: CreateOrderInput & { customFields?: Record<string, string>; idempotencyKey?: string },
): Promise<OrderResult> {
  // 0. Idempotency check — if a previous request with the same key already
  //    created an order, return that order instead of creating a duplicate.
  //    This makes double-clicks and page refreshes safe.
  if (input.idempotencyKey) {
    const existing = await db.order.findUnique({
      where: { idempotencyKey: input.idempotencyKey },
      include: { items: true, country: true },
    })
    if (existing) {
      return {
        ok: true,
        order: {
          id: existing.id,
          number: existing.number,
          total: Number(existing.total),
          subtotal: Number(existing.subtotal),
          shippingCost: Number(existing.shippingCost),
          discountTotal: Number(existing.discountTotal),
          currencyCode: existing.currencyCode,
          status: existing.status,
          items: existing.items.map((i) => ({
            name: i.productName,
            quantity: i.quantity,
            lineTotal: Number(i.lineTotal),
          })),
        },
      }
    }
  }

  // 1. Resolve the country. If the admin deactivated the `country` OrderField
  //    (so the user couldn't pick one) OR no countryId was provided, fall back
  //    to the default country. The Order schema requires countryId (NOT NULL
  //    foreign key) so we MUST have one. We never reject an otherwise-valid
  //    order just because the country field was hidden from the form.
  let countryId = input.countryId
  if (!countryId) {
    const defaultCountry = await db.country.findFirst({
      where: { isDefault: true, isEnabled: true },
    }) || await db.country.findFirst({ where: { isEnabled: true } })
    if (!defaultCountry) {
      return { ok: false, error: 'لا توجد دولة متاحة للطلب. تواصل مع الدعم.' }
    }
    countryId = defaultCountry.id
  }
  const country = await db.country.findUnique({ where: { id: countryId } })
  if (!country || !country.isEnabled) {
    return { ok: false, error: 'الدولة غير متاحة للطلب.' }
  }

  // 2. resolve cart server-side (price/stock validation — NEVER trust client)
  const resolved = await resolveCartLines(input.items)
  if (!resolved.ok) return { ok: false, error: resolved.error }
  const lines = resolved.lines

  const subtotal = lines.reduce((s, l) => s + l.lineTotal, 0)
  const shippingCost = Number(country.shippingBase ?? 0)
  // coupon
  let discountTotal = 0
  let couponCode: string | null = null
  if (input.couponCode) {
    const coupon = await db.coupon.findUnique({ where: { code: input.couponCode.toUpperCase() } })
    if (coupon && coupon.isActive && coupon.startDate <= new Date() && (!coupon.endDate || coupon.endDate > new Date()) && (!coupon.usageLimit || coupon.usedCount < coupon.usageLimit) && (!coupon.minimumOrder || subtotal >= Number(coupon.minimumOrder))) {
      couponCode = coupon.code
      if (coupon.discountType === 'PERCENTAGE') {
        discountTotal = (subtotal * Number(coupon.discountValue)) / 100
        if (coupon.maximumDiscount && discountTotal > Number(coupon.maximumDiscount)) {
          discountTotal = Number(coupon.maximumDiscount)
        }
      } else if (coupon.discountType === 'FIXED') {
        discountTotal = Number(coupon.discountValue)
      } else if (coupon.discountType === 'FREE_SHIPPING') {
        discountTotal = 0 // applied to shipping instead
      }
      discountTotal = Math.min(discountTotal, subtotal)
    }
  }
  const taxTotal = 0 // VAT not yet configured
  const total = subtotal - discountTotal + shippingCost + taxTotal

  // 3. find or create customer.
  //    Look up by phone+country when phone is non-empty. If not found OR
  //    phone is empty, create a fresh customer record. NEVER look up by
  //    empty phone (would match the first random customer with empty phone
  //    in the same country → data privacy issue + order attaches to wrong
  //    person).
  const phoneForLookup = input.customerPhone?.trim() || ''
  let customer
  if (phoneForLookup) {
    customer = await db.customer.findFirst({
      where: { phone: input.customerPhone, countryId: country.id },
    })
  }
  if (!customer) {
    customer = await db.customer.create({
      data: {
        fullName: input.customerFullName,
        phone: input.customerPhone || null,
        email: input.customerEmail || null,
        countryId: country.id,
      },
    })
  }

  // 4. count existing orders for number sequence
  const orderCount = await db.order.count()
  const number = nextOrderNumber(orderCount)

  // 5. create order + items + status history + decrement stock inside a
  //    transaction. If any step fails, the whole order is rolled back —
  //    we never end up with an order without items, or stock decremented
  //    for an order that didn't persist. The idempotency key is stored
  //    so a retry returns the same order.
  const order = await db.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        number,
        idempotencyKey: input.idempotencyKey || null,
        customerId: customer.id,
        customerFullName: input.customerFullName,
        customerPhone: input.customerPhone,
        customerEmail: input.customerEmail || null,
        countryId: country.id,
        shippingCity: input.shippingCity,
        shippingAddress: input.shippingAddress,
        shippingPostalCode: input.shippingPostalCode || null,
        notes: input.notes || null,
        subtotal,
        shippingCost,
        discountTotal,
        taxTotal,
        total,
        currencyCode: country.currencyCode,
        status: 'NEW',
        paymentMethod: 'COD',
        paymentStatus: 'UNPAID',
        couponCode,
        customFields: (input.customFields || {}) as any,
        ip: input.ip,
        userAgent: input.userAgent,
        items: {
          create: lines.map((l) => ({
            productId: l.productId,
            productName: l.name,
            productSku: l.sku,
            productImage: l.image,
            variantId: l.variantId,
            variantName: l.variantName,
            unitPrice: l.unitPrice,
            quantity: l.quantity,
            lineTotal: l.lineTotal,
          })),
        },
        statusHistory: {
          create: { status: 'NEW', note: 'Commande reçue' },
        },
      },
      include: { items: true },
    })

    // decrement inventory + increment salesCount atomically inside the tx
    await Promise.all(
      lines.map((l) =>
        tx.product.update({
          where: { id: l.productId },
          data: {
            stockQuantity: l.trackInventory ? { decrement: l.quantity } : undefined,
            salesCount: { increment: l.quantity },
          },
        }).catch(() => {}),
      ),
    )

    if (couponCode) {
      await tx.coupon.update({
        where: { code: couponCode },
        data: { usedCount: { increment: 1 } },
      }).catch(() => {})
    }

    return created
  })

  revalidateTag('catalog')

  return {
    ok: true,
    order: {
      id: order.id,
      number: order.number,
      total: Number(order.total),
      subtotal: Number(order.subtotal),
      shippingCost: Number(order.shippingCost),
      discountTotal: Number(order.discountTotal),
      currencyCode: order.currencyCode,
      status: order.status,
      items: order.items.map((i) => ({
        name: i.productName,
        quantity: i.quantity,
        lineTotal: Number(i.lineTotal),
      })),
    },
  }
}

export async function updateOrderStatus(
  orderId: string,
  status: import('@prisma/client').OrderStatus,
  adminId: string,
  note?: string,
) {
  const updated = await db.order.update({
    where: { id: orderId },
    data: {
      status,
      confirmedAt: status === 'CONFIRMED' ? new Date() : undefined,
      shippedAt: status === 'SHIPPED' ? new Date() : undefined,
      deliveredAt: status === 'DELIVERED' ? new Date() : undefined,
      cancelledAt: status === 'CANCELLED' ? new Date() : undefined,
      statusHistory: { create: { status, note, adminUserId: adminId } },
    },
    include: { items: true },
  })
  // restore stock if cancelled
  if (status === 'CANCELLED') {
    await Promise.all(
      updated.items.map((i) =>
        db.product.update({
          where: { id: i.productId },
          data: { stockQuantity: { increment: i.quantity }, salesCount: { decrement: i.quantity } },
        }).catch(() => {}),
      ),
    )
  }
  revalidateTag('catalog')
  return updated
}
