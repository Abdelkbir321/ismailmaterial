/**
 * Edge proxy (formerly "middleware" in Next.js ≤15) — handles DB-defined
 * 301/302 redirects.
 *
 * WHY THIS EXISTS
 * ---------------
 * Before this file, the `Redirect` table was managed from the admin UI and
 * written to the DB, but the redirects were NEVER enforced by the runtime.
 * Visitors hitting an old slug got a 404 instead of being redirected.
 *
 * This middleware runs on every request at the edge. It fetches the active
 * redirects list from a cached API endpoint (`/api/redirects`, 60s
 * `unstable_cache` + `revalidateTag('redirects')` from the admin CRUD)
 * and applies them with the proper status code (301 or 302).
 *
 * ARCHITECTURE
 * ------------
 * - The middleware does NOT hit the DB directly (the DB client cannot run
 *   in the edge runtime). It fetches `/api/redirects`, which is a regular
 *   Node.js route that returns the cached list.
 * - The fetch uses `next: { revalidate: 60 }` so the same edge instance
 *   re-uses the cached list for 60s. Combined with the server-side
 *   `unstable_cache(['redirects-public'], { revalidate: 60 })`, this gives
 *   us a max staleness of ~2 minutes after an admin edits a redirect —
 *   acceptable for SEO redirects.
 * - We do NOT follow redirect chains here — the admin API already prevents
 *   creating loops. The destination is applied verbatim.
 *
 * SECURITY
 * --------
 * - Open redirect protection: the admin API already rejects `toPath` values
 *   that are absolute URLs to a different origin. We re-validate here as a
 *   defense-in-depth: only relative paths starting with `/` are allowed to
 *   be applied as a redirect destination through the middleware.
 * - Loop protection: we refuse to redirect if the destination equals the
 *   source path.
 * - We never set arbitrary headers from the DB.
 *
 * WHAT THIS DOES NOT DO
 * --------------------
 * - It does NOT touch admin routes (`/admin/*`, `/api/admin/*`) — those are
 *   never redirected by DB rules (admin URLs must stay stable).
 * - It does NOT rewrite URLs in-place (no `next.rewrites`) — only true
 *   redirects, because rewrites would hide the canonical URL from Google.
 * - It does NOT touch `/_next/*` or static asset paths.
 */

import { NextResponse, type NextRequest } from 'next/server'

interface RedirectRow {
  fromPath: string
  toPath: string
  statusCode: number
}

// In-edge cache (per instance). Refreshed every 60s via the fetch cache.
let redirectCache: { rows: RedirectRow[]; expiresAt: number } | null = null
const CACHE_TTL_MS = 60 * 1000

async function fetchRedirects(req: NextRequest): Promise<RedirectRow[]> {
  const now = Date.now()
  if (redirectCache && redirectCache.expiresAt > now) {
    return redirectCache.rows
  }
  try {
    // Build an absolute URL for the internal endpoint so the fetch works
    // regardless of the proxy headers Netlify sets.
    const url = new URL('/api/redirects', req.nextUrl.origin).toString()
    const res = await fetch(url, {
      method: 'GET',
      headers: { 'x-internal-proxy': '1' },
      next: { revalidate: 60 },
    })
    if (!res.ok) return redirectCache?.rows ?? []
    const json = (await res.json()) as { ok?: boolean; redirects?: RedirectRow[] }
    const rows = Array.isArray(json.redirects) ? json.redirects : []
    redirectCache = { rows, expiresAt: now + CACHE_TTL_MS }
    return rows
  } catch {
    // Network error or origin not yet ready — fall back to the previous cache
    // (may be empty on a cold start).
    return redirectCache?.rows ?? []
  }
}

function normalizePath(p: string): string {
  // Lowercase the path component but preserve the query string case.
  const [pathOnly, query = ''] = p.split('?')
  const lower = pathOnly.toLowerCase().replace(/\/+$/, '') || '/'
  return query ? `${lower}?${query}` : lower
}

export async function proxy(req: NextRequest) {
  const { pathname, search } = req.nextUrl

  // Google Search Console HTML verification file: matches `google*.html` at
  // the site root. We rewrite the request to /api/gsc-verify which serves
  // the file content from the DB setting (super-admin editable).
  // Pattern is strict: must start with `google`, end with `.html`, and
  // contain only [a-z0-9] in between.
  if (/^\/google[a-z0-9]+\.html$/i.test(pathname)) {
    const url = req.nextUrl.clone()
    url.pathname = '/api/gsc-verify'
    url.search = ''
    return NextResponse.rewrite(url)
  }

  // NEVER redirect admin/API/static paths.
  if (
    pathname.startsWith('/admin') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/_next') ||
    pathname === '/favicon.ico' ||
    pathname === '/robots.txt' ||
    pathname === '/sitemap.xml' ||
    pathname === '/health'
  ) {
    return NextResponse.next()
  }

  const rows = await fetchRedirects(req)
  if (rows.length === 0) return NextResponse.next()

  // Normalize the incoming path for matching (case-insensitive, trailing
  // slashes stripped). The `fromPath` in the DB is already stored lowercased
  // and trailing-slash-stripped by the admin API.
  const normalized = normalizePath(pathname + search)

  // Try exact match first, then path-only match (without query string).
  const match =
    rows.find((r) => normalizePath(r.fromPath) === normalized) ||
    rows.find((r) => normalizePath(r.fromPath) === normalizePath(pathname))

  if (!match) return NextResponse.next()

  // Defense-in-depth: refuse self-redirects and absolute external URLs that
  // somehow slipped through (the admin API already rejects them).
  if (match.fromPath === match.toPath) return NextResponse.next()
  if (!match.toPath.startsWith('/')) {
    // If it's an absolute URL to the same origin, allow it; otherwise skip.
    try {
      const siteUrl = process.env.NEXT_PUBLIC_SITE_URL
      if (!siteUrl) return NextResponse.next()
      const site = new URL(siteUrl)
      const to = new URL(match.toPath)
      if (to.origin !== site.origin) return NextResponse.next()
    } catch {
      return NextResponse.next()
    }
  }

  // Build the destination URL preserving the query string of the request
  // (only if the destination is a relative path without its own query).
  let dest = match.toPath
  if (search && dest.startsWith('/') && !dest.includes('?')) {
    dest = `${dest}${search}`
  }

  const redirectUrl = new URL(dest, req.nextUrl.origin)
  return NextResponse.redirect(redirectUrl, {
    status: match.statusCode === 302 ? 302 : 301,
  })
}

export const config = {
  // Run on every path EXCEPT Next internals & static asset file extensions.
  // The runtime check above handles admin/api/static exclusion explicitly.
  // The matcher here is a first-pass performance filter so we don't even
  // invoke the function for static assets.
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|.*\\.(?:png|jpg|jpeg|gif|webp|avif|svg|ico|css|js|woff|woff2|ttf|otf|map)$).*)',
  ],
}
