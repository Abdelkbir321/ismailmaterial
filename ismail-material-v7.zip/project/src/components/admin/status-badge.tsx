import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { classForStatus } from '@/lib/format'

const PRODUCT_STATUS_CLASS: Record<string, string> = {
  DRAFT: 'bg-zinc-100 text-zinc-700 ring-zinc-600/20',
  PUBLISHED: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  ARCHIVED: 'bg-zinc-100 text-zinc-500 ring-zinc-600/20',
  OUT_OF_STOCK: 'bg-rose-50 text-rose-700 ring-rose-600/20',
}

const PAYMENT_STATUS_CLASS: Record<string, string> = {
  UNPAID: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  PENDING: 'bg-amber-50 text-amber-700 ring-amber-600/20',
  PAID: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  REFUNDED: 'bg-orange-50 text-orange-700 ring-orange-600/20',
  FAILED: 'bg-zinc-100 text-zinc-600 ring-zinc-600/20',
}

const ORDER_STATUS_LABEL: Record<string, string> = {
  NEW: 'جديدة',
  CONTACTED: 'تم التواصل',
  CONFIRMED: 'مؤكدة',
  PROCESSING: 'قيد التحضير',
  SHIPPED: 'تم الشحن',
  DELIVERED: 'تم التسليم',
  CANCELLED: 'ملغاة',
  RETURNED: 'مُعادة',
  UNREACHABLE: 'غير قابلة للوصول',
}

const PRODUCT_STATUS_LABEL: Record<string, string> = {
  DRAFT: 'مسودة',
  PUBLISHED: 'منشور',
  ARCHIVED: 'مؤرشف',
  OUT_OF_STOCK: 'نفذ المخزون',
}

const PAYMENT_STATUS_LABEL: Record<string, string> = {
  UNPAID: 'غير مدفوع',
  PENDING: 'قيد الانتظار',
  PAID: 'مدفوع',
  REFUNDED: 'مُسترجع',
  FAILED: 'فشل',
}

export function OrderStatusBadge({ status }: { status: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap',
        classForStatus(status),
      )}
    >
      {ORDER_STATUS_LABEL[status] ?? status}
    </span>
  )
}

export function ProductStatusBadge({ status }: { status: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap',
        PRODUCT_STATUS_CLASS[status] ?? 'bg-zinc-100 text-zinc-700 ring-zinc-600/20',
      )}
    >
      {PRODUCT_STATUS_LABEL[status] ?? status}
    </span>
  )
}

export function PaymentStatusBadge({ status }: { status: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap',
        PAYMENT_STATUS_CLASS[status] ?? 'bg-zinc-100 text-zinc-700 ring-zinc-600/20',
      )}
    >
      {PAYMENT_STATUS_LABEL[status] ?? status}
    </span>
  )
}

export function Badge2({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return <Badge className={className}>{children}</Badge>
}
