'use client'

import * as React from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Tag,
  Globe,
  Settings as SettingsIcon,
  ScrollText,
  Store,
  LogOut,
  ShieldCheck,
  Image as ImageIcon,
  Palette,
  FormInput,
  Users,
  UserCog,
  UserCircle,
  Search as SearchIcon,
  Fingerprint,
} from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'
import {
  Avatar,
  AvatarFallback,
} from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Toaster as SonnerToaster } from '@/components/ui/sonner'

export interface AdminInfo {
  id: string
  email: string
  fullName: string
  role: { name: string; slug: string }
  /** { section: [action, ...] } — present when the admin's role has any permissions set. */
  permissions?: Record<string, string[]>
}

interface NavItem {
  title: string
  href: string
  icon: React.ComponentType<{ className?: string }>
  /** Permission section key — the item only shows if the admin has `view` for it. `undefined` = always visible. */
  section?: string
}

const NAV: NavItem[] = [
  { title: 'الرئيسية', href: '/admin/dashboard', icon: LayoutDashboard, section: 'dashboard' },
  { title: 'المنتجات', href: '/admin/products', icon: Package, section: 'products' },
  { title: 'الطلبات', href: '/admin/orders', icon: ShoppingCart, section: 'orders' },
  { title: 'المخزون', href: '/admin/inventory', icon: Package, section: 'inventory' },
  { title: 'العملاء', href: '/admin/customers', icon: Users, section: 'customers' },
  { title: 'الفئات', href: '/admin/categories', icon: Tag, section: 'categories' },
  { title: 'الماركات', href: '/admin/brands', icon: ShieldCheck, section: 'categories' },
  { title: 'الدول والعملات', href: '/admin/countries', icon: Globe, section: 'countries' },
  { title: 'حقول الطلب', href: '/admin/order-fields', icon: FormInput, section: 'order_fields' },
  { title: 'الوسائط', href: '/admin/media', icon: ImageIcon, section: 'media' },
  { title: 'SEO والروابط', href: '/admin/seo', icon: SearchIcon, section: 'seo' },
  { title: 'الهوية البصرية', href: '/admin/visual-identity', icon: Palette, section: 'store_settings' },
  { title: 'هوية الموقع', href: '/admin/site-identity', icon: Fingerprint, section: 'store_settings' },
  { title: 'لوغو التبويب', href: '/admin/tab-logo', icon: ImageIcon, section: 'store_settings' },
  { title: 'صورة الواجهة الرئيسية', href: '/admin/hero-image', icon: ImageIcon, section: 'store_settings' },
  { title: 'إعدادات المتجر', href: '/admin/settings', icon: SettingsIcon, section: 'store_settings' },
  { title: 'المسؤولون والصلاحيات', href: '/admin/admin-users', icon: UserCog, section: 'admin_users' },
  { title: 'سجل العمليات', href: '/admin/audit-logs', icon: ScrollText, section: 'audit_logs' },
  // Always-visible
  { title: 'حسابي', href: '/admin/my-account', icon: UserCircle },
]

function canSee(item: NavItem, admin: AdminInfo): boolean {
  // "حسابي" is always visible — every admin can edit their own account.
  if (!item.section) return true
  // Super-admin sees everything.
  if (admin.role.slug === 'super-admin') return true
  const perms = admin.permissions
  if (!perms) return false
  const acts = perms[item.section]
  return Array.isArray(acts) && acts.includes('view')
}

function NavList({ pathname, admin }: { pathname: string; admin: AdminInfo }) {
  const visible = NAV.filter((item) => canSee(item, admin))
  return (
    <SidebarGroup>
      <SidebarGroupContent>
        <SidebarMenu>
          {visible.map((item) => {
            const Icon = item.icon
            const isActive =
              pathname === item.href ||
              (item.href !== '/admin/dashboard' && pathname.startsWith(item.href))
            return (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton asChild isActive={isActive} tooltip={item.title}>
                  <Link href={item.href}>
                    <Icon className="size-4" />
                    <span>{item.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            )
          })}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

function BrandHeader() {
  return (
    <SidebarHeader>
      <div className="flex items-center gap-2 px-2 py-3">
        <div className="bg-zinc-900 text-white rounded-lg size-8 flex items-center justify-center font-bold text-sm">
          أ
        </div>
        <div className="leading-tight">
          <p className="text-sm font-semibold">أطلس — لوحة التحكم</p>
          <p className="text-muted-foreground text-[10px] uppercase tracking-wide">
            Admin Console
          </p>
        </div>
      </div>
    </SidebarHeader>
  )
}

function AdminTopbar({ admin }: { admin: AdminInfo }) {
  const router = useRouter()
  const [loading, setLoading] = React.useState(false)

  async function logout() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/auth/logout', {
        method: 'POST',
        credentials: 'include',
      })
      if (!res.ok) throw new Error('فشل')
      toast.success('تم تسجيل الخروج')
      router.push('/admin/login')
      router.refresh()
    } catch {
      toast.error('فشل تسجيل الخروج')
    } finally {
      setLoading(false)
    }
  }

  const initials = (admin.fullName || '?')
    .split(' ')
    .map((s) => s[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()

  return (
    <header className="bg-background/80 sticky top-0 z-30 flex h-14 items-center gap-2 border-b px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <SidebarTrigger />
      <div className="ml-auto flex items-center gap-2">
        <Button asChild variant="ghost" size="sm">
          <Link href="/" target="_blank" rel="noopener noreferrer">
            <Store className="size-4" />
            <span className="hidden sm:inline">عرض المتجر</span>
          </Link>
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-2">
              <Avatar className="size-7">
                <AvatarFallback className="bg-zinc-900 text-white text-xs">
                  {initials || '?'}
                </AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline text-sm font-medium" dir="auto">
                {admin.fullName}
              </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>
              <div className="flex flex-col" dir="rtl">
                <span className="font-medium">{admin.fullName}</span>
                <span className="text-muted-foreground text-xs font-normal" dir="ltr">
                  {admin.email}
                </span>
                <span className="text-muted-foreground text-[10px] mt-1 uppercase tracking-wide">
                  {admin.role.name}
                </span>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/admin/my-account">
                <UserCircle className="size-4" />
                <span>حسابي</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout} disabled={loading}>
              <LogOut className="size-4" />
              <span>تسجيل الخروج</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

export function AdminShell({
  admin,
  children,
}: {
  admin: AdminInfo
  children: React.ReactNode
}) {
  const pathname = usePathname()
  return (
    <SidebarProvider>
      <Sidebar collapsible="icon" className="bg-zinc-50" side="right">
        <BrandHeader />
        <SidebarContent>
          <NavList pathname={pathname} admin={admin} />
        </SidebarContent>
      </Sidebar>
      <SidebarInset>
        <AdminTopbar admin={admin} />
        <main className="flex-1 bg-background p-4 sm:p-6">{children}</main>
      </SidebarInset>
      <SonnerToaster richColors position="top-left" dir="rtl" />
    </SidebarProvider>
  )
}
