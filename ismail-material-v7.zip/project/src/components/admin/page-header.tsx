import { cn } from '@/lib/utils'
import { ChevronRight } from 'lucide-react'
import Link from 'next/link'

export function PageHeader({
  title,
  description,
  actions,
  breadcrumb,
}: {
  title: string
  description?: string
  actions?: React.ReactNode
  breadcrumb?: Array<{ label: string; href?: string }>
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="space-y-1">
        {breadcrumb && breadcrumb.length > 0 && (
          <nav
            aria-label="breadcrumb"
            className="text-muted-foreground flex items-center gap-1 text-xs"
          >
            {breadcrumb.map((b, i) => (
              <span key={i} className="flex items-center gap-1">
                {b.href ? (
                  <Link href={b.href} className="hover:text-foreground">
                    {b.label}
                  </Link>
                ) : (
                  <span>{b.label}</span>
                )}
                {i < breadcrumb.length - 1 && (
                  <ChevronRight className="size-3 opacity-50" />
                )}
              </span>
            ))}
          </nav>
        )}
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {description && (
          <p className="text-muted-foreground text-sm">{description}</p>
        )}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  )
}

export function CardStat({
  label,
  value,
  hint,
  icon,
  accent,
}: {
  label: string
  value: React.ReactNode
  hint?: string
  icon?: React.ReactNode
  accent?: 'emerald' | 'amber' | 'rose' | 'zinc' | 'teal'
}) {
  const accentClass =
    accent === 'emerald'
      ? 'bg-emerald-50 text-emerald-700'
      : accent === 'amber'
        ? 'bg-amber-50 text-amber-700'
        : accent === 'rose'
          ? 'bg-rose-50 text-rose-700'
          : accent === 'teal'
            ? 'bg-teal-50 text-teal-700'
            : 'bg-zinc-100 text-zinc-700'
  return (
    <div className="bg-card border rounded-xl p-4 shadow-sm flex items-start justify-between gap-3">
      <div className="space-y-1">
        <p className="text-muted-foreground text-xs font-medium uppercase tracking-wide">
          {label}
        </p>
        <p className="text-2xl font-semibold tabular-nums">{value}</p>
        {hint && <p className="text-muted-foreground text-xs">{hint}</p>}
      </div>
      {icon && (
        <div className={cn('rounded-lg p-2', accentClass)}>{icon}</div>
      )}
    </div>
  )
}

export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string
  description?: string
  action?: React.ReactNode
  icon?: React.ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed p-10 text-center">
      {icon && (
        <div className="text-muted-foreground/60 bg-muted rounded-full p-3">
          {icon}
        </div>
      )}
      <div className="space-y-1">
        <p className="font-medium">{title}</p>
        {description && (
          <p className="text-muted-foreground text-sm">{description}</p>
        )}
      </div>
      {action}
    </div>
  )
}

export function Spinner() {
  return (
    <div className="flex items-center justify-center p-8">
      <div className="border-primary border-t-transparent size-6 rounded-full border-2 animate-spin" />
    </div>
  )
}
