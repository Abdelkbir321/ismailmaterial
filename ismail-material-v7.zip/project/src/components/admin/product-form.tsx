'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import {
  Loader2,
  Plus,
  Trash2,
  ArrowRight,
  Save,
  Star,
  ImageIcon,
  Upload,
  X,
  ArrowUp,
  ArrowDown,
  Globe,
  Link as LinkIcon,
} from 'lucide-react'

import { slugify } from '@/lib/format'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { productInputSchema } from '@/validations'

interface ProductFormProps {
  mode: 'create' | 'edit'
  productId?: string
}

interface SpecRow {
  key: string
  value: string
}

interface ImageRow {
  id: string
  url: string
  altText: string
  isMain: boolean
  publicId?: string
  assetId?: string
  sourceType?: string // 'cloudinary' | 'external' | 'placeholder'
}

interface Option {
  id: string
  name: string
}

type FormState = {
  name: string
  slug: string
  nameAr: string
  shortDescription: string
  description: string
  sku: string
  barcode: string
  brandId: string
  categoryId: string
  status: string
  price: string
  compareAtPrice: string
  costPrice: string
  currencyCode: string
  taxRate: string
  weightKg: string
  stockQuantity: string
  lowStockThreshold: string
  allowBackorder: boolean
  trackInventory: boolean
  isFeatured: boolean
  isNewArrival: boolean
  isBestSeller: boolean
  seoTitle: string
  seoDescription: string
  ogImage: string
  canonicalUrl: string
  noindex: boolean
  relatedIds: string
  specifications: SpecRow[]
  images: ImageRow[]
}

const DEFAULT_STATE: FormState = {
  name: '',
  slug: '',
  nameAr: '',
  shortDescription: '',
  description: '',
  sku: '',
  barcode: '',
  brandId: '',
  categoryId: '',
  status: 'DRAFT',
  price: '0',
  compareAtPrice: '',
  costPrice: '',
  currencyCode: 'MAD',
  taxRate: '',
  weightKg: '',
  stockQuantity: '0',
  lowStockThreshold: '5',
  allowBackorder: false,
  trackInventory: true,
  isFeatured: false,
  isNewArrival: false,
  isBestSeller: false,
  seoTitle: '',
  seoDescription: '',
  ogImage: '',
  canonicalUrl: '',
  noindex: false,
  relatedIds: '',
  specifications: [],
  images: [],
}

function num(v: string, fallback = 0): number {
  if (v === '' || v === null || v === undefined) return fallback
  const n = Number(v)
  return Number.isNaN(n) ? fallback : n
}

function sourceBadge(sourceType?: string) {
  if (sourceType === 'cloudinary') {
    return (
      <span className="bg-emerald-600 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
        Cloudinary
      </span>
    )
  }
  if (sourceType === 'external') {
    return (
      <span className="bg-orange-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
        رابط خارجي
      </span>
    )
  }
  if (sourceType === 'placeholder') {
    return (
      <span className="bg-zinc-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
        مؤقت
      </span>
    )
  }
  return null
}

export function ProductForm({ mode, productId }: ProductFormProps) {
  const router = useRouter()
  const [state, setState] = React.useState<FormState>(DEFAULT_STATE)
  const [categories, setCategories] = React.useState<Option[]>([])
  const [brands, setBrands] = React.useState<Option[]>([])
  const [loading, setLoading] = React.useState(mode === 'edit')
  const [saving, setSaving] = React.useState(false)
  const [uploading, setUploading] = React.useState(false)
  const [slugTouched, setSlugTouched] = React.useState(mode === 'edit')
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const fileRef = React.useRef<HTMLInputElement>(null)

  // External URL image input state
  const [externalUrl, setExternalUrl] = React.useState('')
  const [externalAlt, setExternalAlt] = React.useState('')
  const [externalPreview, setExternalPreview] = React.useState<string | null>(null)
  const [externalPreviewError, setExternalPreviewError] = React.useState(false)
  const [addingExternal, setAddingExternal] = React.useState(false)

  React.useEffect(() => {
    ;(async () => {
      try {
        const [catRes, brandRes] = await Promise.all([
          fetch('/api/categories', { credentials: 'include' }),
          fetch('/api/brands', { credentials: 'include' }),
        ])
        const catJson = await catRes.json()
        const brandJson = await brandRes.json()
        if (catJson.ok) {
          setCategories(
            (catJson.categories || []).map((c: any) => ({ id: c.id, name: c.name })),
          )
        }
        if (brandJson.ok) {
          setBrands(
            (brandJson.brands || []).map((b: any) => ({ id: b.id, name: b.name })),
          )
        }
      } catch {
        // ignore
      }
    })()
  }, [])

  React.useEffect(() => {
    if (mode !== 'edit' || !productId) return
    let active = true
    ;(async () => {
      try {
        const res = await fetch(`/api/admin/products/${productId}`, {
          credentials: 'include',
        })
        const json = await res.json()
        if (!active) return
        if (!res.ok || !json.ok) {
          toast.error(json.error || 'المنتج غير موجود')
          router.push('/admin/products')
          return
        }
        const p = json.product
        const specs: SpecRow[] = Array.isArray(p.specifications)
          ? p.specifications.map((s: any) => ({
              key: s.key ?? '',
              value: s.value ?? '',
            }))
          : Object.entries(p.specifications || {}).map(([k, v]) => ({
              key: k,
              value: String(v),
            }))
        setState({
          name: p.name || '',
          slug: p.slug || '',
          nameAr: p.nameAr || '',
          shortDescription: p.shortDescription || '',
          description: p.description || '',
          sku: p.sku || '',
          barcode: p.barcode || '',
          brandId: p.brandId || '',
          categoryId: p.categoryId || '',
          status: p.status || 'DRAFT',
          price: String(p.price ?? 0),
          compareAtPrice: p.compareAtPrice ? String(p.compareAtPrice) : '',
          costPrice: p.costPrice ? String(p.costPrice) : '',
          currencyCode: p.currencyCode || 'MAD',
          taxRate: p.taxRate ? String(p.taxRate) : '',
          weightKg: p.weightKg ? String(p.weightKg) : '',
          stockQuantity: String(p.stockQuantity ?? 0),
          lowStockThreshold: String(p.lowStockThreshold ?? 5),
          allowBackorder: p.allowBackorder ?? false,
          trackInventory: p.trackInventory ?? true,
          isFeatured: p.isFeatured ?? false,
          isNewArrival: p.isNewArrival ?? false,
          isBestSeller: p.isBestSeller ?? false,
          seoTitle: p.seoTitle || '',
          seoDescription: p.seoDescription || '',
          ogImage: p.ogImage || '',
          canonicalUrl: p.canonicalUrl || '',
          noindex: p.noindex ?? false,
          relatedIds: Array.isArray(p.relatedIds)
            ? p.relatedIds.join(',')
            : String(p.relatedIds || ''),
          specifications: specs,
          images: (p.images || []).map((im: any) => ({
            id: im.id,
            url: im.secureUrl || im.url,
            altText: im.altText || '',
            isMain: im.isMain ?? false,
            publicId: im.publicId,
            sourceType: im.sourceType,
          })),
        })
      } catch {
        toast.error('خطأ في الشبكة')
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => {
      active = false
    }
  }, [mode, productId, router])

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setState((s) => ({ ...s, [key]: value }))
  }

  function onNameChange(v: string) {
    set('name', v)
    if (!slugTouched) {
      set('slug', slugify(v))
    }
  }

  function addSpec() {
    setState((s) => ({
      ...s,
      specifications: [...s.specifications, { key: '', value: '' }],
    }))
  }
  function updateSpec(i: number, key: 'key' | 'value', v: string) {
    setState((s) => {
      const next = [...s.specifications]
      next[i] = { ...next[i], [key]: v }
      return { ...s, specifications: next }
    })
  }
  function removeSpec(i: number) {
    setState((s) => ({
      ...s,
      specifications: s.specifications.filter((_, idx) => idx !== i),
    }))
  }

  async function uploadFiles(files: FileList | null) {
    if (!files || files.length === 0) return
    if (!productId) {
      toast.info(
        'احفظ المنتج أولاً قبل رفع الصور. يمكنك بعدها إضافتها.',
      )
      return
    }
    setUploading(true)
    try {
      for (const file of Array.from(files)) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('productId', productId)
        if (state.images.length === 0) formData.append('isMain', 'true')
        const res = await fetch('/api/admin/upload', {
          method: 'POST',
          body: formData,
          credentials: 'include',
        })
        const json = await res.json()
        if (!res.ok || !json.ok) {
          toast.error(json.error || 'فشل الرفع')
          continue
        }
        const im = json.image
        const asset = json.asset
        if (im) {
          setState((s) => {
            const images = [...s.images]
            if (im.isMain) {
              images.forEach((i) => (i.isMain = false))
            }
            images.push({
              id: im.id,
              url: im.secureUrl || im.url,
              altText: im.altText || '',
              isMain: im.isMain ?? false,
              publicId: im.publicId,
              sourceType: im.sourceType || asset?.sourceType,
            })
            return { ...s, images }
          })
        }
      }
      toast.success('تم رفع الصور')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  async function addExternalImage() {
    if (!productId) {
      toast.info('احفظ المنتج أولاً قبل إضافة صورة.')
      return
    }
    const url = externalUrl.trim()
    if (!url) {
      toast.error('أدخل رابط الصورة.')
      return
    }
    if (!/^https?:\/\//i.test(url)) {
      toast.error('الرابط غير صالح (يجب أن يبدأ بـ http أو https).')
      return
    }
    setAddingExternal(true)
    try {
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          externalUrl: url,
          productId,
          altText: externalAlt || undefined,
          isMain: state.images.length === 0,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'الرابط لا يشير لصورة صالحة.')
        return
      }
      const im = json.image
      const asset = json.asset
      if (im) {
        setState((s) => {
          const images = [...s.images]
          if (im.isMain) {
            images.forEach((i) => (i.isMain = false))
          }
          images.push({
            id: im.id,
            url: im.secureUrl || im.url,
            altText: im.altText || externalAlt,
            isMain: im.isMain ?? false,
            publicId: im.publicId,
            sourceType: im.sourceType || asset?.sourceType || 'external',
          })
          return { ...s, images }
        })
      }
      toast.success('تمت إضافة الصورة')
      setExternalUrl('')
      setExternalAlt('')
      setExternalPreview(null)
      setExternalPreviewError(false)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setAddingExternal(false)
    }
  }

  function previewExternal() {
    setExternalPreviewError(false)
    setExternalPreview(externalUrl.trim())
  }

  function setMainImage(id: string) {
    setState((s) => ({
      ...s,
      images: s.images.map((i) => ({ ...i, isMain: i.id === id })),
    }))
  }

  function moveImage(i: number, dir: -1 | 1) {
    setState((s) => {
      const images = [...s.images]
      const j = i + dir
      if (j < 0 || j >= images.length) return s
      ;[images[i], images[j]] = [images[j], images[i]]
      return { ...s, images }
    })
  }

  function buildPayload() {
    return {
      name: state.name,
      slug: state.slug,
      nameAr: state.nameAr,
      shortDescription: state.shortDescription,
      description: state.description,
      sku: state.sku,
      barcode: state.barcode,
      brandId: state.brandId || null,
      categoryId: state.categoryId,
      status: state.status as 'DRAFT' | 'PUBLISHED' | 'ARCHIVED' | 'OUT_OF_STOCK',
      price: num(state.price, 0),
      compareAtPrice: state.compareAtPrice ? num(state.compareAtPrice, 0) : null,
      costPrice: state.costPrice ? num(state.costPrice, 0) : null,
      currencyCode: state.currencyCode,
      taxRate: state.taxRate ? num(state.taxRate, 0) : null,
      weightKg: state.weightKg ? num(state.weightKg, 0) : null,
      stockQuantity: num(state.stockQuantity, 0),
      lowStockThreshold: num(state.lowStockThreshold, 5),
      allowBackorder: state.allowBackorder,
      trackInventory: state.trackInventory,
      isFeatured: state.isFeatured,
      isNewArrival: state.isNewArrival,
      isBestSeller: state.isBestSeller,
      specifications: state.specifications.filter((s) => s.key),
      faq: [],
      relatedIds: state.relatedIds
        .split(',')
        .map((x) => x.trim())
        .filter(Boolean),
      seoTitle: state.seoTitle,
      seoDescription: state.seoDescription,
      ogImage: state.ogImage,
      canonicalUrl: state.canonicalUrl,
      noindex: state.noindex,
    }
  }

  async function onSave() {
    if (saving) return
    setErrors({})
    const payload = buildPayload()
    const parsed = productInputSchema.safeParse(payload)
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {}
      for (const e of parsed.error.issues) fieldErrors[e.path.join('.')] = e.message
      setErrors(fieldErrors)
      toast.error('تحقق من الحقول الموضحة.')
      return
    }
    setSaving(true)
    try {
      const res = await fetch(
        mode === 'create' ? '/api/admin/products' : `/api/admin/products/${productId}`,
        {
          method: mode === 'create' ? 'POST' : 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          credentials: 'include',
        },
      )
      const json = await res.json()
      if (!res.ok || !json.ok) {
        if (json.fieldErrors) {
          setErrors(json.fieldErrors)
          toast.error(json.error || 'حقول غير صالحة')
        } else {
          toast.error(json.error || 'فشل الحفظ')
        }
        return
      }
      toast.success(
        mode === 'create' ? 'تم إنشاء المنتج' : 'تم تحديث المنتج',
      )
      router.push('/admin/products')
      router.refresh()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push('/admin/products')}
            className="text-muted-foreground"
          >
            <ArrowRight className="size-4" />
            رجوع
          </Button>
          <h1 className="text-2xl font-semibold tracking-tight">
            {mode === 'create' ? 'منتج جديد' : 'تعديل المنتج'}
          </h1>
        </div>
        <Button onClick={onSave} disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
          {saving ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              جارٍ الحفظ…
            </>
          ) : (
            <>
              <Save className="size-4" />
              حفظ التغييرات
            </>
          )}
        </Button>
      </div>

      <Tabs defaultValue="info" className="space-y-4">
        <TabsList className="flex w-full overflow-x-auto justify-start">
          <TabsTrigger value="info">معلومات</TabsTrigger>
          <TabsTrigger value="price">السعر</TabsTrigger>
          <TabsTrigger value="stock">المخزون</TabsTrigger>
          <TabsTrigger value="images">الصور</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="pub">النشر</TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">المعلومات الأساسية</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="name">اسم المنتج *</Label>
                <Input
                  id="name"
                  value={state.name}
                  onChange={(e) => onNameChange(e.target.value)}
                  placeholder="مثال: مثقاب لاسلكي 18V"
                />
                {errors.name && <p className="text-destructive text-xs">{errors.name}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="slug">الرابط (Slug) *</Label>
                <Input
                  id="slug"
                  value={state.slug}
                  onChange={(e) => {
                    setSlugTouched(true)
                    set('slug', slugify(e.target.value))
                  }}
                  placeholder="perceuse-sans-fil-18v"
                  dir="ltr"
                  className="text-left"
                />
                {errors.slug && <p className="text-destructive text-xs">{errors.slug}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="nameAr">الاسم بالعربية</Label>
                <Input
                  id="nameAr"
                  value={state.nameAr}
                  onChange={(e) => set('nameAr', e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sku">الرمز (SKU) *</Label>
                <Input
                  id="sku"
                  value={state.sku}
                  onChange={(e) => set('sku', e.target.value)}
                  placeholder="ING-PD-001"
                  dir="ltr"
                  className="text-left"
                />
                {errors.sku && <p className="text-destructive text-xs">{errors.sku}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="barcode">الباركود</Label>
                <Input
                  id="barcode"
                  value={state.barcode}
                  onChange={(e) => set('barcode', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="category">الفئة *</Label>
                <Select
                  value={state.categoryId}
                  onValueChange={(v) => set('categoryId', v)}
                >
                  <SelectTrigger id="category" className="w-full">
                    <SelectValue placeholder="اختر…" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.categoryId && (
                  <p className="text-destructive text-xs">{errors.categoryId}</p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="brand">الماركة</Label>
                <Select
                  value={state.brandId || 'none'}
                  onValueChange={(v) => set('brandId', v === 'none' ? '' : v)}
                >
                  <SelectTrigger id="brand" className="w-full">
                    <SelectValue placeholder="بدون" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">بدون</SelectItem>
                    {brands.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="short">وصف مختصر</Label>
                <Input
                  id="short"
                  value={state.shortDescription}
                  onChange={(e) => set('shortDescription', e.target.value)}
                  placeholder="جملة واحدة تلخص المنتج."
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="description">الوصف الكامل</Label>
                <Textarea
                  id="description"
                  rows={6}
                  value={state.description}
                  onChange={(e) => set('description', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-base">المواصفات</CardTitle>
              <Button variant="outline" size="sm" onClick={addSpec}>
                <Plus className="size-4" />
                إضافة
              </Button>
            </CardHeader>
            <CardContent className="space-y-2">
              {state.specifications.length === 0 && (
                <p className="text-muted-foreground text-sm">
                  لا توجد مواصفات. اضغط «إضافة».
                </p>
              )}
              {state.specifications.map((s, i) => (
                <div key={i} className="flex items-center gap-2">
                  <Input
                    value={s.key}
                    placeholder="المفتاح (مثال: القدرة)"
                    onChange={(e) => updateSpec(i, 'key', e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    value={s.value}
                    placeholder="القيمة (مثال: 18V)"
                    onChange={(e) => updateSpec(i, 'value', e.target.value)}
                    className="flex-1"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeSpec(i)}
                    className="text-rose-600"
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="price" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">التسعير</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="price">السعر (شامل الضريبة) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={state.price}
                  onChange={(e) => set('price', e.target.value)}
                />
                {errors.price && <p className="text-destructive text-xs">{errors.price}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="compareAt">السعر المشطوب</Label>
                <Input
                  id="compareAt"
                  type="number"
                  step="0.01"
                  value={state.compareAtPrice}
                  onChange={(e) => set('compareAtPrice', e.target.value)}
                  placeholder="اختياري"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cost">التكلفة (قبل الضريبة)</Label>
                <Input
                  id="cost"
                  type="number"
                  step="0.01"
                  value={state.costPrice}
                  onChange={(e) => set('costPrice', e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="currency">العملة</Label>
                <Select
                  value={state.currencyCode}
                  onValueChange={(v) => set('currencyCode', v)}
                >
                  <SelectTrigger id="currency" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MAD">MAD (DH)</SelectItem>
                    <SelectItem value="DZD">DZD</SelectItem>
                    <SelectItem value="TND">TND</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="tax">نسبة الضريبة (%)</Label>
                <Input
                  id="tax"
                  type="number"
                  step="0.01"
                  value={state.taxRate}
                  onChange={(e) => set('taxRate', e.target.value)}
                  placeholder="0"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="weight">الوزن (كغ)</Label>
                <Input
                  id="weight"
                  type="number"
                  step="0.001"
                  value={state.weightKg}
                  onChange={(e) => set('weightKg', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stock" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">المخزون</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="stock">الكمية في المخزون</Label>
                  <Input
                    id="stock"
                    type="number"
                    value={state.stockQuantity}
                    onChange={(e) => set('stockQuantity', e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="low">حد المخزون المنخفض</Label>
                  <Input
                    id="low"
                    type="number"
                    value={state.lowStockThreshold}
                    onChange={(e) => set('lowStockThreshold', e.target.value)}
                  />
                </div>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">تتبّع المخزون</p>
                  <p className="text-muted-foreground text-xs">
                    يخفض المخزون عند كل طلب.
                  </p>
                </div>
                <Switch
                  checked={state.trackInventory}
                  onCheckedChange={(v) => set('trackInventory', v)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">السماح بالطلب المسبق</p>
                  <p className="text-muted-foreground text-xs">
                    يسمح بالشراء حتى عند نفاد المخزون.
                  </p>
                </div>
                <Switch
                  checked={state.allowBackorder}
                  onCheckedChange={(v) => set('allowBackorder', v)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="images" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">الصور</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mode === 'create' && (
                <div className="bg-amber-50 text-amber-700 text-sm rounded-md p-3 border border-amber-200">
                  احفظ المنتج أولاً لتتمكن من رفع الصور.
                </div>
              )}

              {/* File upload dropzone */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault()
                  uploadFiles(e.dataTransfer.files)
                }}
                className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => fileRef.current?.click()}
              >
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => uploadFiles(e.target.files)}
                />
                {uploading ? (
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Loader2 className="size-6 animate-spin" />
                    <p className="text-sm">جارٍ الرفع…</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Upload className="size-6" />
                    <p className="text-sm font-medium">
                      اسحب الصور هنا، أو اضغط لتصفح الملفات
                    </p>
                    <p className="text-xs">PNG، JPG، WEBP — حد أقصى 5 ميغابايت</p>
                  </div>
                )}
              </div>

              {/* External URL image add */}
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <LinkIcon className="size-4" />
                  إضافة صورة برابط خارجي
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  <Input
                    placeholder="https://example.com/image.jpg"
                    value={externalUrl}
                    onChange={(e) => {
                      setExternalUrl(e.target.value)
                      setExternalPreview(null)
                      setExternalPreviewError(false)
                    }}
                    dir="ltr"
                    className="text-left"
                  />
                  <Input
                    placeholder="النص البديل (alt) — اختياري"
                    value={externalAlt}
                    onChange={(e) => setExternalAlt(e.target.value)}
                  />
                </div>
                {externalPreview && (
                  <div className="relative bg-muted border rounded-md p-2 inline-block">
                    {externalPreviewError ? (
                      <p className="text-rose-600 text-xs p-3">
                        الرابط غير صالح أو تعذر تحميل الصورة.
                      </p>
                    ) : (
                      <img
                        src={externalPreview}
                        alt="معاينة"
                        className="size-32 object-cover rounded"
                        onError={() => setExternalPreviewError(true)}
                      />
                    )}
                  </div>
                )}
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={previewExternal}
                    disabled={!externalUrl}
                  >
                    <Globe className="size-4" />
                    معاينة
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    onClick={addExternalImage}
                    disabled={addingExternal || !externalUrl}
                    className="bg-zinc-900 hover:bg-zinc-800"
                  >
                    {addingExternal ? (
                      <Loader2 className="size-4 animate-spin" />
                    ) : (
                      <Plus className="size-4" />
                    )}
                    إضافة
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  يتم التحقق من الرابط على الخادم عند الإضافة.
                </p>
              </div>

              <Separator />

              {state.images.length > 0 && (
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                  {state.images.map((im, i) => (
                    <div
                      key={im.id}
                      className="group relative border rounded-lg overflow-hidden bg-muted"
                    >
                      <div className="aspect-square relative">
                        <img
                          src={im.url}
                          alt={im.altText || state.name}
                          className="size-full object-cover"
                        />
                        <div className="absolute top-1 right-1 flex flex-col gap-1">
                          {im.isMain && (
                            <span className="bg-emerald-600 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
                              رئيسية
                            </span>
                          )}
                          {sourceBadge(im.sourceType)}
                        </div>
                      </div>
                      <div className="p-2 space-y-1">
                        <Input
                          placeholder="نص بديل"
                          value={im.altText}
                          onChange={(e) => {
                            const v = e.target.value
                            setState((s) => ({
                              ...s,
                              images: s.images.map((x) =>
                                x.id === im.id ? { ...x, altText: v } : x,
                              ),
                            }))
                          }}
                          className="h-7 text-xs"
                        />
                        <div className="flex items-center gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="size-7"
                            disabled={i === 0}
                            onClick={() => moveImage(i, -1)}
                          >
                            <ArrowUp className="size-3" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="size-7"
                            disabled={i === state.images.length - 1}
                            onClick={() => moveImage(i, 1)}
                          >
                            <ArrowDown className="size-3" />
                          </Button>
                          {!im.isMain && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 text-xs"
                              onClick={() => setMainImage(im.id)}
                            >
                              <Star className="size-3" />
                              رئيسية
                            </Button>
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            className="mr-auto size-7 text-rose-600"
                            onClick={() =>
                              setState((s) => ({
                                ...s,
                                images: s.images.filter((x) => x.id !== im.id),
                              }))
                            }
                            title="حذف محلي (احفظ لتطبيق التغيير)"
                          >
                            <X className="size-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {state.images.length === 0 && (
                <div className="text-center text-muted-foreground text-sm flex items-center justify-center gap-2">
                  <ImageIcon className="size-4" />
                  لا توجد صور. ارفعها أعلاه.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">تحسين محركات البحث</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="seoTitle">عنوان SEO</Label>
                <Input
                  id="seoTitle"
                  value={state.seoTitle}
                  onChange={(e) => set('seoTitle', e.target.value)}
                  placeholder={state.name || 'عنوان الصفحة'}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="seoDesc">وصف SEO</Label>
                <Textarea
                  id="seoDesc"
                  rows={3}
                  value={state.seoDescription}
                  onChange={(e) => set('seoDescription', e.target.value)}
                  placeholder="الوصف الذي سيظهر في جوجل."
                />
                <p className="text-muted-foreground text-xs">
                  {(state.seoDescription || state.shortDescription || '').length}/300 حرف
                </p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="og">صورة OG (رابط)</Label>
                  <Input
                    id="og"
                    value={state.ogImage}
                    onChange={(e) => set('ogImage', e.target.value)}
                    placeholder="https://…"
                    dir="ltr"
                    className="text-left"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="canonical">الرابط الأساسي (Canonical)</Label>
                  <Input
                    id="canonical"
                    value={state.canonicalUrl}
                    onChange={(e) => set('canonicalUrl', e.target.value)}
                    placeholder="https://…"
                    dir="ltr"
                    className="text-left"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">noindex</p>
                  <p className="text-muted-foreground text-xs">
                    اطلب من جوجل عدم فهرسة هذه الصفحة.
                  </p>
                </div>
                <Switch
                  checked={state.noindex}
                  onCheckedChange={(v) => set('noindex', v)}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">معاينة جوجل</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border p-4 bg-white">
                <div className="flex items-center gap-2 text-xs text-emerald-700" dir="ltr">
                  <Globe className="size-3" />
                  <span>ismailmaterial.ma</span>
                  <span className="text-muted-foreground">› produit › {state.slug || 'slug'}</span>
                </div>
                <h3 className="text-lg text-emerald-700 leading-tight mt-1 line-clamp-1">
                  {state.seoTitle || state.name || 'عنوان المنتج'}
                </h3>
                <p className="text-sm text-zinc-600 mt-0.5 line-clamp-2">
                  {state.seoDescription ||
                    state.shortDescription ||
                    'سيظهر الوصف هنا عند إضافته.'}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pub" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">النشر</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="status">الحالة</Label>
                <Select
                  value={state.status}
                  onValueChange={(v) => set('status', v)}
                >
                  <SelectTrigger id="status" className="w-full sm:w-60">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">مسودة</SelectItem>
                    <SelectItem value="PUBLISHED">منشور</SelectItem>
                    <SelectItem value="OUT_OF_STOCK">نفذ المخزون</SelectItem>
                    <SelectItem value="ARCHIVED">مؤرشف</SelectItem>
                  </SelectContent>
                </Select>
                {errors.status && (
                  <p className="text-destructive text-xs">{errors.status}</p>
                )}
              </div>
              <Separator />
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <p className="text-sm font-medium flex items-center gap-1.5">
                      <Star className="size-3.5" /> مميز
                    </p>
                  </div>
                  <Switch
                    checked={state.isFeatured}
                    onCheckedChange={(v) => set('isFeatured', v)}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <p className="text-sm font-medium">وصل حديثاً</p>
                  </div>
                  <Switch
                    checked={state.isNewArrival}
                    onCheckedChange={(v) => set('isNewArrival', v)}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <p className="text-sm font-medium">الأكثر مبيعاً</p>
                  </div>
                  <Switch
                    checked={state.isBestSeller}
                    onCheckedChange={(v) => set('isBestSeller', v)}
                  />
                </div>
              </div>
              <Separator />
              <div className="space-y-1.5">
                <Label htmlFor="related">منتجات ذات صلة (معرّفات مفصولة بفاصلة)</Label>
                <Textarea
                  id="related"
                  rows={2}
                  value={state.relatedIds}
                  onChange={(e) => set('relatedIds', e.target.value)}
                  placeholder="cl1,cl2,cl3"
                  dir="ltr"
                  className="text-left"
                />
                <p className="text-muted-foreground text-xs">
                  اختياري. تظهر في قسم «قد يعجبك أيضاً».
                </p>
              </div>
              <div className="flex justify-start pt-2">
                <Button
                  onClick={onSave}
                  disabled={saving}
                  className="bg-zinc-900 hover:bg-zinc-800"
                >
                  {saving ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      جارٍ الحفظ…
                    </>
                  ) : (
                    <>
                      <Save className="size-4" />
                      حفظ المنتج
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
