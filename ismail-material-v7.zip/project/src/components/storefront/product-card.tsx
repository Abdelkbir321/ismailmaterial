'use client'

import { useState, useCallback } from 'react'
import Link from 'next/link'
import { ShoppingBag, Plus, Check, Loader2, ImageIcon } from 'lucide-react'
import type { ProductCard } from '@/types'
import { formatPrice, discountPercent } from '@/lib/format'
import { useCart } from '@/lib/cart-store'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

/**
 * ProductCard — redesigned for robust click navigation + clean layout.
 *
 * ==========================================================================
 * ROOT CAUSE OF THE DESKTOP CLICK BUG (NOW FIXED)
 * --------------------------------------------------------------------------
 * The previous version used `transform-style: preserve-3d` + an inline
 * `transform: rotateX/rotateY` on the <Link> itself, combined with an
 * `::after` pseudo-element (`after:absolute after:inset-0 after:z-10`) to
 * "stretch" the click area.
 *
 * That combination is fragile: when `preserve-3d` is active, the browser
 * treats the pseudo-element as a 3D layer, and its hit area becomes the
 * 2D projection of a tilted plane. On desktop (where the tilt fires on
 * hover), clicks on the edges/corners of the card miss the pseudo-element
 * and hit nothing — so nothing navigates.
 *
 * THE FIX: The <Link> wraps the ENTIRE card body as a simple block element.
 * No `preserve-3d`, no inline `transform`, no `::after` pseudo-element.
 * The Link's natural box covers the whole card, so every pixel is
 * clickable. The Add-to-Cart button sits ABOVE the Link (sibling, z-30)
 * and calls `e.preventDefault()` + `e.stopPropagation()` so it adds to
 * cart WITHOUT navigating.
 *
 * ==========================================================================
 * CARD LAYOUT (flexible, no fixed heights)
 * --------------------------------------------------------------------------
 * - Image area: fixed aspect-square, `object-contain` on a neutral bg so
 *   product photos (tools, instruments) are never cropped.
 * - Body: brand kicker → name (2-line clamp) → short description (1-line) →
 *   stock status → price row. All flex-col, no fixed heights, so cards
 *   with long/short names align naturally.
 * - Add-to-Cart: circular icon button, bottom-right, z-30, with
 *   loading / success / disabled states + double-click guard.
 *
 * ==========================================================================
 * IMAGE HANDLING
 * --------------------------------------------------------------------------
 * - `object-contain` preserves aspect ratio (no cropping of tools).
 * - `loading="lazy"` + `decoding="async"` for performance.
 * - `onError` falls back to a placeholder icon (no broken image).
 * - `draggable={false}` prevents drag-interference with click.
 *
 * ==========================================================================
 * ADD-TO-CART STATES
 * --------------------------------------------------------------------------
 * - idle: Plus icon
 * - loading: spinner (brief, while validating)
 * - success: Check icon (1.2s, then back to idle)
 * - disabled (out of stock): dash icon, dimmed
 * - Double-click guard: `submittingRef` prevents concurrent calls.
 * ==========================================================================
 */

type AddState = 'idle' | 'loading' | 'success'

export function ProductCard({ product }: { product: ProductCard }) {
  const add = useCart((s) => s.add)
  const openCart = useCart((s) => s.open)
  const [addState, setAddState] = useState<AddState>('idle')
  const [imgError, setImgError] = useState(false)

  const currency = { code: product.currencyCode, symbol: 'DH', locale: 'fr-MA' }
  const price = Number(product.price)
  const compare = product.compareAtPrice ? Number(product.compareAtPrice) : null
  const discount = discountPercent(price, compare)
  const outOfStock =
    product.trackInventory && !product.allowBackorder && product.stockQuantity <= 0
  const lowStock =
    product.trackInventory && !outOfStock && product.stockQuantity <= 5

  // Add to cart — MUST preventDefault + stopPropagation so it doesn't
  // trigger the card Link's navigation. Also includes a double-click guard.
  const handleAdd = useCallback(
    async (e: React.MouseEvent) => {
      e.preventDefault()
      e.stopPropagation()
      if (outOfStock || addState !== 'idle') return
      setAddState('loading')
      try {
        add({
          productId: product.id,
          slug: product.slug,
          name: product.name,
          sku: product.sku,
          price,
          image: product.mainImage?.secureUrl ?? product.mainImage?.url ?? null,
          maxStock: product.trackInventory ? product.stockQuantity : 999,
        })
        setAddState('success')
        openCart()
        setTimeout(() => setAddState('idle'), 1200)
      } catch {
        setAddState('idle')
      }
    },
    [add, openCart, outOfStock, addState, product, price],
  )

  const imgSrc = product.mainImage?.secureUrl || product.mainImage?.url

  return (
    <article className="group relative">
      {/*
        Single <Link> wrapping the ENTIRE card body. It's a block element
        that fills the card — no ::after pseudo-element, no preserve-3d,
        no inline transform. Every pixel of the card is clickable.
        The Add-to-Cart button is a SIBLING (not a child) positioned above
        with z-30 + stopPropagation, so it never triggers navigation.
      */}
      <Link
        href={`/produits/${product.slug}`}
        className="surface-1 relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all duration-300 hover:border-border-strong hover:shadow-[var(--shadow-md)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        aria-label={product.name}
      >
        {/* === IMAGE AREA === */}
        <div className="relative aspect-square overflow-hidden bg-muted/25">
          {imgSrc && !imgError ? (
            <img
              src={imgSrc}
              alt={product.mainImage?.altText || product.name}
              className="h-full w-full object-contain p-3 transition-transform duration-500 ease-out group-hover:scale-[1.04]"
              loading="lazy"
              decoding="async"
              draggable={false}
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="grid h-full w-full place-items-center text-muted-foreground/30">
              <ImageIcon className="h-10 w-10" strokeWidth={1.2} />
            </div>
          )}

          {/* Badges — top-left, pointer-events-none so they never block clicks */}
          <div
            className="pointer-events-none absolute left-2.5 top-2.5 z-20 flex flex-col gap-1.5"
            aria-hidden="true"
          >
            {discount && (
              <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground shadow-[var(--shadow-sm)]">
                −{discount}%
              </span>
            )}
            {product.isNewArrival && !outOfStock && (
              <span className="rounded-full bg-success px-2 py-0.5 text-[10px] font-bold text-success-foreground shadow-[var(--shadow-sm)]">
                Nouveau
              </span>
            )}
            {product.isBestSeller && !outOfStock && (
              <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-accent-foreground shadow-[var(--shadow-sm)]">
                Top
              </span>
            )}
            {product.isFeatured && !product.isNewArrival && !product.isBestSeller && !outOfStock && (
              <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold text-secondary-foreground shadow-[var(--shadow-sm)]">
                Sélection
              </span>
            )}
          </div>

          {/* Out-of-stock overlay */}
          {outOfStock && (
            <div className="pointer-events-none absolute inset-0 z-20 grid place-items-center bg-background/70 backdrop-blur-[2px]">
              <span className="rounded-full border border-border-strong bg-secondary px-3.5 py-1.5 text-xs font-semibold text-secondary-foreground shadow-[var(--shadow-md)]">
                Rupture de stock
              </span>
            </div>
          )}
        </div>

        {/* === BODY === */}
        <div className="flex flex-1 flex-col p-3.5 sm:p-4">
          {product.brand && (
            <span className="kicker mb-1 !text-[10px]">{product.brand.name}</span>
          )}
          <h3 className="line-clamp-2 min-h-[2.5rem] font-display text-[14px] font-semibold leading-snug text-foreground transition-colors group-hover:text-primary sm:text-[15px]">
            {product.name}
          </h3>
          {product.shortDescription && (
            <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">
              {product.shortDescription}
            </p>
          )}
          {lowStock && !outOfStock && (
            <p className="mt-1.5 text-[11px] font-medium text-accent">
              Plus que {product.stockQuantity} en stock
            </p>
          )}

          {/* Price row — aligned across cards, takes remaining space */}
          <div className="mt-auto pt-3">
            <div className="flex items-baseline gap-1.5">
              <span className="price-display font-display text-lg font-bold tracking-tight text-foreground">
                {formatPrice(price, currency)}
              </span>
              {compare && (
                <span className="text-xs text-muted-foreground/60 line-through">
                  {formatPrice(compare, currency)}
                </span>
              )}
            </div>
            <p className="mt-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground/70">
              {product.currencyCode} · paiement à la livraison
            </p>
          </div>
        </div>
      </Link>

      {/*
        Add-to-Cart button — SIBLING of the Link (not a child), positioned
        absolutely with z-30 so it sits ABOVE the Link's clickable area.
        handleAdd calls preventDefault + stopPropagation so clicks here
        add to cart WITHOUT navigating to the product page.
      */}
      <div className="absolute bottom-3.5 right-3.5 z-30 sm:bottom-4 sm:right-4">
        <Button
          onClick={handleAdd}
          disabled={outOfStock || addState === 'loading'}
          size="sm"
          variant={outOfStock ? 'secondary' : 'default'}
          aria-label={outOfStock ? 'Indisponible' : `Ajouter ${product.name} au panier`}
          aria-disabled={outOfStock}
          className={cn(
            'btn-primary-cta grid size-9 place-items-center rounded-full p-0 shadow-[var(--shadow-sm)] transition-all hover:shadow-[var(--shadow-md)] sm:size-10',
            outOfStock && 'cursor-not-allowed opacity-50',
            addState === 'success' && 'bg-success text-success-foreground hover:bg-success',
          )}
        >
          {outOfStock ? (
            <span className="text-sm font-bold">—</span>
          ) : addState === 'loading' ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : addState === 'success' ? (
            <Check className="h-4 w-4" />
          ) : (
            <Plus className="h-4 w-4" />
          )}
        </Button>
      </div>
    </article>
  )
}

/** Skeleton card for loading states */
export function ProductCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card">
      <div className="skeleton-shimmer aspect-square w-full" />
      <div className="p-4">
        <div className="skeleton-shimmer mb-2 h-2.5 w-1/3" />
        <div className="skeleton-shimmer mb-1 h-4 w-3/4" />
        <div className="skeleton-shimmer mb-3 h-4 w-1/2" />
        <div className="skeleton-shimmer h-6 w-2/3" />
      </div>
    </div>
  )
}
