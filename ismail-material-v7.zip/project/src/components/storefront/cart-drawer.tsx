'use client'

import Link from 'next/link'
import { Minus, Plus, Trash2, ShoppingBag, X, ShoppingCart } from 'lucide-react'
import { useCart } from '@/lib/cart-store'
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/format'

/**
 * CartDrawer — refined drawer with depth and clear hierarchy.
 *
 * DESIGN INTENT
 * -------------
 * - Header has a "kicker" eyebrow + cart count as a pill
 * - Empty state has an editorial illustration (icon in a circle)
 * - Item rows have a thumbnail + name + price/qty row + remove button
 * - Sticky footer with subtotal + 2 CTA buttons (view cart / checkout)
 */
export function CartDrawer() {
  const { items, isOpen, close, setQty, remove, subtotal, count } = useCart()
  const total = subtotal()
  const currency = { code: 'MAD', symbol: 'DH', locale: 'fr-MA' }

  return (
    <Sheet open={isOpen} onOpenChange={(o) => !o && close()}>
      <SheetContent className="flex w-full flex-col p-0 sm:max-w-md" side="right">
        <SheetTitle className="sr-only">Panier</SheetTitle>

        {/* Header */}
        <div className="flex items-center justify-between border-b border-border bg-card px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="grid size-9 place-items-center rounded-full bg-muted text-primary">
              <ShoppingBag className="h-4 w-4" strokeWidth={1.6} />
            </div>
            <div>
              <span className="block text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                Votre
              </span>
              <h2 className="font-display text-base font-bold leading-tight">Panier</h2>
            </div>
            <span className="ml-1 rounded-full bg-muted px-2 py-0.5 font-mono text-xs font-semibold text-muted-foreground">
              {count()}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={close}
            aria-label="Fermer"
            className="rounded-full"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
            <div className="grid size-20 place-items-center rounded-full bg-muted text-muted-foreground/60">
              <ShoppingBag className="h-8 w-8" strokeWidth={1.2} />
            </div>
            <div>
              <p className="font-display text-base font-semibold">Votre panier est vide</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Découvrez nos produits professionnels
              </p>
            </div>
            <Button asChild onClick={close} className="btn-primary-cta rounded-full">
              <Link href="/produits">
                <ShoppingCart className="mr-2 h-4 w-4" /> Parcourir le catalogue
              </Link>
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-3 py-2">
              {items.map((item) => (
                <div
                  key={`${item.productId}-${item.variantId ?? 'x'}`}
                  className="flex gap-3 border-b border-border px-2 py-3 last:border-b-0"
                >
                  <div className="size-16 flex-shrink-0 overflow-hidden rounded-xl bg-muted">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="grid h-full w-full place-items-center text-muted-foreground/60">
                        <ShoppingBag className="h-5 w-5" />
                      </div>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col">
                    <Link
                      href={`/produits/${item.slug}`}
                      onClick={close}
                      className="line-clamp-2 font-display text-sm font-medium leading-snug text-foreground transition-colors hover:text-primary"
                    >
                      {item.name}
                    </Link>
                    {item.variantName && (
                      <p className="mt-0.5 text-xs text-muted-foreground">{item.variantName}</p>
                    )}
                    <p className="mt-1 price-display text-sm font-semibold text-foreground">
                      {formatPrice(item.price, currency)}
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex items-center rounded-full border border-border bg-card p-0.5">
                        <button
                          onClick={() => setQty(item.productId, item.variantId, item.quantity - 1)}
                          className="grid size-6 place-items-center rounded-full text-foreground transition-colors hover:bg-muted"
                          aria-label="Diminuer"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-7 text-center font-mono text-xs font-semibold tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => setQty(item.productId, item.variantId, item.quantity + 1)}
                          className="grid size-6 place-items-center rounded-full text-foreground transition-colors hover:bg-muted"
                          aria-label="Augmenter"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <button
                        onClick={() => remove(item.productId, item.variantId)}
                        className="grid size-7 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                        aria-label="Retirer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="price-display shrink-0 text-right text-sm font-semibold">
                    {formatPrice(item.price * item.quantity, currency)}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="border-t border-border bg-card px-5 py-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Sous-total</span>
                <span className="font-display price-display text-xl font-bold tracking-tight">
                  {formatPrice(total, currency)}
                </span>
              </div>
              <p className="mb-3 text-[11px] text-muted-foreground">
                Livraison calculée à l'étape suivante · Paiement à la livraison
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  asChild
                  variant="outline"
                  className="rounded-full border-border"
                >
                  <Link href="/cart" onClick={close}>Voir le panier</Link>
                </Button>
                <Button
                  asChild
                  className="btn-primary-cta rounded-full"
                >
                  <Link href="/checkout" onClick={close}>Commander</Link>
                </Button>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
