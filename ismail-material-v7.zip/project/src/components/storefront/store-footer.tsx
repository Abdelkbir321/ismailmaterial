'use client'

import Link from 'next/link'
import { ShieldCheck, Truck, Phone, Facebook, Instagram, Youtube, Wrench, ArrowUpRight, CreditCard } from 'lucide-react'
import { Logo } from '@/components/storefront/logo'
import type { LogoMotion, LogoSize } from '@/lib/logo-config'

interface FooterBranding {
  siteName: string
  tagline: string
  description: string
  logoUrl: string | null
  logoSize?: LogoSize | null
  logoMotion?: LogoMotion | null
  supportPhone: string
  supportEmail: string
  address: string
  social: { facebook: string; instagram: string; tiktok: string; youtube: string }
}

export function StoreFooter({ branding }: { branding: FooterBranding | null }) {
  const b = branding
  const name = b?.siteName || 'Ismail Material'
  const phone = b?.supportPhone || ''
  const phoneHref = phone.replace(/[\s()-]/g, '')

  return (
    <footer className="mt-auto border-t border-border bg-secondary text-secondary-foreground">
      {/* Benefits strip — distinct bands, not just cards */}
      <div className="border-b border-border-strong/20">
        <div className="mx-auto grid max-w-7xl grid-cols-1 divide-y divide-border-strong/20 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
          {[
            {
              icon: Truck,
              title: 'Livraison rapide',
              text: 'Expédition 24–72h partout au Maroc',
            },
            {
              icon: ShieldCheck,
              title: 'Paiement à la livraison',
              text: 'Payez en espèces à la réception du colis',
            },
            {
              icon: CreditCard,
              title: phone || 'Support expert',
              text: phone ? 'Contactez notre équipe technique' : 'Du lundi au samedi',
            },
          ].map((bn, i) => (
            <div
              key={i}
              className="flex flex-col items-center gap-2 px-6 py-6 text-center"
            >
              <bn.icon className="h-6 w-6 text-accent" strokeWidth={1.5} />
              <p className="font-display text-sm font-semibold tracking-tight">
                {bn.title}
              </p>
              <p className="text-xs text-secondary-foreground/70">{bn.text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main footer grid — editorial, not generic */}
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:grid-cols-2 lg:grid-cols-12">
        {/* Brand column — wide */}
        <div className="lg:col-span-4">
          <div className="flex items-center gap-2.5">
            <div className="relative grid place-items-center rounded-xl bg-card shadow-[var(--shadow-sm)]"
                 style={{ minWidth: '40px', minHeight: '40px', padding: '4px' }}>
              <Logo
                logoUrl={b?.logoUrl ?? null}
                alt={name}
                size={b?.logoSize ?? null}
                motion={b?.logoMotion ?? null}
                className="relative z-10"
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="font-display text-base font-bold tracking-tight">
                {name}
              </span>
              <span className="text-[10px] font-medium uppercase tracking-[0.12em] text-secondary-foreground/60">
                Outillage · Maroc
              </span>
            </div>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-secondary-foreground/70">
            {b?.description || b?.tagline}
          </p>
          {b?.address && (
            <p className="mt-4 text-xs text-secondary-foreground/60">
              {b.address}
            </p>
          )}
        </div>

        {/* Catalog column */}
        <div className="lg:col-span-2">
          <h3 className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-accent">
            <span className="h-px w-4 bg-accent" /> Catalogue
          </h3>
          <ul className="space-y-2.5 text-sm">
            <li>
              <Link
                href="/produits"
                className="inline-flex items-center gap-1 text-secondary-foreground/80 transition-colors hover:text-secondary-foreground"
              >
                Tous les produits
              </Link>
            </li>
            <li>
              <Link
                href="/categories"
                className="inline-flex items-center gap-1 text-secondary-foreground/80 transition-colors hover:text-secondary-foreground"
              >
                Catégories
              </Link>
            </li>
            <li>
              <Link
                href="/produits?filter=featured"
                className="inline-flex items-center gap-1 text-secondary-foreground/80 transition-colors hover:text-secondary-foreground"
              >
                Produits en vedette
              </Link>
            </li>
            <li>
              <Link
                href="/produits?filter=best"
                className="inline-flex items-center gap-1 text-secondary-foreground/80 transition-colors hover:text-secondary-foreground"
              >
                Meilleures ventes
              </Link>
            </li>
            <li>
              <Link
                href="/produits?filter=new"
                className="inline-flex items-center gap-1 text-secondary-foreground/80 transition-colors hover:text-secondary-foreground"
              >
                Nouveautés
              </Link>
            </li>
          </ul>
        </div>

        {/* Help column */}
        <div className="lg:col-span-2">
          <h3 className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-accent">
            <span className="h-px w-4 bg-accent" /> Aide
          </h3>
          <ul className="space-y-2.5 text-sm">
            <li>
              <Link href="/aide" className="text-secondary-foreground/80 transition-colors hover:text-secondary-foreground">
                Centre d'aide
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-secondary-foreground/80 transition-colors hover:text-secondary-foreground">
                Contact
              </Link>
            </li>
            <li>
              <Link href="/page/faq" className="text-secondary-foreground/80 transition-colors hover:text-secondary-foreground">
                FAQ
              </Link>
            </li>
            <li>
              <Link href="/page/livraison-retours" className="text-secondary-foreground/80 transition-colors hover:text-secondary-foreground">
                Livraison & retours
              </Link>
            </li>
            <li>
              <Link href="/page/conditions-generales" className="text-secondary-foreground/80 transition-colors hover:text-secondary-foreground">
                Conditions générales
              </Link>
            </li>
          </ul>
        </div>

        {/* Contact column — wider with social */}
        <div className="lg:col-span-4">
          <h3 className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-accent">
            <span className="h-px w-4 bg-accent" /> Contact
          </h3>
          <ul className="space-y-2 text-sm">
            {phone && (
              <li className="flex items-center gap-2.5 text-secondary-foreground/80">
                <Phone className="h-4 w-4 text-accent" />
                <a
                  href={`tel:${phoneHref}`}
                  className="font-medium transition-colors hover:text-secondary-foreground"
                  dir="ltr"
                >
                  {phone}
                </a>
              </li>
            )}
            {b?.supportEmail && (
              <li className="text-secondary-foreground/80">{b.supportEmail}</li>
            )}
          </ul>
          {(b?.social.facebook || b?.social.instagram || b?.social.youtube) && (
            <div className="mt-5 flex flex-wrap gap-2">
              {b?.social.facebook && (
                <a
                  href={b.social.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook"
                  className="grid size-9 place-items-center rounded-full border border-border-strong/30 text-secondary-foreground/70 transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground"
                >
                  <Facebook className="h-4 w-4" />
                </a>
              )}
              {b?.social.instagram && (
                <a
                  href={b.social.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram"
                  className="grid size-9 place-items-center rounded-full border border-border-strong/30 text-secondary-foreground/70 transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground"
                >
                  <Instagram className="h-4 w-4" />
                </a>
              )}
              {b?.social.youtube && (
                <a
                  href={b.social.youtube}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="YouTube"
                  className="grid size-9 place-items-center rounded-full border border-border-strong/30 text-secondary-foreground/70 transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground"
                >
                  <Youtube className="h-4 w-4" />
                </a>
              )}
            </div>
          )}
          {/* Trust badge */}
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-border-strong/30 bg-card/40 px-3 py-1.5 text-xs">
            <Wrench className="h-3 w-3 text-accent" />
            <span className="text-secondary-foreground/70">Marques professionnelles</span>
            <span className="font-mono text-secondary-foreground">· INGCO · Total · Crown · Würth</span>
          </div>
        </div>
      </div>

      {/* Bottom strip */}
      <div className="border-t border-border-strong/20">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-secondary-foreground/60 sm:flex-row">
          <p>
            © {new Date().getFullYear()} {name}. Tous droits réservés.
          </p>
          <p className="flex items-center gap-2">
            <span className="font-medium tracking-tight">
              Paiement à la livraison
            </span>
            <span className="text-secondary-foreground/30">·</span>
            <span>Livraison Maroc</span>
          </p>
        </div>
      </div>
    </footer>
  )
}
