'use client'

import { useState } from 'react'

/**
 * HeroImage — static hero image for the homepage.
 *
 * Replaces the old 3D HeroScene. Shows an image from the admin-configured
 * `hero_image_url` setting. Falls back to a branded placeholder when no
 * image is set or when the image fails to load.
 *
 * Responsive: uses object-contain to preserve aspect ratio without
 * distortion on both desktop and mobile.
 */
export function HeroImage({ imageUrl }: { imageUrl: string | null }) {
  const [error, setError] = useState(false)
  const src = imageUrl && !error ? imageUrl : null

  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl sm:aspect-square lg:aspect-[5/4]">
      {src ? (
        <img
          src={src}
          alt="Ismail Material"
          className="h-full w-full object-contain"
          onError={() => setError(true)}
          loading="eager"
        />
      ) : (
        <div className="absolute inset-0 grid place-items-center">
          <div className="relative grid size-32 place-items-center rounded-2xl bg-[#1A1410] shadow-2xl">
            <img
              src="/logo.svg"
              alt="Ismail Material"
              className="size-20 object-contain"
            />
            <div className="absolute -right-3 -top-3 size-8 rounded-full bg-[#9A6A1E] opacity-80 shadow-lg" />
            <div className="absolute -bottom-2 -left-4 size-6 rounded-full bg-[#B23A0E] opacity-90 shadow-md" />
            <div className="absolute -right-6 bottom-8 size-4 rounded-full bg-[#FFFCF7] shadow" />
          </div>
        </div>
      )}
    </div>
  )
}
