'use client'

import { useState, useRef } from 'react'
import { cn } from '@/lib/utils'
import { ZoomIn } from 'lucide-react'

/**
 * ProductGallery — refined, with depth + zoom affordance.
 *
 * DESIGN INTENT
 * -------------
 * - Main image area has a subtle inner shadow + hairline border
 * - Zoom indicator in the top-right corner (visible on hover, desktop)
 * - Thumbnail strip below, with active state using border-color not box-shadow
 * - All animations respect prefers-reduced-motion via the global CSS
 */
export function ProductGallery({
  images,
  name,
}: {
  images: Array<{ secureUrl: string; url: string; altText?: string | null; isMain?: boolean }>
  name: string
}) {
  const ordered = [...images].sort((a, b) => (b.isMain ? 1 : 0) - (a.isMain ? 1 : 0))
  const [active, setActive] = useState(0)
  const [zoom, setZoom] = useState(false)
  const [pos, setPos] = useState({ x: 50, y: 50 })
  const imgRef = useRef<HTMLDivElement>(null)

  if (!ordered.length) {
    return (
      <div className="aspect-square w-full overflow-hidden rounded-3xl border border-border bg-muted/30 grid place-items-center text-muted-foreground/60">
        <span className="text-sm">Pas d'image</span>
      </div>
    )
  }
  const current = ordered[active] ?? ordered[0]

  const onMove = (e: React.MouseEvent) => {
    if (!imgRef.current) return
    const rect = imgRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setPos({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) })
  }

  return (
    <div className="flex flex-col gap-3">
      <div
        ref={imgRef}
        className="group relative aspect-square w-full overflow-hidden rounded-3xl border border-border bg-muted/30 cursor-zoom-in shadow-[var(--shadow-sm)]"
        onMouseEnter={() => setZoom(true)}
        onMouseLeave={() => setZoom(false)}
        onMouseMove={onMove}
      >
        <img
          src={current.secureUrl || current.url}
          alt={current.altText || name}
          className="h-full w-full object-cover transition-transform duration-300 ease-out"
          style={zoom ? { transformOrigin: `${pos.x}% ${pos.y}%`, transform: 'scale(1.8)' } : undefined}
        />

        {/* Zoom affordance — top-right, visible on hover */}
        <div className="pointer-events-none absolute right-3 top-3 translate-y-[-4px] opacity-0 transition-all duration-200 group-hover:translate-y-0 group-hover:opacity-100">
          <span className="grid size-8 place-items-center rounded-full bg-card/95 shadow-[var(--shadow-sm)] backdrop-blur">
            <ZoomIn className="h-3.5 w-3.5 text-foreground" />
          </span>
        </div>
      </div>
      {ordered.length > 1 && (
        <div className="grid grid-cols-5 gap-2 sm:grid-cols-6">
          {ordered.map((img, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={cn(
                'aspect-square overflow-hidden rounded-xl border bg-muted/30 transition-all duration-200',
                i === active
                  ? 'border-primary shadow-[var(--shadow-xs)]'
                  : 'border-border hover:border-border-strong',
              )}
              aria-label={`Image ${i + 1}`}
              aria-pressed={i === active}
            >
              <img
                src={img.secureUrl || img.url}
                alt=""
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

/** Gallery skeleton */
export function ProductGallerySkeleton() {
  return (
    <div className="flex flex-col gap-3">
      <div className="skeleton-shimmer aspect-square w-full rounded-3xl" />
      <div className="grid grid-cols-5 gap-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton-shimmer aspect-square rounded-xl" />
        ))}
      </div>
    </div>
  )
}
