import { z } from 'zod'

export const createOrderSchema = z.object({
  customerFullName: z
    .string()
    .min(2, 'Le nom est requis')
    .max(120, 'Nom trop long'),
  customerPhone: z
    .string()
    .min(8, 'Numéro de téléphone invalide')
    .max(20, 'Numéro trop long')
    .regex(/^[+\d\s().-]+$/, 'Téléphone invalide'),
  customerEmail: z.string().email('Email invalide').optional().or(z.literal('')),
  countryId: z.string().min(1, 'Pays requis'),
  shippingCity: z.string().min(2, 'Ville requise').max(120),
  shippingAddress: z.string().min(5, 'Adresse requise').max(500),
  shippingPostalCode: z.string().max(20).optional().or(z.literal('')),
  notes: z.string().max(1000).optional().or(z.literal('')),
  couponCode: z.string().max(50).optional().or(z.literal('')),
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        variantId: z.string().optional().nullable(),
        quantity: z.number().int().min(1).max(999),
      }),
    )
    .min(1, 'Panier vide'),
})
export type CreateOrderSchema = z.infer<typeof createOrderSchema>

export const productInputSchema = z.object({
  name: z.string().min(2).max(200),
  slug: z.string().min(2).max(120).regex(/^[a-z0-9-]+$/, 'Slug invalide'),
  nameAr: z.string().max(200).optional().or(z.literal('')),
  shortDescription: z.string().max(500).optional().or(z.literal('')),
  description: z.string().max(8000).optional().or(z.literal('')),
  sku: z.string().min(1).max(60),
  barcode: z.string().max(60).optional().or(z.literal('')),
  brandId: z.string().optional().nullable(),
  categoryId: z.string().min(1, 'Catégorie requise'),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED', 'OUT_OF_STOCK']),
  price: z.number().min(0),
  compareAtPrice: z.number().min(0).optional().nullable(),
  costPrice: z.number().min(0).optional().nullable(),
  currencyCode: z.string().max(3).default('MAD'),
  taxRate: z.number().min(0).max(100).optional().nullable(),
  weightKg: z.number().min(0).optional().nullable(),
  stockQuantity: z.number().int().min(0).default(0),
  lowStockThreshold: z.number().int().min(0).default(5),
  allowBackorder: z.boolean().default(false),
  trackInventory: z.boolean().default(true),
  isFeatured: z.boolean().default(false),
  isNewArrival: z.boolean().default(false),
  isBestSeller: z.boolean().default(false),
  specifications: z.any().default([]),
  faq: z.any().default([]),
  relatedIds: z.any().default([]),
  seoTitle: z.string().max(200).optional().or(z.literal('')),
  seoDescription: z.string().max(300).optional().or(z.literal('')),
  seoKeywords: z.string().max(200).optional().or(z.literal('')),
  ogImage: z.string().max(500).optional().or(z.literal('')),
  canonicalUrl: z.string().max(500).optional().or(z.literal('')),
  noindex: z.boolean().default(false),
})
export type ProductInputSchema = z.infer<typeof productInputSchema>

export const categoryInputSchema = z.object({
  name: z.string().min(2).max(120),
  slug: z.string().min(2).max(120).regex(/^[a-z0-9-]+$/),
  nameAr: z.string().max(120).optional().or(z.literal('')),
  description: z.string().max(2000).optional().or(z.literal('')),
  parentId: z.string().optional().nullable(),
  sortOrder: z.number().int().default(0),
  isVisible: z.boolean().default(true),
  seoTitle: z.string().max(200).optional().or(z.literal('')),
  seoDescription: z.string().max(300).optional().or(z.literal('')),
})
export type CategoryInputSchema = z.infer<typeof categoryInputSchema>

export const brandInputSchema = z.object({
  name: z.string().min(2).max(120),
  slug: z.string().min(2).max(120).regex(/^[a-z0-9-]+$/),
  nameAr: z.string().max(120).optional().or(z.literal('')),
  description: z.string().max(2000).optional().or(z.literal('')),
  countryOfOrigin: z.string().max(120).optional().or(z.literal('')),
  isVisible: z.boolean().default(true),
  sortOrder: z.number().int().default(0),
})
export type BrandInputSchema = z.infer<typeof brandInputSchema>

export const adminLoginSchema = z.object({
  email: z.string().email('Email invalide'),
  password: z.string().min(1, 'Mot de passe requis'),
})
export type AdminLoginSchema = z.infer<typeof adminLoginSchema>

export const countryInputSchema = z.object({
  code: z.string().min(2).max(2).toUpperCase(),
  name: z.string().min(2).max(120),
  nameAr: z.string().max(120).optional().or(z.literal('')),
  currencyCode: z.string().min(3).max(3),
  currencySymbol: z.string().min(1).max(8),
  phonePrefix: z.string().min(1).max(8),
  locale: z.string().max(8).default('fr'),
  isEnabled: z.boolean().default(true),
  isDefault: z.boolean().default(false),
  sortOrder: z.number().int().default(0),
  shippingBase: z.number().min(0).default(0),
  shippingPerKg: z.number().min(0).default(0),
  taxRate: z.number().min(0).max(100).default(0),
})
export type CountryInputSchema = z.infer<typeof countryInputSchema>
