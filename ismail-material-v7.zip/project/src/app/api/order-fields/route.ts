import { NextRequest } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

/**
 * GET /api/order-fields?locale=fr&countryId=xxx&countryCode=MA
 * Returns the active order fields for rendering the checkout form.
 * - locale: ar | fr | en (selects the label language)
 * - countryId: filter to fields visible in this country (empty countryCodes = all)
 * - countryCode: same filter but by ISO code (MA, DZ...)
 */
export async function GET(req: NextRequest) {
  const locale = (req.nextUrl.searchParams.get('locale') || 'fr') as 'ar' | 'fr' | 'en'
  const countryId = req.nextUrl.searchParams.get('countryId')
  const countryCode = req.nextUrl.searchParams.get('countryCode')

  // Resolve the country code if only countryId was given
  let code: string | null = countryCode
  if (!code && countryId) {
    const c = await db.country.findUnique({ where: { id: countryId }, select: { code: true } })
    code = c?.code ?? null
  }

  const fields = await db.orderField.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: 'asc' },
  })

  // Filter by country: a field shows in a country if countryCodes is empty (all)
  // OR includes the country's code.
  const visible = code
    ? fields.filter((f) => f.countryCodes.length === 0 || f.countryCodes.includes(code))
    : fields

  const pick = (ar: string, fr: string, en: string) => (locale === 'ar' ? ar : locale === 'en' ? en : fr)

  return Response.json({
    ok: true,
    fields: visible.map((f) => ({
      key: f.key,
      type: f.type,
      label: pick(f.labelAr, f.labelFr, f.labelEn),
      placeholder: pick(f.placeholderAr || '', f.placeholderFr || '', f.placeholderEn || '') || null,
      helpText: pick(f.helpTextAr || '', f.helpTextFr || '', f.helpTextEn || '') || null,
      required: f.required,
      width: f.width,
      defaultValue: f.defaultValue,
      minLength: f.minLength,
      maxLength: f.maxLength,
      options: Array.isArray(f.options) ? (f.options as any[]).map((o) => ({
        value: o.value,
        label: pick(o.labelAr || '', o.labelFr || '', o.labelEn || ''),
      })) : [],
    })),
  })
}
