import { getCountries, getDefaultCountry } from '@/services/catalog'
export const dynamic = "force-dynamic"
export async function GET() {
  const [countries, def] = await Promise.all([getCountries(), getDefaultCountry()])
  return Response.json({ ok: true, countries, defaultId: def?.id ?? null })
}
