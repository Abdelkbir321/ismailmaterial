import { db } from '@/lib/db'
import { isCloudinaryConfigured } from '@/lib/cloudinary'

export const dynamic = 'force-dynamic'
export const maxDuration = 10

/**
 * GET /api/health
 *
 * Lightweight health check — used by external monitors (UptimeRobot, Netlify
 * monitoring, etc.) to verify the storefront is alive and all critical
 * dependencies are reachable.
 *
 * Returns:
 *   { ok: true, status: 'healthy'|'degraded', checks: {...}, time }
 *
 * NEVER exposes internal paths, DB credentials, or stack traces.
 */
export async function GET() {
  const checks: Record<string, 'ok' | 'fail'> = {
    database: 'fail',
    cloudinary: 'fail',
  }

  // DB ping — short timeout to avoid hanging the health probe
  try {
    await db.$queryRaw`SELECT 1`
    checks.database = 'ok'
  } catch {
    checks.database = 'fail'
  }

  // Cloudinary config presence (no network call)
  checks.cloudinary = isCloudinaryConfigured() ? 'ok' : 'fail'

  const allOk = Object.values(checks).every((v) => v === 'ok')
  return Response.json(
    {
      ok: allOk,
      status: allOk ? 'healthy' : 'degraded',
      checks,
      time: new Date().toISOString(),
    },
    { status: allOk ? 200 : 503 },
  )
}
