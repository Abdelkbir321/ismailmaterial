import { getCategories } from '@/services/catalog'
export const dynamic = "force-dynamic"
export async function GET() {
  return Response.json({ ok: true, categories: await getCategories() })
}
