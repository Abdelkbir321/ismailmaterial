import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createOrder } from '@/services/orders'
import { clientMeta } from '@/lib/admin-api'
import { rateLimitByIp } from '@/lib/rate-limit'
import { revalidateTag } from 'next/cache'
import {
  buildOrderSchemaFromFields,
  STRUCTURED_TO_FIELD_KEY,
  FIELD_KEY_TO_STRUCTURED,
} from '@/lib/order-schema'

export const dynamic = 'force-dynamic'

/**
 * Order creation endpoint.
 *
 * ==========================================================================
 * ROOT CAUSE of the original "المرجو تصحيح الحقول المشار إليها بالأحمر." bug
 * --------------------------------------------------------------------------
 * The `baseSchema` was HARDCODED with `z.string().min(2)` for `customerFullName`,
 * `customerPhone`, `countryId`, `shippingCity`, `shippingAddress` — REGARDLESS
 * of what the admin configured in the `OrderField` table.
 *
 * Scenario: admin deactivates the `phone` field (or sets `required: false`)
 * in `/admin/order-fields`. The `/api/order-fields` endpoint correctly
 * stops returning that field → the checkout form stops rendering the input.
 * But `baseSchema` in the POST handler still required `customerPhone.min(6)`.
 * → User submits form → server says "رقم الهاتف إجباري" → frontend shows
 * the toast but NO input to fix → user is stuck.
 *
 * Same issue if the admin set `required: false` on `phone` while keeping it
 * active: the form shows the input as optional, but baseSchema rejects
 * empty submissions.
 *
 * ==========================================================================
 * THE FIX
 * --------------------------------------------------------------------------
 * Build `baseSchema` DYNAMICALLY per-request by reading the `OrderField`
 * table. The schema-building logic lives in `src/lib/order-schema.ts` so it
 * can be unit-tested without a database.
 *
 * For each STRUCTURED field key (full_name, phone, country, city,
 * address, postal_code, notes):
 *
 *   - Field row MISSING OR `isActive === false` → corresponding structured
 *     column becomes OPTIONAL in the schema (accepts empty string).
 *
 *   - Field present, `required === true` → apply full type validation.
 *
 *   - Field present, `required === false` → format validation only when
 *     a value IS provided.
 *
 * For DB write: structured columns are NOT NULL in the Prisma schema.
 * When a structured field is deactivated, `createOrder` writes an empty
 * string `''` (satisfies NOT NULL without fabricating fake data).
 *
 * `countryId` is a foreign key — when the `country` field is deactivated,
 * `createOrder` resolves the default country server-side.
 *
 * The dynamic order fields pass (validating admin-defined CUSTOM fields
 * outside the structured set) is unchanged — it iterates over active
 * `OrderField` rows and only flags required + empty custom fields.
 *
 * ==========================================================================
 */

export async function POST(req: NextRequest) {
  // Rate limit: 10 orders / 10 min / IP (anti-spam + anti-resource-drain).
  const meta = clientMeta(req)
  const rl = rateLimitByIp(meta.ip, 'order-create', 10, 10 * 60 * 1000)
  if (!rl.ok) {
    return Response.json(
      { ok: false, error: 'طلبات كثيرة في وقت قصير. حاول لاحقاً.' },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfter) } },
    )
  }
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return Response.json({ ok: false, error: 'Requête invalide.' }, { status: 400 })
  }

  // Read ALL order fields (active AND inactive — needed to know required
  // flags + isActive state for each structured field). Build the schema
  // DYNAMICALLY so deactivated fields don't block checkout.
  const allOrderFields = await db.orderField.findMany()
  const dynamicSchema = buildOrderSchemaFromFields(allOrderFields)

  const parsed = dynamicSchema.safeParse(body)
  if (!parsed.success) {
    // Map structured column errors BACK to order field keys so the
    // frontend can highlight the specific input that failed.
    const fieldErrors: Record<string, string> = {}
    for (const issue of parsed.error.issues) {
      const pathKey = issue.path.join('.')
      const fieldKey = STRUCTURED_TO_FIELD_KEY[pathKey] || pathKey
      // Don't overwrite a more specific earlier error
      if (!fieldErrors[fieldKey]) {
        fieldErrors[fieldKey] = issue.message
      }
    }
    return Response.json(
      { ok: false, error: 'المرجو تصحيح الحقول المشار إليها بالأحمر.', fieldErrors },
      { status: 422 },
    )
  }
  const data = parsed.data as {
    customerFullName: string
    customerPhone: string
    customerEmail?: string
    countryId: string
    shippingCity: string
    shippingAddress: string
    shippingPostalCode?: string
    notes?: string
    couponCode?: string
    items: Array<{ productId: string; variantId?: string | null; quantity: number }>
    customFields?: Record<string, string>
    idempotencyKey?: string
  }

  // Server-side validation of DYNAMIC order fields against DB definitions.
  // Only iterate over ACTIVE fields. For STRUCTURED fields, skip the
  // required check entirely (baseSchema already enforced them). For
  // CUSTOM (admin-defined) fields, run required + type validation.
  const activeOrderFields = allOrderFields.filter((f) => f.isActive)
  const fieldErrors: Record<string, string> = {}
  const customFields: Record<string, string> = { ...(data.customFields || {}) }

  for (const f of activeOrderFields) {
    const structuredKey = FIELD_KEY_TO_STRUCTURED[f.key]
    const value = structuredKey
      ? String((data as Record<string, unknown>)[structuredKey] ?? '').trim()
      : (customFields[f.key] ?? '').trim()

    if (f.required && !value) {
      // For structured fields, baseSchema already added the error above.
      // Re-adding here would overwrite the Arabic message with a generic one.
      if (!structuredKey) {
        fieldErrors[f.key] = 'هذا الحقل إجباري.'
      }
      continue
    }
    if (!value) continue

    // type-specific validation (only for non-empty values)
    // IMPORTANT: phone length validation respects admin's minLength/maxLength
    // settings from the OrderField table. The old code had a HARDCODED {6,20}
    // check that rejected valid short numbers even when the admin set a lower
    // minLength. Now we only check the CHARACTER FORMAT (digits, spaces, +, (),
    // -) and let the admin's length settings control the bounds.
    if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      fieldErrors[f.key] = 'البريد الإلكتروني غير صالح.'
    } else if (f.type === 'phone' && !/^[+\d\s().-]+$/.test(value)) {
      fieldErrors[f.key] = 'رقم الهاتف غير صالح.'
    } else if (f.type === 'number' && Number.isNaN(Number(value))) {
      fieldErrors[f.key] = 'الرقم غير صالح.'
    } else if (f.type === 'select' && f.key !== 'country') {
      const opts = Array.isArray(f.options) ? (f.options as Array<{ value: string }>) : []
      if (!opts.some((o) => o.value === value)) {
        fieldErrors[f.key] = 'القيمة غير مسموحة.'
      }
    }

    // minLength / maxLength enforcement for ALL fields (structured + custom).
    // This respects the admin's configured bounds from the OrderField table.
    if (f.minLength && value.length < f.minLength) {
      fieldErrors[f.key] = `الحد الأدنى ${f.minLength} أحرف.`
    }
    if (f.maxLength && value.length > f.maxLength) {
      fieldErrors[f.key] = `الحد الأقصى ${f.maxLength} أحرف.`
    }
  }
  if (Object.keys(fieldErrors).length > 0) {
    return Response.json(
      { ok: false, error: 'المرجو تصحيح الحقول المشار إليها بالأحمر.', fieldErrors },
      { status: 422 },
    )
  }

  // Sanitize free-text inputs to prevent stored XSS in admin order view.
  // Defense-in-depth — the admin dashboard renders these as text.
  // For deactivated fields, store empty string (satisfies NOT NULL constraint
  // on `customer_phone`, `customer_full_name`, etc. without polluting the
  // record with fake data).
  const sanitizedInput = {
    customerFullName: (data.customerFullName || '').trim().slice(0, 120),
    customerPhone: (data.customerPhone || '').trim().slice(0, 20),
    customerEmail: data.customerEmail?.trim().slice(0, 200) || '',
    countryId: data.countryId,
    shippingCity: (data.shippingCity || '').trim().slice(0, 120),
    shippingAddress: (data.shippingAddress || '').trim().slice(0, 500),
    shippingPostalCode: data.shippingPostalCode?.trim().slice(0, 20) || '',
    notes: data.notes?.trim().slice(0, 1000) || '',
  }

  const meta2 = clientMeta(req)
  // CRITICAL: pass `items` + `customFields` + `couponCode` to createOrder.
  // The previous version spread only `sanitizedInput` (text fields) + meta2 +
  // idempotencyKey — which DROPPED `items`, causing createOrder to receive
  // `input.items = undefined` → resolveCartLines returned "Panier vide."
  // even when the client sent valid items. This was the root cause of the
  // checkout "تعذّر إتمام الطلب" failure.
  const result = await createOrder({
    ...sanitizedInput,
    items: data.items,
    customFields: data.customFields || {},
    couponCode: data.couponCode || undefined,
    ...meta2,
    idempotencyKey: data.idempotencyKey,
  })
  if (!result.ok) {
    // Log technical detail to server logs (no PII), but return a friendly
    // Arabic message to the customer. Never expose DB internals.
    console.error('[orders/create] failed:', result.error)
    return Response.json(
      { ok: false, error: result.error || 'تعذّر تسجيل الطلب. حاول مرة أخرى.' },
      { status: 400 },
    )
  }
  revalidateTag('catalog')
  return Response.json(result, { status: 201 })
}
