import { NextRequest } from 'next/server'
import { getAllProducts, getFeaturedProducts, getBestSellers, getNewArrivals, searchProducts } from '@/services/catalog'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const filter = searchParams.get('filter') // featured | best | new | all
  const q = searchParams.get('q')
  const take = Math.min(Number(searchParams.get('take')) || 24, 60)

  if (q) {
    return Response.json({ ok: true, products: await searchProducts(q, take) })
  }
  let products
  switch (filter) {
    case 'featured':
      products = await getFeaturedProducts(take)
      break
    case 'best':
      products = await getBestSellers(take)
      break
    case 'new':
      products = await getNewArrivals(take)
      break
    default:
      products = await getAllProducts(take)
  }
  return Response.json({ ok: true, products })
}
