import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/customers?q=...
 * Returns customers with their order count and total spent, optionally filtered by name/phone.
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const q = (req.nextUrl.searchParams.get('q') || '').trim().toLowerCase()

  const where = q
    ? {
        OR: [
          { fullName: { contains: q, mode: 'insensitive' as const } },
          { phone: { contains: q, mode: 'insensitive' as const } },
          { email: { contains: q, mode: 'insensitive' as const } },
        ],
      }
    : {}

  const customers = await db.customer.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 200,
    select: {
      id: true,
      fullName: true,
      email: true,
      phone: true,
      status: true,
      createdAt: true,
      country: {
        select: { id: true, name: true, code: true, currencySymbol: true, currencyCode: true },
      },
      _count: {
        select: { orders: true },
      },
      orders: {
        where: { status: { in: ['CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED'] } },
        select: { total: true, currencyCode: true },
      },
    },
  })

  const out = customers.map((c) => {
    const total = c.orders.reduce(
      (sum, o) => sum + Number(o.total),
      0,
    )
    return {
      id: c.id,
      fullName: c.fullName,
      email: c.email,
      phone: c.phone,
      status: c.status,
      createdAt: c.createdAt,
      country: c.country
        ? {
            name: c.country.name,
            code: c.country.code,
            currencySymbol: c.country.currencySymbol,
            currencyCode: c.country.currencyCode,
          }
        : null,
      orderCount: c._count.orders,
      totalSpent: total,
      currencyCode: c.country?.currencyCode || 'MAD',
      currencySymbol: c.country?.currencySymbol || 'DH',
    }
  })

  return Response.json({ ok: true, customers: out })
}
