import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission, isSuperAdmin, PERMISSION_SECTIONS, type PermissionAction } from '@/lib/permissions'
import { audit, clientMeta } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * PUT /api/admin/admin-users/[id]/permissions — set custom permissions on the
 * user's ROLE. (Permissions are stored on the role, not the user, so all users
 * with that role share them. For per-user overrides, create a dedicated role.)
 *
 * Body: { permissions: { section: [action, ...] } }
 */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('permissions', 'manage_settings')
  if (admin instanceof Response) return admin
  const { id } = await params
  const target = await db.adminUser.findUnique({ where: { id }, include: { role: true } })
  if (!target) return Response.json({ ok: false, error: 'غير موجود' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const perms = body.permissions
  if (!perms || typeof perms !== 'object') {
    return Response.json({ ok: false, error: 'permissions مطلوبة' }, { status: 422 })
  }

  // Validate: only known sections + actions; strip unknowns
  const validActions = new Set<PermissionAction>(['view', 'create', 'edit', 'delete', 'publish', 'manage_settings'])
  const cleaned: Record<string, string[]> = {}
  for (const section of PERMISSION_SECTIONS) {
    const acts = perms[section.key]
    if (Array.isArray(acts)) {
      cleaned[section.key] = acts.filter((a: any) => validActions.has(a))
    }
  }

  // Prevent privilege escalation: non-super-admin cannot grant admin_users / permissions / security
  if (!isSuperAdmin(admin)) {
    for (const restricted of ['admin_users', 'permissions', 'security']) {
      if (cleaned[restricted] && cleaned[restricted].length > 0) {
        return Response.json({ ok: false, error: `ممنوع منح صلاحيات ${restricted} إلا من المسؤول المطلق` }, { status: 403 })
      }
    }
  }

  // Prevent removing super-admin permissions from the last active super-admin
  if (target.role.slug === 'super-admin' && target.status === 'ACTIVE') {
    const count = await db.adminUser.count({
      where: { roleId: target.roleId, status: 'ACTIVE' },
    })
    if (count <= 1) {
      return Response.json({ ok: false, error: 'ممنوع تعديل صلاحيات آخر مسؤول مطلق' }, { status: 409 })
    }
  }

  const updated = await db.role.update({
    where: { id: target.roleId },
    data: { permissions: cleaned },
  })
  await audit(admin.id, 'permissions.update', 'role', target.roleId, { forUserId: id }, clientMeta(req))
  return Response.json({ ok: true, permissions: updated.permissions })
}
