import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/**
 * Navigation items — manages the header / footer / mobile menu links
 * rendered on the storefront. Stored in the `navigation_items` table.
 *
 * GET    /api/admin/navigation            — list all (tree)
 * POST   /api/admin/navigation            — create
 * PUT    /api/admin/navigation/[id]        — update
 * DELETE /api/admin/navigation/[id]        — delete
 */

const ALLOWED_LOCATIONS = ['header', 'footer', 'mobile'] as const

const navSchema = z.object({
  label: z.string().min(1).max(80),
  url: z.string().min(1).max(500),
  parentId: z.string().optional().nullable(),
  sortOrder: z.number().int().min(0).max(9999).default(0),
  isVisible: z.boolean().default(true),
  location: z.enum(ALLOWED_LOCATIONS).default('header'),
})

/** Security: block dangerous URL schemes. Only allow relative paths or https. */
function isSafeUrl(url: string): boolean {
  if (url.startsWith('/')) {
    // relative — block path traversal
    if (url.includes('\\') || url.startsWith('//')) return false
    return true
  }
  try {
    const u = new URL(url)
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return false
    // Block javascript:/data:/file: etc (already done by the protocol check)
    return true
  } catch {
    return false
  }
}

export async function GET() {
  const admin = await requirePermission('seo', 'view')
  if (admin instanceof Response) return admin
  const items = await db.navigationItem.findMany({
    orderBy: [{ location: 'asc' }, { sortOrder: 'asc' }],
  })
  return Response.json({ ok: true, items })
}

export async function POST(req: NextRequest) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin
  const body = await req.json().catch(() => ({}))
  const parsed = navSchema.safeParse(body)
  if (!parsed.success) {
    const fe: Record<string, string> = {}
    for (const e of parsed.error.issues) fe[e.path.join('.')] = e.message
    return jsonError('بيانات غير صالحة', 422, fe)
  }
  const d = parsed.data
  if (!isSafeUrl(d.url)) {
    return jsonError('رابط غير آمن. استعمل مساراً نسبياً (/page) أو https://', 422, { url: 'invalid' })
  }
  if (d.parentId) {
    const parent = await db.navigationItem.findUnique({ where: { id: d.parentId } })
    if (!parent) return jsonError('العنصر الأصل غير موجود', 422, { parentId: 'not_found' })
    if (parent.location !== d.location) {
      return jsonError('العنصر الأصل يجب أن يكون بنفس الموقع (header/footer/mobile)', 422, { parentId: 'location_mismatch' })
    }
  }
  const item = await db.navigationItem.create({
    data: {
      label: d.label,
      url: d.url,
      parentId: d.parentId ?? null,
      sortOrder: d.sortOrder,
      isVisible: d.isVisible,
      location: d.location,
    },
  })
  revalidateTag('settings')
  await audit(admin.id, 'navigation.create', 'navigation_item', item.id, { label: d.label, url: d.url, location: d.location }, clientMeta(req))
  return Response.json({ ok: true, item }, { status: 201 })
}
