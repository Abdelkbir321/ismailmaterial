import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const schema = z.object({
  label: z.string().min(1).max(80).optional(),
  url: z.string().min(1).max(500).optional(),
  parentId: z.string().nullable().optional(),
  sortOrder: z.number().int().min(0).max(9999).optional(),
  isVisible: z.boolean().optional(),
  location: z.enum(['header', 'footer', 'mobile']).optional(),
})

function isSafeUrl(url: string): boolean {
  if (url.startsWith('/')) return !url.includes('\\') && !url.startsWith('//')
  try {
    const u = new URL(url)
    return u.protocol === 'https:' || u.protocol === 'http:'
  } catch {
    return false
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin
  const { id } = await params
  const existing = await db.navigationItem.findUnique({ where: { id } })
  if (!existing) return jsonError('العنصر غير موجود', 404)
  const body = await req.json().catch(() => ({}))
  const parsed = schema.safeParse(body)
  if (!parsed.success) return jsonError('بيانات غير صالحة', 422)
  const d = parsed.data
  if (d.url !== undefined && !isSafeUrl(d.url)) {
    return jsonError('رابط غير آمن', 422, { url: 'invalid' })
  }
  if (d.parentId) {
    if (d.parentId === id) return jsonError('لا يمكن أن يكون العنصر أصلاً لنفسه', 422, { parentId: 'self' })
    const parent = await db.navigationItem.findUnique({ where: { id: d.parentId } })
    if (!parent) return jsonError('العنصر الأصل غير موجود', 422, { parentId: 'not_found' })
    const loc = d.location ?? existing.location
    if (parent.location !== loc) {
      return jsonError('العنصر الأصل يجب أن يكون بنفس الموقع', 422, { parentId: 'location_mismatch' })
    }
    // Loop check: walk up the parent chain to make sure we don't create a cycle
    let cursor: string | null = d.parentId
    const visited = new Set<string>([id])
    let depth = 0
    while (cursor && depth < 20) {
      if (visited.has(cursor)) return jsonError('هذا الربط يسبب حلقة (loop)', 422, { parentId: 'loop' })
      visited.add(cursor)
      const p = await db.navigationItem.findUnique({ where: { id: cursor }, select: { parentId: true } })
      cursor = p?.parentId ?? null
      depth++
    }
  }
  const updated = await db.navigationItem.update({ where: { id }, data: d })
  revalidateTag('settings')
  await audit(admin.id, 'navigation.update', 'navigation_item', id, { changed: Object.keys(d) }, clientMeta(req))
  return Response.json({ ok: true, item: updated })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin
  const { id } = await params
  // onDelete: Cascade — children are auto-deleted by Prisma
  await db.navigationItem.delete({ where: { id } }).catch(() => {})
  revalidateTag('settings')
  await audit(admin.id, 'navigation.delete', 'navigation_item', id, {}, clientMeta(req))
  return Response.json({ ok: true })
}
