import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)

  const { searchParams } = req.nextUrl
  const page = Math.max(1, Number(searchParams.get('page')) || 1)
  const pageSize = Math.min(50, Number(searchParams.get('pageSize')) || 20)
  const status = searchParams.get('status')
  const q = searchParams.get('q')

  const where = {
    ...(status ? { status } : {}),
    ...(q
      ? {
          OR: [
            { number: { contains: q, mode: 'insensitive' as const } },
            { customerFullName: { contains: q, mode: 'insensitive' as const } },
            { customerPhone: { contains: q } },
          ],
        }
      : {}),
  }
  const [items, total] = await Promise.all([
    db.order.findMany({
      where,
      orderBy: { placedAt: 'desc' },
      take: pageSize,
      skip: (page - 1) * pageSize,
      include: {
        country: { select: { name: true, code: true, currencySymbol: true } },
        _count: { select: { items: true } },
      },
    }),
    db.order.count({ where }),
  ])

  return Response.json({
    ok: true,
    items: items.map((o) => ({
      id: o.id,
      number: o.number,
      customerFullName: o.customerFullName,
      customerPhone: o.customerPhone,
      status: o.status,
      paymentMethod: o.paymentMethod,
      paymentStatus: o.paymentStatus,
      total: Number(o.total),
      currencyCode: o.currencyCode,
      currencySymbol: o.country.currencySymbol,
      itemCount: o._count.items,
      placedAt: o.placedAt,
      countryName: o.country.name,
    })),
    total,
    page,
    pageSize,
  })
}
