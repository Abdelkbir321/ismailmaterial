import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { updateOrderStatus } from '@/services/orders'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  const order = await db.order.findUnique({
    where: { id },
    include: {
      items: true,
      country: true,
      customer: true,
      statusHistory: { orderBy: { createdAt: 'desc' } },
    },
  })
  if (!order) return jsonError('Commande introuvable', 404)
  return Response.json({ ok: true, order })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  let body: { status?: string; adminNotes?: string; note?: string }
  try {
    body = await req.json()
  } catch {
    return jsonError('Requête invalide.')
  }
  if (!body.status) return jsonError('Statut requis.')
  const validStatuses = ['NEW', 'CONTACTED', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'RETURNED', 'UNREACHABLE']
  if (!validStatuses.includes(body.status)) return jsonError('Statut invalide.')

  const updated = await updateOrderStatus(id, body.status as any, admin.id, body.note ?? body.adminNotes)

  if (body.adminNotes !== undefined) {
    await db.order.update({ where: { id }, data: { adminNotes: body.adminNotes } })
  }
  const meta = clientMeta(req)
  await audit(admin.id, 'order.status_change', 'order', id, { status: body.status, note: body.note }, meta)
  revalidateTag('catalog')
  return Response.json({ ok: true, order: updated })
}
