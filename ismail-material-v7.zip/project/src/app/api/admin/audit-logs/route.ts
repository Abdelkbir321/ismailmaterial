import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { searchParams } = req.nextUrl
  const take = Math.min(100, Number(searchParams.get('take')) || 50)
  const logs = await db.auditLog.findMany({
    take,
    orderBy: { createdAt: 'desc' },
    include: { adminUser: { select: { email: true, fullName: true } } },
  })
  return Response.json({ ok: true, logs })
}
