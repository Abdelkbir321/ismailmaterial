import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { productInputSchema } from '@/validations'
import { sanitizeHtml, htmlToPlainText } from '@/lib/sanitize'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  const product = await db.product.findUnique({
    where: { id },
    include: {
      images: { orderBy: { sortOrder: 'asc' } },
      category: true,
      brand: true,
      variants: true,
    },
  })
  if (!product) return jsonError('Produit introuvable', 404)
  return Response.json({ ok: true, product })
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  const existing = await db.product.findUnique({ where: { id } })
  if (!existing) return jsonError('Produit introuvable', 404)
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return jsonError('Requête invalide.')
  }
  const parsed = productInputSchema.partial().safeParse(body)
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {}
    for (const e of parsed.error.issues) fieldErrors[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'Champs invalides', fieldErrors }, { status: 422 })
  }
  const d = parsed.data
  // uniqueness if changed
  if (d.slug && d.slug !== existing.slug) {
    if (await db.product.findUnique({ where: { slug: d.slug } }))
      return jsonError('Slug déjà utilisé', 409, { slug: 'Slug déjà utilisé' })
    // When slug changes, auto-create a 301 redirect from the old slug to the new
    // one so external links don't break. (Best-effort — if a redirect already
    // exists, we leave it.)
    try {
      await db.redirect.upsert({
        where: { fromPath: existing.slug.toLowerCase() },
        create: {
          fromPath: existing.slug.toLowerCase(),
          toPath: `/produits/${d.slug}`,
          statusCode: 301,
          isActive: true,
        },
        update: {},
      })
      revalidateTag('redirects')
    } catch {
      // ignore — not fatal
    }
  }
  if (d.sku && d.sku !== existing.sku) {
    if (await db.product.findUnique({ where: { sku: d.sku } }))
      return jsonError('SKU déjà utilisé', 409, { sku: 'SKU déjà utilisé' })
  }
  // Sanitize HTML/URL fields on update too.
  const update: Record<string, unknown> = { ...d }
  if (d.description !== undefined) update.description = d.description ? sanitizeHtml(d.description) : null
  if (d.shortDescription !== undefined) update.shortDescription = d.shortDescription ? htmlToPlainText(d.shortDescription, 500) : null
  if (d.seoTitle !== undefined) update.seoTitle = d.seoTitle ? htmlToPlainText(d.seoTitle, 200) : null
  if (d.seoDescription !== undefined) update.seoDescription = d.seoDescription ? htmlToPlainText(d.seoDescription, 300) : null
  if (d.canonicalUrl !== undefined && d.canonicalUrl) {
    try {
      const u = new URL(d.canonicalUrl)
      if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('bad proto')
    } catch {
      return jsonError('Canonical URL غير صالح', 422, { canonicalUrl: 'invalid' })
    }
  }
  if (d.ogImage !== undefined && d.ogImage) {
    try {
      const u = new URL(d.ogImage)
      if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('bad proto')
    } catch {
      return jsonError('OG image URL غير صالح', 422, { ogImage: 'invalid' })
    }
  }
  const wasPublished = existing.status === 'PUBLISHED'
  if (d.status === 'PUBLISHED' && !wasPublished) update.publishedAt = new Date()
  const product = await db.product.update({ where: { id }, data: update })
  const meta = clientMeta(req)
  await audit(admin.id, 'product.update', 'product', id, { changed: Object.keys(d) }, meta)
  revalidateTag('catalog')
  revalidateTag('sitemap')
  return Response.json({ ok: true, product })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  // soft delete -> archive
  const product = await db.product.update({
    where: { id },
    data: { status: 'ARCHIVED' },
  }).catch(() => null)
  if (!product) return jsonError('Produit introuvable', 404)
  const meta = clientMeta(req)
  await audit(admin.id, 'product.archive', 'product', id, { name: product.name }, meta)
  revalidateTag('catalog')
  revalidateTag('sitemap')
  return Response.json({ ok: true })
}

// reorder images: PATCH /api/admin/products/[id]/images  handled via separate route-less action on PUT body
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  const body = await req.json().catch(() => ({}))
  // quick status toggle
  if (body.status) {
    const product = await db.product.update({ where: { id }, data: { status: body.status } })
    await audit(admin.id, 'product.status_change', 'product', id, { status: body.status }, clientMeta(req))
    revalidateTag('catalog')
    return Response.json({ ok: true, status: product.status })
  }
  return jsonError('Unsupported patch')
}
