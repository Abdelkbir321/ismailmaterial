import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)

  const startOfDay = new Date()
  startOfDay.setHours(0, 0, 0, 0)

  const [
    totalOrders,
    todayOrders,
    pendingOrders,
    confirmedOrders,
    deliveredOrders,
    cancelledOrders,
    totalProducts,
    lowStockProducts,
    salesAgg,
    recentOrders,
    bestSellers,
  ] = await Promise.all([
    db.order.count(),
    db.order.count({ where: { placedAt: { gte: startOfDay } } }),
    db.order.count({ where: { status: 'NEW' } }),
    db.order.count({ where: { status: 'CONFIRMED' } }),
    db.order.count({ where: { status: 'DELIVERED' } }),
    db.order.count({ where: { status: 'CANCELLED' } }),
    db.product.count(),
    db.product.count({ where: { stockQuantity: { lte: 5 }, trackInventory: true, status: 'PUBLISHED' } }),
    db.order.aggregate({ _sum: { total: true }, where: { status: { in: ['CONFIRMED', 'SHIPPED', 'DELIVERED'] } } }),
    db.order.findMany({
      take: 8,
      orderBy: { placedAt: 'desc' },
      select: { id: true, number: true, customerFullName: true, status: true, total: true, placedAt: true },
    }),
    db.product.findMany({
      where: { salesCount: { gt: 0 } },
      orderBy: { salesCount: 'desc' },
      take: 5,
      select: { id: true, name: true, slug: true, salesCount: true, stockQuantity: true, price: true },
    }),
  ])

  return Response.json({
    ok: true,
    stats: {
      totalOrders,
      todayOrders,
      totalSales: Number(salesAgg._sum.total ?? 0),
      pendingOrders,
      confirmedOrders,
      deliveredOrders,
      cancelledOrders,
      totalProducts,
      lowStockProducts,
      currencyCode: 'MAD',
    },
    activity: {
      recentOrders,
      bestSellers: bestSellers.map((p) => ({ ...p, price: Number(p.price), mainImage: null })),
    },
  })
}
