import { NextRequest } from 'next/server'
import { requireAdmin, jsonError } from '@/lib/admin-api'
import { signDirectUpload, isCloudinaryConfigured } from '@/lib/cloudinary'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/upload/sign?folder=products/xxx&maxBytes=25000000
 * Returns the signature params the browser POSTs directly to Cloudinary.
 * The API secret NEVER leaves the server. Use this for large files to bypass
 * the Netlify function body-size limit (browser uploads directly to Cloudinary).
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  if (!isCloudinaryConfigured()) {
    return jsonError('Cloudinary غير مهيأ. عمر CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET فـ Environment Variables.', 503)
  }
  const folder = req.nextUrl.searchParams.get('folder') || 'media'
  const maxBytes = Number(req.nextUrl.searchParams.get('maxBytes')) || 25 * 1024 * 1024
  const sig = signDirectUpload(folder, maxBytes)
  if (!sig) return jsonError('تعذّر توليد التوقيع.', 500)
  return Response.json({ ok: true, ...sig, uploadUrl: `https://api.cloudinary.com/v1_1/${sig.cloudName}/image/upload` })
}
