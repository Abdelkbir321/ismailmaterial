import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { uploadBuffer, validateImageFile, verifyImageMagicBytes, isCloudinaryConfigured, validateExternalImageUrl } from '@/lib/cloudinary'
import { revalidateTag } from 'next/cache'
import { randomBytes } from 'node:crypto'

export const dynamic = 'force-dynamic'
// Give the function room for the (best-effort, short) HEAD validation + Cloudinary upload.
export const maxDuration = 30

/**
 * POST /api/admin/upload
 *
 * Two modes:
 *
 * A) File upload (multipart/form-data):
 *    file=@image.png, productId?, altText?, isMain?
 *    → uploads to Cloudinary (server-side SDK) OR falls back to a placeholder
 *      when Cloudinary is not configured. NEVER times out the function on
 *      external fetches (file is uploaded directly to Cloudinary).
 *
 * B) External URL (application/json):
 *    { externalUrl, productId?, altText?, isMain? }
 *    → FAST validation: format + SSRF check (instant) + best-effort 4s HEAD.
 *      If the HEAD fails (slow host, hotlink-block, timeout) we STILL ACCEPT
 *      the URL — the browser verifies rendering via <img onError>. This fixes
 *      the old "خطأ في الشبكة" (network error) that happened when the 12s
 *      server-side fetch timed out the Netlify function.
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const meta = clientMeta(req)
  const contentType = req.headers.get('content-type') || ''

  // ---- Branch B: external URL (JSON body) ----
  if (contentType.includes('application/json')) {
    let body: { externalUrl?: string; productId?: string; altText?: string; isMain?: boolean }
    try {
      body = await req.json()
    } catch {
      return jsonError('طلب غير صالح.')
    }
    const url = (body.externalUrl || '').trim()
    if (!url) return jsonError('الرابط مطلوب.', 422, { externalUrl: 'الرابط مطلوب' })

    // FAST, non-blocking validation (format + SSRF + best-effort 4s HEAD)
    const check = await validateExternalImageUrl(url)
    if (!check.ok) {
      return jsonError(check.error || 'الرابط غير صالح.', 422, { externalUrl: check.error || 'invalid' })
    }

    // store as media asset + optional product image
    const publicId = `external/${randomBytes(8).toString('hex')}`
    const asset = await db.mediaAsset.create({
      data: {
        sourceType: 'external',
        publicId,
        externalUrl: url,
        secureUrl: url,
        url,
        width: null,
        height: null,
        format: check.contentType?.split('/')[1] || null,
        bytes: check.bytes ?? null,
        resourceType: 'image',
        altText: body.altText || null,
        tags: [],
        uploadedByAdminId: admin.id,
      },
    })

    let image = null
    if (body.productId) {
      const maxSort = await db.productImage.aggregate({ where: { productId: body.productId }, _max: { sortOrder: true } })
      image = await db.productImage.create({
        data: {
          productId: body.productId,
          sourceType: 'external',
          publicId,
          externalUrl: url,
          secureUrl: url,
          url,
          altText: body.altText || null,
          sortOrder: (maxSort._max.sortOrder ?? -1) + 1,
          isMain: body.isMain || false,
        },
      })
      if (body.isMain) {
        await db.productImage.updateMany({ where: { productId: body.productId, NOT: { id: image.id } }, data: { isMain: false } })
      }
      revalidateTag('catalog')
    }

    await audit(admin.id, 'media.upload', 'media', asset.id, { sourceType: 'external', url, productId: body.productId, verified: check.verified }, meta)
    revalidateTag('settings')
    return Response.json({
      ok: true,
      asset,
      image,
      sourceType: 'external',
      verified: check.verified, // true = server confirmed image content-type; false = accepted, browser verifies
      cloudinary: isCloudinaryConfigured(),
    }, { status: 201 })
  }

  // ---- Branch A: file upload (multipart) ----
  const formData = await req.formData()
  const file = formData.get('file') as File | null
  const productId = (formData.get('productId') as string) || null
  const altText = (formData.get('altText') as string) || null
  const isMain = formData.get('isMain') === 'true'

  if (!file) return jsonError('ما وصلش حتى ملف.')
  const validation = validateImageFile({ type: file.type, size: file.size, name: file.name })
  if (!validation.ok) return jsonError(validation.error || 'ملف غير صالح.')

  const buffer = Buffer.from(await file.arrayBuffer())

  // Magic-byte verification — does NOT trust the browser-supplied MIME type.
  // Defeats attacks where a .jpg is actually an HTML/JS file (a common
  // stored-XSS vector for image-upload features).
  const magic = verifyImageMagicBytes(buffer)
  if (!magic.ok) {
    return jsonError('محتوى الملف ما كيتطابقش مع نوع الصورة المعلن عنه. الملف مرفوض.')
  }

  let upload: { publicId: string; secureUrl: string; url: string; width?: number; height?: number; format?: string; bytes?: number } | null = null
  if (isCloudinaryConfigured()) {
    const folder = productId ? `products/${productId}` : 'media'
    upload = await uploadBuffer(buffer, folder)
  }

  let publicId = upload?.publicId
  let secureUrl = upload?.secureUrl
  let url = upload?.url
  let width = upload?.width
  let height = upload?.height
  let format = upload?.format
  let bytes = upload?.bytes
  let sourceType = 'cloudinary'

  if (!upload) {
    // Graceful fallback when Cloudinary not configured — placeholder image
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg'
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 60)
    publicId = `local/${Date.now()}-${safeName}`
    secureUrl = `https://placehold.co/800x800/f5f5f4/1c1917?text=${encodeURIComponent(file.name.slice(0, 20))}`
    url = secureUrl
    width = 800
    height = 800
    format = ext
    bytes = file.size
    sourceType = 'placeholder'
  }

  const asset = await db.mediaAsset.create({
    data: {
      sourceType,
      publicId: publicId!,
      secureUrl: secureUrl!,
      url: url!,
      width: width ?? null,
      height: height ?? null,
      format: format ?? null,
      bytes: bytes ?? null,
      resourceType: 'image',
      altText,
      tags: [],
      uploadedByAdminId: admin.id,
    },
  })

  let image = null
  if (productId) {
    const maxSort = await db.productImage.aggregate({ where: { productId }, _max: { sortOrder: true } })
    image = await db.productImage.create({
      data: {
        productId,
        sourceType,
        publicId: publicId!,
        externalUrl: sourceType === 'external' ? url : null,
        secureUrl: secureUrl!,
        url: url!,
        width: width ?? null,
        height: height ?? null,
        format: format ?? null,
        altText,
        sortOrder: (maxSort._max.sortOrder ?? -1) + 1,
        isMain,
      },
    })
    if (isMain) {
      await db.productImage.updateMany({ where: { productId, NOT: { id: image.id } }, data: { isMain: false } })
    }
    revalidateTag('catalog')
  }

  await audit(admin.id, 'media.upload', 'media', asset.id, { sourceType, publicId, productId }, meta)
  revalidateTag('settings')
  return Response.json({ ok: true, asset, image, sourceType, cloudinary: isCloudinaryConfigured() }, { status: 201 })
}

/** GET /api/admin/upload/status — whether Cloudinary is configured */
export async function GET() {
  return Response.json({ ok: true, configured: isCloudinaryConfigured() })
}
