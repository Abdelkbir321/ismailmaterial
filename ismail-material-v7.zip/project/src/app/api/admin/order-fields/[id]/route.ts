import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/** PUT /api/admin/order-fields/[id] — update (preserves old order data: key is immutable) */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const { id } = await params
  const existing = await db.orderField.findUnique({ where: { id } })
  if (!existing) return jsonError('الحقل غير موجود.', 404)
  const b = await req.json().catch(() => ({}))
  // key is NOT updatable — changing it would break old orders' customFields
  const f = await db.orderField.update({
    where: { id },
    data: {
      type: b.type ?? undefined,
      labelAr: b.labelAr ?? undefined,
      labelFr: b.labelFr ?? undefined,
      labelEn: b.labelEn ?? undefined,
      placeholderAr: b.placeholderAr ?? undefined,
      placeholderFr: b.placeholderFr ?? undefined,
      placeholderEn: b.placeholderEn ?? undefined,
      helpTextAr: b.helpTextAr ?? undefined,
      helpTextFr: b.helpTextFr ?? undefined,
      helpTextEn: b.helpTextEn ?? undefined,
      options: b.options ?? undefined,
      required: b.required ?? undefined,
      isActive: b.isActive ?? undefined,
      sortOrder: b.sortOrder ?? undefined,
      width: b.width ?? undefined,
      defaultValue: b.defaultValue ?? undefined,
    },
  })
  revalidateTag('settings')
  await audit(admin.id, 'order_field.update', 'order_field', id, { changed: Object.keys(b) }, clientMeta(req))
  return Response.json({ ok: true, field: f })
}

/** DELETE — soft delete (isActive=false). Hard delete only if no orders reference it. */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const { id } = await params
  const existing = await db.orderField.findUnique({ where: { id } })
  if (!existing) return jsonError('الحقل غير موجود.', 404)
  // Check if any order uses this field's key in customFields
  const orders = await db.order.findMany({ where: { customFields: { path: [existing.key], not: { equals: null } } } })
  if (orders.length > 0) {
    // Soft-delete: hide it instead, preserve old order data
    await db.orderField.update({ where: { id }, data: { isActive: false } })
    revalidateTag('settings')
    await audit(admin.id, 'order_field.deactivate', 'order_field', id, { key: existing.key, ordersUsing: orders.length }, clientMeta(req))
    return Response.json({ ok: true, deactivated: true, message: `تم إخفاء الحقل (${orders.length} طلبات قديمة كيستعملونه).` })
  }
  await db.orderField.delete({ where: { id } })
  revalidateTag('settings')
  await audit(admin.id, 'order_field.delete', 'order_field', id, { key: existing.key }, clientMeta(req))
  return Response.json({ ok: true })
}
