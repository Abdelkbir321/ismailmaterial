import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/** GET /api/admin/order-fields — admin list (all fields, incl inactive) */
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const fields = await db.orderField.findMany({ orderBy: { sortOrder: 'asc' } })
  return Response.json({ ok: true, fields })
}

/**
 * POST /api/admin/order-fields — create
 * Body: { key, type, labelAr, labelFr, labelEn, required, isActive, sortOrder, width, ... }
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const b = await req.json().catch(() => ({}))
  if (!b.key || !b.labelAr || !b.labelFr || !b.labelEn) {
    return jsonError('key و labelAr و labelFr و labelEn مطلوبين.', 422)
  }
  if (await db.orderField.findUnique({ where: { key: b.key } })) {
    return jsonError('key موجود من قبل.', 409, { key: 'موجود' })
  }
  const f = await db.orderField.create({
    data: {
      key: b.key,
      type: b.type || 'text',
      labelAr: b.labelAr,
      labelFr: b.labelFr,
      labelEn: b.labelEn,
      placeholderAr: b.placeholderAr || null,
      placeholderFr: b.placeholderFr || null,
      placeholderEn: b.placeholderEn || null,
      helpTextAr: b.helpTextAr || null,
      helpTextFr: b.helpTextFr || null,
      helpTextEn: b.helpTextEn || null,
      options: b.options || [],
      required: !!b.required,
      isActive: b.isActive !== false,
      sortOrder: b.sortOrder ?? 0,
      width: b.width || 'full',
      defaultValue: b.defaultValue || null,
    },
  })
  revalidateTag('settings')
  await audit(admin.id, 'order_field.create', 'order_field', f.id, { key: f.key }, clientMeta(req))
  return Response.json({ ok: true, field: f }, { status: 201 })
}
