import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const schema = z.object({
  fromPath: z.string().startsWith('/').optional(),
  toPath: z.string().min(1).optional(),
  statusCode: z.union([z.literal(301), z.literal(302)]).optional(),
  isActive: z.boolean().optional(),
})

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin
  const { id } = await params
  const existing = await db.redirect.findUnique({ where: { id } })
  if (!existing) return jsonError('التوجيه غير موجود.', 404)
  const body = await req.json().catch(() => ({}))
  const parsed = schema.safeParse(body)
  if (!parsed.success) return jsonError('بيانات غير صالحة.', 422)
  const d = parsed.data
  // fromPath is NOT updatable (changing it would break the redirect chain)
  const updated = await db.redirect.update({
    where: { id },
    data: {
      toPath: d.toPath ?? undefined,
      statusCode: d.statusCode ?? undefined,
      isActive: d.isActive ?? undefined,
    },
  })
  revalidateTag('redirects')
  await audit(admin.id, 'redirect.update', 'redirect', id, { changed: Object.keys(d) }, clientMeta(req))
  return Response.json({ ok: true, redirect: updated })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin
  const { id } = await params
  await db.redirect.delete({ where: { id } }).catch(() => {})
  revalidateTag('redirects')
  await audit(admin.id, 'redirect.delete', 'redirect', id, {}, clientMeta(req))
  return Response.json({ ok: true })
}
