import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/** GET /api/admin/redirects — list all redirects */
export async function GET() {
  const admin = await requirePermission('seo', 'view')
  if (admin instanceof Response) return admin
  const redirects = await db.redirect.findMany({ orderBy: { fromPath: 'asc' } })
  return Response.json({ ok: true, redirects })
}

const schema = z.object({
  fromPath: z.string().min(1).max(500).startsWith('/'),
  toPath: z.string().min(1).max(500),
  statusCode: z.union([z.literal(301), z.literal(302)]).default(301),
  isActive: z.boolean().default(true),
})

/** POST — create redirect (with loop detection) */
export async function POST(req: NextRequest) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin
  const body = await req.json().catch(() => ({}))
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    const fe: Record<string, string> = {}
    for (const e of parsed.error.issues) fe[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'بيانات غير صالحة', fieldErrors: fe }, { status: 422 })
  }
  const d = parsed.data

  // Normalize: ensure fromPath starts with /, lowercase for case-insensitive match
  const fromPath = d.fromPath.toLowerCase().replace(/\/+$/, '') || '/'
  const toPath = d.toPath

  // Prevent self-redirect (loop)
  if (fromPath === toPath.toLowerCase()) {
    return jsonError('لا يمكن توجيه الرابط إلى نفسه (loop).', 422, { fromPath: 'loop' })
  }

  // Check for chain loops: follow the chain from toPath, see if we return to fromPath
  let current = toPath.toLowerCase().replace(/\/+$/, '') || '/'
  const visited = new Set<string>([fromPath])
  let depth = 0
  while (depth < 20) {
    if (current === fromPath) {
      return jsonError('هذا التوجيه يسبب حلقة (redirect loop).', 422, { fromPath: 'loop' })
    }
    if (visited.has(current)) break
    visited.add(current)
    const next = await db.redirect.findUnique({ where: { fromPath: current }, select: { toPath: true } })
    if (!next) break
    current = next.toPath.toLowerCase().replace(/\/+$/, '') || '/'
    depth++
  }

  // Prevent open redirect: toPath must be relative (starts with /) OR same-origin https
  try {
    const toUrl = new URL(toPath, 'https://example.com')
    if (toUrl.origin !== 'https://example.com' && !toPath.startsWith('/')) {
      return jsonError('الوجهة خاصها تكون داخل الموقع (/path) أو HTTPS بنفس الدومين.', 422, { toPath: 'invalid' })
    }
  } catch {
    return jsonError('وجهة غير صالحة.', 422, { toPath: 'invalid' })
  }

  // Uniqueness
  if (await db.redirect.findUnique({ where: { fromPath } })) {
    return jsonError('هذا الرابط مصدر توجيه آخر موجود.', 409, { fromPath: 'موجود' })
  }

  const redirect = await db.redirect.create({ data: { fromPath, toPath: d.toPath, statusCode: d.statusCode, isActive: d.isActive } })
  revalidateTag('redirects')
  await audit(admin.id, 'redirect.create', 'redirect', redirect.id, { fromPath, toPath }, clientMeta(req))
  return Response.json({ ok: true, redirect }, { status: 201 })
}
