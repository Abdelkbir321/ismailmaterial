import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/visual-identity
 * Returns the current visual-identity settings (logo, favicon, colors,
 * logo size, logo motion, logo visual, logo mobile, hero scene, site identity)
 * + a flag indicating whether Cloudinary is configured.
 */
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const keys = [
    'site_logo_source',
    'site_logo_public_id',
    'site_logo_url',
    'site_logo_alt',
    'logo_light_url',
    'logo_dark_url',
    'logo_mobile_url',
    'favicon_url',
    'favicon_cache_bust',
    'primary_color',
    'accent_color',
    'logo_size',
    'logo_motion',
    // === expanded logo controls ===
    'logo_visual',   // JSON: shadow/glow/border/background/radius/padding
    'logo_mobile',   // JSON: mobile disable animation + separate size
    // === hero image (replaces old 3D scene) ===
    'hero_image_url',  // direct image URL shown on homepage hero
    // === site identity (favicon + site name/description in one place) ===
    'site_name',
    'site_tagline',
    'site_description',
  ]
  const rows = await db.siteSetting.findMany({ where: { key: { in: keys } } })
  const settings: Record<string, string | null> = {}
  for (const k of keys) settings[k] = rows.find((r) => r.key === k)?.value ?? null

  const cloudinaryConfigured = !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET)

  return Response.json({ ok: true, settings, cloudinaryConfigured })
}

/**
 * PUT /api/admin/visual-identity
 * Body: { settings: { key: value, ... } }
 * Persists visual-identity settings. Each value is a string (URL, color,
 * or JSON-stringified object for nested settings).
 *
 * On every PUT that includes favicon_url, we also bump `favicon_cache_bust`
 * so the layout's metadata re-emits the favicon URL with a new ?v=... param.
 */
export async function PUT(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  let body: { settings?: Record<string, string> }
  try {
    body = await req.json()
  } catch {
    return jsonError('طلب غير صالح.')
  }
  if (!body.settings) return jsonError('settings مطلوبة.', 422)

  const allowed = new Set([
    'site_logo_source',
    'site_logo_public_id',
    'site_logo_url',
    'site_logo_alt',
    'logo_light_url',
    'logo_dark_url',
    'logo_mobile_url',
    'favicon_url',
    'favicon_cache_bust',
    'primary_color',
    'accent_color',
    'logo_size',
    'logo_motion',
    'logo_visual',
    'logo_mobile',
    'hero_image_url',
    'site_name',
    'site_tagline',
    'site_description',
  ])

  // === VALIDATION ===

  const faviconUrl = body.settings['favicon_url']
  if (faviconUrl && faviconUrl.trim()) {
    const trimmed = faviconUrl.trim()
    if (!/^https?:\/\/[^\s]+$/.test(trimmed) && !trimmed.startsWith('/')) {
      return jsonError('رابط الفافيكون غير صالح.', 422)
    }
  }

  // Validate hero_image_url format if non-empty
  const heroImageUrl = body.settings['hero_image_url']
  if (heroImageUrl && heroImageUrl.trim()) {
    const trimmed = heroImageUrl.trim()
    if (!/^https?:\/\/[^\s]+$/.test(trimmed) && !trimmed.startsWith('/')) {
      return jsonError('رابط صورة الواجهة الرئيسية غير صالح. مثال: https://example.com/hero.jpg', 422)
    }
  }

  const logoSizeRaw = body.settings['logo_size']
  if (logoSizeRaw && logoSizeRaw.trim()) {
    try {
      const parsed = JSON.parse(logoSizeRaw)
      if (typeof parsed !== 'object' || parsed === null) throw new Error()
      if (parsed.width !== undefined && (typeof parsed.width !== 'number' || parsed.width < 8 || parsed.width > 200)) {
        return jsonError('عرض اللوغو خاصو يكون بين 8 و 200 بكسل.', 422)
      }
      if (parsed.height !== undefined && (typeof parsed.height !== 'number' || parsed.height < 8 || parsed.height > 200)) {
        return jsonError('ارتفاع اللوغو خاصو يكون بين 8 و 200 بكسل.', 422)
      }
    } catch {
      return jsonError('صيغة logo_size غير صالحة.', 422)
    }
  }

  const logoMotionRaw = body.settings['logo_motion']
  if (logoMotionRaw && logoMotionRaw.trim()) {
    try {
      const parsed = JSON.parse(logoMotionRaw)
      if (typeof parsed !== 'object' || parsed === null) throw new Error()
      const validTypes = ['breathe', 'float', 'rotate', 'pulse', 'rotate3d', 'tilt', 'none']
      if (parsed.type && !validTypes.includes(parsed.type)) {
        return jsonError(`نوع حركة غير صالح. المتاح: ${validTypes.join(', ')}`, 422)
      }
      if (parsed.speed !== undefined && ![0.5, 1, 2].includes(parsed.speed)) {
        return jsonError('سرعة الحركة خاصها تكون 0.5 أو 1 أو 2.', 422)
      }
      if (parsed.intensity !== undefined && ![0.3, 0.5, 0.8].includes(parsed.intensity)) {
        return jsonError('شدة الحركة خاصها تكون 0.3 أو 0.5 أو 0.8.', 422)
      }
    } catch {
      return jsonError('صيغة logo_motion غير صالحة.', 422)
    }
  }

  // Validate colors
  for (const colorKey of ['primary_color', 'accent_color']) {
    const v = body.settings[colorKey]
    if (v && v.trim() && !/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(v.trim())) {
      return jsonError(`${colorKey} خاصو يكون HEX صالح.`, 422)
    }
  }

  // Bump favicon_cache_bust whenever favicon_url changes
  if ('favicon_url' in body.settings) {
    body.settings['favicon_cache_bust'] = String(Date.now())
  }

  // Persist each setting
  for (const [key, value] of Object.entries(body.settings)) {
    if (!allowed.has(key)) continue
    const isJson = ['logo_size', 'logo_motion', 'logo_visual', 'logo_mobile'].includes(key)
    const group = 'visual'
    const type = isJson ? 'json' : key.includes('color') ? 'text' : key === 'site_name' || key === 'site_tagline' || key === 'site_description' ? 'text' : 'image'
    await db.siteSetting.upsert({
      where: { key },
      create: { key, value: String(value), group, type, isPublic: true },
      update: { value: String(value) },
    })
  }

  // Invalidate caches
  revalidateTag('settings')
  revalidateTag('catalog')
  revalidateTag('sitemap')

  await audit(admin.id, 'settings.visual_identity', 'setting', null, { keys: Object.keys(body.settings) }, clientMeta(req))
  return Response.json({ ok: true })
}
