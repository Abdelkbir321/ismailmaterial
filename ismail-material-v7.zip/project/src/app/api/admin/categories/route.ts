import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'
import { categoryInputSchema } from '@/validations'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const categories = await db.category.findMany({ orderBy: { sortOrder: 'asc' }, include: { _count: { select: { products: true } } } })
  return Response.json({ ok: true, categories })
}
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const parsed = categoryInputSchema.safeParse(await req.json().catch(() => ({})))
  if (!parsed.success) return jsonError('Champs invalides', 422)
  const d = parsed.data
  if (await db.category.findUnique({ where: { slug: d.slug } })) return jsonError('Slug déjà utilisé', 409)
  const category = await db.category.create({ data: d as any })
  revalidateTag('catalog')
  return Response.json({ ok: true, category }, { status: 201 })
}
