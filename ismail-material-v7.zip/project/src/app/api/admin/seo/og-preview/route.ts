import { NextRequest } from 'next/server'
import { requirePermission } from '@/lib/permissions'
import { jsonError } from '@/lib/admin-api'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

/**
 * POST /api/admin/seo/og-preview
 * Body: { type: 'home'|'product'|'category'|'brand'|'page', slug?, title, description, image }
 *
 * Returns the absolute URLs that would be used for:
 *   - the page itself (canonical)
 *   - the Open Graph image
 *   - a length-aware validation (title ≤ 60, description ≤ 155 are typical
 *     Google snippet limits).
 *
 * This is a *preview helper* — it does NOT persist anything. The admin UI
 * uses it to show a Google-snippet + Facebook-card preview before the user
 * saves SEO changes.
 */
const TYPES = ['home', 'product', 'category', 'brand', 'page'] as const
type PreviewType = (typeof TYPES)[number]

function pathFor(type: PreviewType, slug?: string): string {
  switch (type) {
    case 'home':
      return '/'
    case 'product':
      return `/produits/${slug || 'mon-produit'}`
    case 'category':
      return `/categories/${slug || 'ma-categorie'}`
    case 'brand':
      return `/brands/${slug || 'ma-marque'}`
    case 'page':
      return `/page/${slug || 'ma-page'}`
  }
}

export async function POST(req: NextRequest) {
  const admin = await requirePermission('seo', 'view')
  if (admin instanceof Response) return admin

  const body = await req.json().catch(() => ({}))
  const type = (body.type || 'home') as PreviewType
  if (!TYPES.includes(type)) return jsonError('نوع غير صالح', 422)
  const slug = typeof body.slug === 'string' ? body.slug.trim() : undefined
  const title = typeof body.title === 'string' ? body.title.slice(0, 200) : ''
  const description = typeof body.description === 'string' ? body.description.slice(0, 500) : ''
  const image = typeof body.image === 'string' ? body.image.slice(0, 500) : ''

  // Resolve site URL from DB → env (mirror the sitemap logic).
  let siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/+$/, '')
  try {
    const row = await db.siteSetting.findUnique({ where: { key: 'site_url' } })
    if (row?.value && /^https?:\/\/[^/]+/.test(row.value)) {
      siteUrl = row.value.replace(/\/+$/, '')
    }
  } catch {
    // ignore
  }

  const path = pathFor(type, slug)
  const absoluteUrl = `${siteUrl}${path}`

  // Google snippet best practices
  const titleLengthOk = title.length >= 30 && title.length <= 60
  const descriptionLengthOk = description.length >= 70 && description.length <= 155
  const imageValid = image.startsWith('http') || image.startsWith('/')

  return Response.json({
    ok: true,
    preview: {
      url: absoluteUrl,
      canonical: absoluteUrl,
      title,
      description,
      image: image || null,
    },
    checks: {
      titleLength: title.length,
      titleLengthOk,
      descriptionLength: description.length,
      descriptionLengthOk,
      imageValid,
      imageDimensions: imageValid ? '800x800 recommended' : 'missing',
    },
    warnings: [
      title.length === 0 ? 'العنوان فارغ' : null,
      title.length > 60 ? 'العنوان طويل — Google قد يقصّه' : null,
      title.length < 30 && title.length > 0 ? 'العنوان قصير — استهدف 30–60 حرفاً' : null,
      description.length > 155 ? 'الوصف طويل — Google قد يقصّه' : null,
      description.length < 70 && description.length > 0 ? 'الوصف قصير — استهدف 70–155 حرفاً' : null,
      !imageValid ? 'لا توجد صورة OG — شاركات السوشال ميديا ستظهر بدون صورة' : null,
    ].filter(Boolean),
  })
}
