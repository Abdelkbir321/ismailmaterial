import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/seo/sitemap-status
 *
 * Returns a snapshot of what the sitemap will contain:
 *   - counts of indexable products / categories / brands / pages
 *   - excluded counts (draft, archived, noindex)
 *   - the resolved site URL
 *   - the last time the catalog was touched (max updatedAt)
 *
 * Used by the "SEO والروابط" admin page to show whether the sitemap is
 * up-to-date and how many URLs are published.
 */
export async function GET(_req: NextRequest) {
  const admin = await requirePermission('seo', 'view')
  if (admin instanceof Response) return admin

  try {
    const [
      publishedProducts,
      draftProducts,
      archivedProducts,
      noindexProducts,
      visibleCategories,
      hiddenCategories,
      visibleBrands,
      visiblePages,
      redirectsActive,
      redirectsTotal,
      lastUpdatedProduct,
      lastUpdatedCategory,
    ] = await Promise.all([
      db.product.count({ where: { status: 'PUBLISHED', noindex: false } }),
      db.product.count({ where: { status: 'DRAFT' } }),
      db.product.count({ where: { status: 'ARCHIVED' } }),
      db.product.count({ where: { noindex: true } }),
      db.category.count({ where: { isVisible: true } }),
      db.category.count({ where: { isVisible: false } }),
      db.brand.count({ where: { isVisible: true } }),
      db.page.count({ where: { isVisible: true } }),
      db.redirect.count({ where: { isActive: true } }),
      db.redirect.count(),
      db.product.findFirst({ orderBy: { updatedAt: 'desc' }, select: { updatedAt: true } }),
      db.category.findFirst({ orderBy: { updatedAt: 'desc' }, select: { updatedAt: true } }),
    ])

    // Resolve the site URL (same logic as the sitemap)
    const siteRow = await db.siteSetting.findUnique({ where: { key: 'site_url' } })
    const siteUrl =
      (siteRow?.value && /^https?:\/\/[^/]+/.test(siteRow.value) && siteRow.value.replace(/\/+$/, '')) ||
      (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/+$/, '')

    const totalUrls =
      5 + // static routes
      publishedProducts +
      visibleCategories +
      visibleBrands +
      visiblePages

    const lastModifiedCandidates = [
      lastUpdatedProduct?.updatedAt,
      lastUpdatedCategory?.updatedAt,
    ].filter(Boolean) as Date[]
    const lastModified = lastModifiedCandidates.length
      ? new Date(Math.max(...lastModifiedCandidates.map((d) => d.getTime())))
      : null

    return Response.json({
      ok: true,
      siteUrl,
      sitemapUrl: `${siteUrl}/sitemap.xml`,
      robotsUrl: `${siteUrl}/robots.txt`,
      counts: {
        productsPublished: publishedProducts,
        productsDraft: draftProducts,
        productsArchived: archivedProducts,
        productsNoindex: noindexProducts,
        categoriesVisible: visibleCategories,
        categoriesHidden: hiddenCategories,
        brandsVisible: visibleBrands,
        pagesVisible: visiblePages,
      },
      redirects: { active: redirectsActive, total: redirectsTotal },
      totalUrls,
      lastContentUpdate: lastModified,
    })
  } catch (e) {
    return jsonError('فشل في قراءة حالة Sitemap من قاعدة البيانات.', 500)
  }
}
