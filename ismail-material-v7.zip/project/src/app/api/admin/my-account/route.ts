import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentAdmin } from '@/lib/auth'
import { hashPassword, verifyPassword } from '@/lib/password'
import { audit, clientMeta } from '@/lib/admin-api'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/** GET /api/admin/my-account — current admin's profile */
export async function GET() {
  const admin = await getCurrentAdmin()
  if (!admin) return Response.json({ ok: false, error: 'غير مصرّح' }, { status: 401 })
  return Response.json({
    ok: true,
    account: {
      id: admin.id,
      email: admin.email,
      fullName: admin.fullName,
      roleId: admin.roleId,
      role: { slug: admin.role.slug, name: admin.role.name, permissions: admin.role.permissions },
      status: admin.status,
      lastLoginAt: admin.lastLoginAt,
      lastLoginIp: admin.lastLoginIp,
    },
  })
}

const profileSchema = z.object({
  fullName: z.string().min(2).max(120).optional(),
  email: z.string().email().optional(),
})

/** PUT /api/admin/my-account — update own profile (name, email) */
export async function PUT(req: NextRequest) {
  const admin = await getCurrentAdmin()
  if (!admin) return Response.json({ ok: false, error: 'غير مصرّح' }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const parsed = profileSchema.safeParse(body)
  if (!parsed.success) {
    const fe: Record<string, string> = {}
    for (const e of parsed.error.issues) fe[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'بيانات غير صالحة', fieldErrors: fe }, { status: 422 })
  }
  const d = parsed.data
  const update: Record<string, unknown> = {}
  if (d.fullName) update.fullName = d.fullName
  if (d.email && d.email.toLowerCase() !== admin.email) {
    // check email not taken by someone else
    const existing = await db.adminUser.findUnique({ where: { email: d.email.toLowerCase() } })
    if (existing && existing.id !== admin.id) {
      return Response.json({ ok: false, error: 'البريد مستعمل', fieldErrors: { email: 'مستعمل' } }, { status: 409 })
    }
    update.email = d.email.toLowerCase()
  }
  if (Object.keys(update).length === 0) {
    return Response.json({ ok: false, error: 'لا توجد تغييرات' }, { status: 400 })
  }
  const updated = await db.adminUser.update({ where: { id: admin.id }, data: update, include: { role: true } })
  await audit(admin.id, 'my_account.update', 'admin_user', admin.id, { changed: Object.keys(update) }, clientMeta(req))
  return Response.json({ ok: true, account: { ...updated, passwordHash: undefined } })
}
