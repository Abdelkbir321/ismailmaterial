import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/inventory
 * Returns products where trackInventory=true AND stockQuantity <= lowStockThreshold,
 * ordered by stockQuantity ascending (lowest first).
 */
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  // Prisma can't easily compare two columns; fetch candidates then filter.
  const products = await db.product.findMany({
    where: {
      trackInventory: true,
      status: { in: ['PUBLISHED', 'OUT_OF_STOCK', 'DRAFT'] },
    },
    select: {
      id: true,
      name: true,
      slug: true,
      sku: true,
      stockQuantity: true,
      lowStockThreshold: true,
      status: true,
      trackInventory: true,
      currencyCode: true,
      images: {
        where: { isMain: true },
        take: 1,
        select: { secureUrl: true, url: true },
      },
    },
  })

  const items = products
    .filter(
      (p) =>
        Number(p.stockQuantity) <= Number(p.lowStockThreshold ?? 5),
    )
    .sort((a, b) => Number(a.stockQuantity) - Number(b.stockQuantity))
    .map((p) => ({
      id: p.id,
      name: p.name,
      slug: p.slug,
      sku: p.sku,
      stockQuantity: Number(p.stockQuantity),
      lowStockThreshold: Number(p.lowStockThreshold ?? 5),
      status: p.status,
      trackInventory: p.trackInventory,
      currencyCode: p.currencyCode,
      mainImage: p.images[0]?.secureUrl || p.images[0]?.url || null,
    }))

  return Response.json({ ok: true, items })
}
