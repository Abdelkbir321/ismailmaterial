import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/**
 * PATCH /api/admin/media/[id]
 * Body: { altText?: string }
 * Update alt text of a media asset.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const { id } = await params
  const existing = await db.mediaAsset.findUnique({ where: { id } })
  if (!existing) return jsonError('الأصل غير موجود.', 404)
  const body = await req.json().catch(() => ({}))
  const updated = await db.mediaAsset.update({
    where: { id },
    data: {
      altText: body.altText !== undefined ? String(body.altText) || null : undefined,
    },
  })
  await audit(admin.id, 'media.update', 'media', id, { changed: Object.keys(body) }, clientMeta(req))
  revalidateTag('settings')
  return Response.json({ ok: true, asset: updated })
}

/**
 * DELETE /api/admin/media/[id]
 * Removes the media asset record from DB (does not delete from Cloudinary
 * to avoid breaking product images that still reference it).
 */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const { id } = await params
  const existing = await db.mediaAsset.findUnique({ where: { id } })
  if (!existing) return jsonError('الأصل غير موجود.', 404)
  await db.mediaAsset.delete({ where: { id } })
  await audit(admin.id, 'media.delete', 'media', id, { publicId: existing.publicId }, clientMeta(req))
  revalidateTag('settings')
  return Response.json({ ok: true })
}
