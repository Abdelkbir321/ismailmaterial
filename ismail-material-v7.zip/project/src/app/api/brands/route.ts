import { getBrands } from '@/services/catalog'
export const dynamic = "force-dynamic"
export async function GET() {
  return Response.json({ ok: true, brands: await getBrands() })
}
