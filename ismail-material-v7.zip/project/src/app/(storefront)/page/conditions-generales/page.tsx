import Link from 'next/link'
import { ChevronRight } from 'lucide-react'
import { getBranding } from '@/services/branding'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

const META: { slug: string; title: string; description: string } = {
  slug: 'conditions-generales',
  title: 'Conditions générales de vente',
  description: 'Conditions générales de vente — commandes, paiements, livraison, retours.',
}

export const metadata: Metadata = {
  title: META.title,
  description: META.description,
  alternates: { canonical: `/page/${META.slug}` },
  robots: { index: true, follow: true },
}

export default async function Page() {
  const b = await getBranding()
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Conditions générales</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Légal</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          {META.title}
        </h1>
      </header>

      {/* Content */}
      <div className="mt-8 space-y-6 text-sm leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">1. Objet</h2>
          <p className="mt-2">
            Les présentes conditions générales régissent les ventes de produits par{' '}
            <strong className="text-foreground">{b.siteName}</strong> à travers son site web.
            Toute commande implique l'acceptation pleine et entière des présentes conditions.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">2. Commandes</h2>
          <p className="mt-2">
            Les commandes se font directement sur le site, sans obligation de création de compte.
            Les informations saisies (nom, téléphone, adresse) doivent être exactes.{' '}
            {b.siteName} se réserve le droit de refuser une commande pour des raisons légitimes.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">3. Prix & Paiement</h2>
          <p className="mt-2">
            Les prix sont indiqués en {b.raw.default_currency || 'MAD'} et incluent les taxes
            applicables. Le paiement s'effectue à la livraison (Cash on Delivery). Le paiement
            en ligne sera proposé ultérieurement.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">4. Livraison</h2>
          <p className="mt-2">
            La livraison s'effectue dans tout le Maroc sous 24–72h pour les grandes villes et
            2–5 jours pour les zones rurales. Les frais de livraison sont indiqués au moment
            de la commande. {b.siteName} n'est pas responsable des retards imputables au transporteur.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">5. Retours & Remboursement</h2>
          <p className="mt-2">
            Vous disposez de 7 jours à compter de la réception pour retourner un produit non
            conforme ou défectueux, dans son emballage d'origine. Le remboursement intervient
            après vérification du produit retourné.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">6. Contact</h2>
          <p className="mt-2">
            Pour toute question, contactez-nous :{' '}
            <span className="font-mono">{b.supportPhone}</span> ·{' '}
            <span className="font-mono">{b.supportEmail}</span> · {b.address}
          </p>
        </section>
      </div>

      <p className="mt-10 border-t border-border pt-4 text-xs text-muted-foreground">
        Dernière mise à jour :{' '}
        <span className="font-mono">{new Date().toLocaleDateString('fr-MA')}</span>
      </p>
    </div>
  )
}
