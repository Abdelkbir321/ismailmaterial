'use client'

import Link from 'next/link'
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, ChevronRight, ShieldCheck } from 'lucide-react'
import { useCart } from '@/lib/cart-store'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/format'

/**
 * Cart page — editorial layout with item list + sticky summary.
 *
 * DESIGN INTENT
 * -------------
 * - Header has kicker + big title + count
 * - Item rows are refined, with better thumbnail sizes and pill qty selectors
 * - Sticky summary card on desktop with "trust band" (COD, secure, etc.)
 * - Empty state is editorial, not generic
 */
export default function CartPage() {
  const { items, setQty, remove, subtotal, clear } = useCart()
  const total = subtotal()
  const currency = { code: 'MAD', symbol: 'DH', locale: 'fr-MA' }
  const shipping = total > 500 ? 0 : 30
  const grandTotal = total + shipping

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20">
        <div className="flex flex-col items-center gap-5 text-center">
          <div className="grid size-24 place-items-center rounded-full bg-muted text-muted-foreground/60">
            <ShoppingBag className="h-10 w-10" strokeWidth={1.2} />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">Votre panier est vide</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Découvrez notre outillage professionnel — perceuses, visseuses, meuleuses et plus.
            </p>
          </div>
          <Button asChild className="btn-primary-cta rounded-full px-7 h-12 text-base font-semibold">
            <Link href="/produits">
              Parcourir le catalogue <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:py-14">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Panier</span>
      </nav>

      {/* Header */}
      <header className="mt-4 flex items-end justify-between border-b border-border pb-6">
        <div>
          <span className="kicker">Panier</span>
          <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Votre panier
          </h1>
        </div>
        <p className="text-sm text-muted-foreground">
          <span className="font-mono tabular-nums">{items.length}</span>{' '}
          {items.length > 1 ? 'articles' : 'article'}
        </p>
      </header>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* Items list */}
        <div className="lg:col-span-2">
          <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-[var(--shadow-xs)]">
            {items.map((item, i) => (
              <div
                key={`${item.productId}-${item.variantId ?? 'x'}`}
                className={`flex gap-4 p-4 ${i > 0 ? 'border-t border-border' : ''}`}
              >
                <Link
                  href={`/produits/${item.slug}`}
                  className="size-20 flex-shrink-0 overflow-hidden rounded-2xl bg-muted"
                >
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                  ) : (
                    <div className="grid h-full w-full place-items-center text-muted-foreground/60">
                      <ShoppingBag className="h-6 w-6" />
                    </div>
                  )}
                </Link>
                <div className="flex flex-1 flex-col">
                  <Link
                    href={`/produits/${item.slug}`}
                    className="font-display text-sm font-semibold leading-snug transition-colors hover:text-primary"
                  >
                    {item.name}
                  </Link>
                  {item.variantName && (
                    <p className="mt-0.5 text-xs text-muted-foreground">{item.variantName}</p>
                  )}
                  <p className="mt-0.5 text-[11px] text-muted-foreground/60">
                    <span className="font-mono">Réf: {item.sku}</span>
                  </p>
                  <div className="mt-auto flex items-center justify-between pt-2">
                    <div className="flex items-center rounded-full border border-border bg-background p-0.5">
                      <button
                        onClick={() => setQty(item.productId, item.variantId, item.quantity - 1)}
                        className="grid size-7 place-items-center rounded-full text-foreground transition-colors hover:bg-muted"
                        aria-label="Diminuer"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-9 text-center font-mono text-sm font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => setQty(item.productId, item.variantId, item.quantity + 1)}
                        className="grid size-7 place-items-center rounded-full text-foreground transition-colors hover:bg-muted"
                        aria-label="Augmenter"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <button
                      onClick={() => remove(item.productId, item.variantId)}
                      className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Retirer
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-foreground">
                    {formatPrice(item.price, currency)}
                  </div>
                  <div className="mt-1 font-display price-display font-bold tracking-tight text-foreground">
                    {formatPrice(item.price * item.quantity, currency)}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex justify-between">
            <Button asChild variant="outline" className="rounded-full">
              <Link href="/produits">
                <ChevronRight className="mr-1.5 h-4 w-4 rotate-180" /> Continuer mes achats
              </Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clear}
              className="rounded-full text-muted-foreground hover:text-destructive"
            >
              Vider le panier
            </Button>
          </div>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-32 rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-sm)]">
            <h2 className="font-display text-base font-bold tracking-tight">Récapitulatif</h2>
            <dl className="mt-4 space-y-2.5 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Sous-total</dt>
                <dd className="price-display font-medium">{formatPrice(total, currency)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Livraison</dt>
                <dd className="price-display font-medium">
                  {shipping === 0 ? 'Gratuite' : formatPrice(shipping, currency)}
                </dd>
              </div>
              {shipping === 0 && (
                <p className="text-[11px] font-medium text-success">Livraison gratuite offerte</p>
              )}
              <div className="mt-3 flex justify-between border-t border-border pt-3">
                <dt className="font-display text-base font-semibold">Total</dt>
                <dd className="font-display price-display text-base font-bold">
                  {formatPrice(grandTotal, currency)}
                </dd>
              </div>
            </dl>

            {/* COD trust badge */}
            <div className="mt-4 flex items-center gap-2 rounded-2xl border border-border bg-muted/40 px-3 py-2.5 text-xs text-muted-foreground">
              <ShieldCheck className="h-4 w-4 text-accent" strokeWidth={1.6} />
              <span>Paiement à la livraison (COD)</span>
            </div>

            <Button
              asChild
              className="btn-primary-cta mt-4 w-full rounded-full h-12 text-base font-semibold"
              size="lg"
            >
              <Link href="/checkout">
                Commander <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
