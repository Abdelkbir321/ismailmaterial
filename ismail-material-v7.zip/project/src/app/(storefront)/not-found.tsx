import Link from 'next/link'
import { Home, Search, ChevronRight, Compass } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { Button } from '@/components/ui/button'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { robots: { index: false, follow: true } }

/**
 * 404 page — editorial, not generic.
 *
 * DESIGN INTENT
 * -------------
 * Big "404" number in display font, accent color. Short explanatory
 * copy. Three CTAs. Breadcrumb-like row of nav links at the bottom.
 * The whole thing reads as a "lost in the workshop" moment —
 * not a broken page.
 */
export default async function NotFound() {
  const b = await getBranding()
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center px-4 py-16 text-center">
      {/* Compass icon in a circle — represents "lost in navigation" */}
      <div className="mb-8 grid size-20 place-items-center rounded-full bg-muted text-primary">
        <Compass className="h-9 w-9" strokeWidth={1.3} />
      </div>

      <p className="font-display text-7xl font-bold tracking-tight text-gradient-warm sm:text-8xl">
        404
      </p>
      <h1 className="mt-4 font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
        Page introuvable
      </h1>
      <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
        Désolé, la page que vous cherchez n'existe pas ou a été déplacée.
        Le lien est peut-être ancien, ou le produit a été retiré du catalogue.
      </p>

      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Button asChild className="btn-primary-cta rounded-full">
          <Link href="/">
            <Home className="mr-2 h-4 w-4" /> Accueil
          </Link>
        </Button>
        <Button asChild variant="outline" className="rounded-full border-border">
          <Link href="/produits">
            <Search className="mr-2 h-4 w-4" /> Voir le catalogue
          </Link>
        </Button>
        <Button asChild variant="ghost" className="rounded-full">
          <Link href="/contact">Nous contacter</Link>
        </Button>
      </div>

      <nav className="mt-10 flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">{b.siteName}</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/produits" className="transition-colors hover:text-foreground">Produits</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/aide" className="transition-colors hover:text-foreground">Aide</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/contact" className="transition-colors hover:text-foreground">Contact</Link>
      </nav>
    </div>
  )
}
