import { StoreHeader } from '@/components/storefront/store-header'
import { StoreFooter } from '@/components/storefront/store-footer'
import { CartDrawer } from '@/components/storefront/cart-drawer'
import { getCategories } from '@/services/catalog'
import { getBranding } from '@/services/branding'

/**
 * All storefront pages are dynamic (rendered at request time).
 * This is the correct architecture for an e-commerce site with a live DB:
 * product data changes frequently, and we do NOT want to require database
 * access during `next build` (which would fail in CI/sandbox environments
 * where the DB may be unreachable). Pages render on the serverless
 * function at request time, where the DB is reachable. Catalog reads
 * are cached via unstable_cache (60s revalidate) so dynamic rendering
 * stays fast.
 *
 * Branding (logo, site name, contact, social, logo size, logo motion) is
 * read ONCE here from site_settings and passed to both header and footer,
 * so changing a setting in the admin reflects everywhere within 60s
 * (cache revalidation). The `revalidateTag('settings')` call in the
 * visual-identity admin API also forces an immediate refresh when the
 * admin saves.
 */
export const dynamic = 'force-dynamic'

export default async function StorefrontLayout({ children }: { children: React.ReactNode }) {
  let categories: Array<{ slug: string; name: string; nameAr?: string | null }> = []
  let branding: Awaited<ReturnType<typeof getBranding>> | null = null
  try {
    const [cats, b] = await Promise.all([getCategories(), getBranding()])
    categories = cats.map((c) => ({ slug: c.slug, name: c.name, nameAr: c.nameAr }))
    branding = b
  } catch {
    // DB unavailable — render with defaults (header/footer handle null branding)
  }
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <StoreHeader
        categories={categories}
        logoUrl={branding?.logoUrl ?? null}
        siteName={branding?.siteName ?? null}
        supportPhone={branding?.supportPhone ?? null}
        whatsapp={branding?.whatsapp ?? null}
        logoSize={branding?.logoSize ?? null}
        logoMotion={branding?.logoMotion ?? null}
        logoVisual={branding?.logoVisual ?? null}
        logoMobile={branding?.logoMobile ?? null}
      />
      <main className="flex-1">{children}</main>
      <StoreFooter branding={branding} />
      <CartDrawer />
    </div>
  )
}
