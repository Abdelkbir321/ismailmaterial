'use client'

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Search, ChevronRight, PackageX } from 'lucide-react'
import { ProductCard } from '@/components/storefront/product-card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import type { ProductCard as TProductCard } from '@/types'

function SearchContent() {
  const router = useRouter()
  const sp = useSearchParams()
  const q = sp.get('q') || ''
  const [input, setInput] = useState(q)
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<TProductCard[]>([])

  useEffect(() => setInput(q), [q])

  useEffect(() => {
    let active = true
    const query = q.trim()
    if (!query) {
      setResults([])
      setLoading(false)
      return
    }
    setLoading(true)
    fetch(`/api/search?q=${encodeURIComponent(query)}`)
      .then((r) => r.json())
      .then((d) => {
        if (active) {
          setResults(d.products || [])
          setLoading(false)
        }
      })
      .catch(() => active && setLoading(false))
    return () => {
      active = false
    }
  }, [q])

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) router.push(`/recherche?q=${encodeURIComponent(input.trim())}`)
  }

  return (
    <>
      <form onSubmit={submit} className="mt-6 flex gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Rechercher un produit, une marque, une référence…"
            className="h-12 rounded-full border-border bg-card pl-11 text-base shadow-[var(--shadow-xs)]"
            aria-label="Recherche"
          />
        </div>
        <Button type="submit" className="btn-primary-cta h-12 rounded-full px-6 font-semibold">
          Rechercher
        </Button>
      </form>

      {loading ? (
        <p className="mt-6 text-sm text-muted-foreground">Recherche…</p>
      ) : !q.trim() ? (
        <p className="mt-6 text-sm text-muted-foreground">Saisissez un terme de recherche.</p>
      ) : results.length === 0 ? (
        <div className="mt-12 grid place-items-center rounded-3xl border border-dashed border-border bg-card/40 py-20 text-center">
          <div className="grid size-16 place-items-center rounded-full bg-muted text-muted-foreground">
            <PackageX className="h-7 w-7" strokeWidth={1.4} />
          </div>
          <p className="mt-5 font-display text-lg font-semibold">
            Aucun produit trouvé pour «&nbsp;{q}&nbsp;»
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Essayez un autre terme, ou parcourez tout le catalogue.
          </p>
          <Button asChild variant="outline" className="mt-5 rounded-full">
            <Link href="/produits">Voir tout le catalogue</Link>
          </Button>
        </div>
      ) : (
        <>
          <p className="mt-6 text-sm text-muted-foreground">
            <span className="font-mono tabular-nums">{results.length}</span>{' '}
            {results.length > 1 ? 'résultats' : 'résultat'} pour «&nbsp;{q}&nbsp;»
          </p>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {results.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </>
      )}
    </>
  )
}

export default function SearchPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:py-14">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Recherche</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Recherche</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Rechercher dans le catalogue
        </h1>
      </header>

      <Suspense fallback={<p className="mt-6 text-sm text-muted-foreground">Chargement…</p>}>
        <SearchContent />
      </Suspense>
    </div>
  )
}
