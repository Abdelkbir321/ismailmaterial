import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getProductsByCategory, getCategories } from '@/services/catalog'
import { ProductCard } from '@/components/storefront/product-card'
import { ChevronRight, PackageX, ArrowRight } from 'lucide-react'
import type { Metadata } from 'next'

export const revalidate = 60

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const categories = await getCategories()
  const cat = categories.find((c) => c.slug === slug)
  if (!cat) return { title: 'Catégorie introuvable', robots: { index: false, follow: true } }
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || ''
  return {
    title: cat.seoTitle || cat.name,
    description: cat.seoDescription || cat.description || `Produits dans la catégorie ${cat.name}`,
    alternates: { canonical: `${siteUrl}/categories/${cat.slug}` },
    openGraph: {
      title: cat.seoTitle || cat.name,
      description: cat.seoDescription || cat.description || '',
      url: `${siteUrl}/categories/${cat.slug}`,
      type: 'website',
    },
    robots: { index: true, follow: true },
  }
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const categories = await getCategories()
  const category = categories.find((c) => c.slug === slug)
  if (!category) notFound()
  const products = await getProductsByCategory(slug, 40)

  const children = categories.filter((c) => c.parentId === category.id)
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || ''

  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Accueil', item: siteUrl || '/' },
      { '@type': 'ListItem', position: 2, name: 'Catégories', item: `${siteUrl}/categories` },
      { '@type': 'ListItem', position: 3, name: category.name, item: `${siteUrl}/categories/${category.slug}` },
    ],
  }
  const itemListSchema = products.length > 0
    ? {
        '@context': 'https://schema.org',
        '@type': 'ItemList',
        name: category.name,
        itemListElement: products.slice(0, 20).map((p, i) => ({
          '@type': 'ListItem',
          position: i + 1,
          url: `${siteUrl}/produits/${p.slug}`,
          name: p.name,
        })),
      }
    : null

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:py-14">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      {itemListSchema && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListSchema) }} />}

      {/* Breadcrumb */}
      <nav className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/categories" className="transition-colors hover:text-foreground">Catégories</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">{category.name}</span>
      </nav>

      {/* Header */}
      <header className="mt-4 flex flex-col gap-4 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <span className="kicker">Catégorie</span>
          <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            {category.name}
          </h1>
          {category.description && (
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
              {category.description}
            </p>
          )}
        </div>
        <div className="text-sm text-muted-foreground">
          <span className="font-mono tabular-nums">{products.length}</span>{' '}
          {products.length > 1 ? 'produits' : 'produit'}
        </div>
      </header>

      {/* Children categories */}
      {children.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {children.map((c) => (
            <Link
              key={c.id}
              href={`/categories/${c.slug}`}
              className="tag-pill transition-all hover:border-primary hover:text-primary"
            >
              {c.name}
              {c._count?.products !== undefined && (
                <span className="ml-1 text-[10px] opacity-60">{c._count.products}</span>
              )}
            </Link>
          ))}
        </div>
      )}

      {/* Products or empty state */}
      {products.length === 0 ? (
        <div className="mt-12 grid place-items-center rounded-3xl border border-dashed border-border bg-card/40 py-20 text-center">
          <div className="grid size-16 place-items-center rounded-full bg-muted text-muted-foreground">
            <PackageX className="h-7 w-7" strokeWidth={1.4} />
          </div>
          <p className="mt-5 font-display text-lg font-semibold">
            Aucun produit dans cette catégorie
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Nous enrichissons le catalogue régulièrement — revenez bientôt.
          </p>
          <Link
            href="/produits"
            className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
          >
            Voir tout le catalogue <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}
