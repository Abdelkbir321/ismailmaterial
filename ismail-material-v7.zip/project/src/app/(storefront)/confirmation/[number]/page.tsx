import Link from 'next/link'
import { notFound, redirect } from 'next/navigation'
import { CheckCircle2, Truck, Phone, ArrowRight, MessageCircle, Package, Clock, MapPin } from 'lucide-react'
import { db } from '@/lib/db'
import { formatPrice } from '@/lib/format'
import { Button } from '@/components/ui/button'
import { getBranding } from '@/services/branding'
import type { Metadata } from 'next'

/**
 * Order confirmation page — "Thank you" experience.
 *
 * SECURITY
 * -------
 * The order is fetched from the DB by its `number` (public reference).
 * Without a guard, anyone could enumerate `/confirmation/ORD-2024-00001`,
 * `ORD-2024-00002`, ... and harvest customer names, phones, and addresses.
 *
 * We prevent that by requiring an `idempotencyKey` query param that
 * matches the order's stored `idempotencyKey`. The checkout page passes
 * this key when navigating here. Without it (or with a wrong one), we
 * return 404 — exactly as if the order didn't exist.
 */

export const metadata: Metadata = {
  robots: { index: false, follow: false, googleBot: { index: false, follow: false } },
  title: 'تأكيد الطلب',
}
export const dynamic = 'force-dynamic'

export default async function ConfirmationPage({
  params,
  searchParams,
}: {
  params: Promise<{ number: string }>
  searchParams: Promise<{ key?: string }>
}) {
  const { number } = await params
  const { key } = await searchParams

  // Fetch the order with items + country
  const order = await db.order.findUnique({
    where: { number },
    include: { items: true, country: true },
  })

  // If order doesn't exist OR the idempotency key doesn't match, return 404.
  // We do NOT reveal whether the order exists — same response either way.
  if (!order || !key || (order.idempotencyKey && order.idempotencyKey !== key)) {
    notFound()
  }

  // For legacy orders (pre-idempotency-key migration), the order.idempotencyKey
  // is NULL — we can't verify ownership via the key. As a fallback, allow
  // viewing if the order is recent (placed within the last hour). This is
  // a transitional measure; once all orders have keys, this branch can be
  // removed.
  if (!order.idempotencyKey) {
    const placedAt = new Date(order.placedAt).getTime()
    const oneHour = 60 * 60 * 1000
    if (Date.now() - placedAt > oneHour) {
      notFound()
    }
  }

  // Fetch branding for the WhatsApp link + site name
  const branding = await getBranding()
  const currency = {
    code: order.currencyCode,
    symbol: order.country.currencySymbol,
    locale: 'fr-MA',
  }
  const waPhone = (branding.whatsapp || branding.supportPhone || '').replace(/[^\d]/g, '')
  const waUrl = waPhone ? `https://wa.me/${waPhone}?text=${encodeURIComponent(`مرحباً، بغيت نستفسر على الطلب رقم ${order.number}`)}` : null

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:py-14" dir="rtl">
      {/* Success header */}
      <div className="text-center">
        <div className="mx-auto grid size-20 place-items-center rounded-full bg-success/10 text-success shadow-[var(--shadow-md)]">
          <CheckCircle2 className="h-12 w-12" strokeWidth={1.4} />
        </div>
        <h1 className="mt-5 font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
          شكراً على ثقتكم بنا!
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
          تم تسجيل طلبكم بنجاح. غادي يتاصل بكم فريق خدمة العملاء خلال 24 ساعة لتأكيد الطلب ومراجعة معلومات التوصيل معكم. شكراً لاختياركم متجرنا، ومرحباً بكم دائماً.
        </p>
        <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 shadow-[var(--shadow-xs)]">
          <Package className="h-4 w-4 text-accent" strokeWidth={1.5} />
          <span className="text-sm text-muted-foreground">رقم الطلب:</span>
          <span className="font-mono font-bold text-foreground" dir="ltr">{order.number}</span>
        </div>
      </div>

      {/* Order summary card */}
      <div className="mt-8 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-sm)] sm:p-6">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <h2 className="font-display text-base font-bold tracking-tight">ملخص الطلب</h2>
          <span className="rounded-full bg-success/10 px-2.5 py-0.5 text-xs font-medium text-success">
            تم التسجيل
          </span>
        </div>

        {/* Items */}
        <div className="mt-4 divide-y divide-border">
          {order.items.map((it) => (
            <div key={it.id} className="flex items-start gap-3 py-3">
              <div className="size-14 flex-shrink-0 overflow-hidden rounded-xl bg-muted">
                {it.productImage && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={it.productImage} alt={it.productName} className="h-full w-full object-cover" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-display text-sm font-medium text-foreground line-clamp-2">{it.productName}</p>
                {it.variantName && (
                  <p className="mt-0.5 text-xs text-muted-foreground">{it.variantName}</p>
                )}
                <p className="mt-0.5 text-xs text-muted-foreground">الكمية: {it.quantity}</p>
              </div>
              <p className="price-display text-sm font-medium text-foreground whitespace-nowrap">
                {formatPrice(Number(it.lineTotal), currency)}
              </p>
            </div>
          ))}
        </div>

        {/* Totals */}
        <dl className="mt-4 space-y-1.5 border-t border-border pt-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted-foreground">المجموع الفرعي</dt>
            <dd className="price-display tabular-nums">{formatPrice(Number(order.subtotal), currency)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted-foreground">الشحن</dt>
            <dd className="price-display tabular-nums">
              {Number(order.shippingCost) === 0 ? 'مجاني' : formatPrice(Number(order.shippingCost), currency)}
            </dd>
          </div>
          {Number(order.discountTotal) > 0 && (
            <div className="flex justify-between text-success">
              <dt>الخصم</dt>
              <dd className="price-display tabular-nums">-{formatPrice(Number(order.discountTotal), currency)}</dd>
            </div>
          )}
          <div className="flex justify-between border-t border-border pt-2 font-display text-base font-bold">
            <dt>الإجمالي</dt>
            <dd className="price-display tabular-nums">{formatPrice(Number(order.total), currency)}</dd>
          </div>
        </dl>

        {/* Shipping info */}
        <div className="mt-4 rounded-2xl border border-border bg-muted/30 p-3">
          <div className="flex items-start gap-2 text-sm">
            <Truck className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" strokeWidth={1.6} />
            <div>
              <p className="font-display font-medium text-foreground">عنوان التوصيل</p>
              <p className="mt-0.5 text-muted-foreground">{order.customerFullName}</p>
              <p className="text-muted-foreground">{order.shippingAddress}</p>
              <p className="text-muted-foreground">
                {order.shippingCity}
                {order.shippingPostalCode ? `، ${order.shippingPostalCode}` : ''}
              </p>
              <p className="text-muted-foreground">{order.country.name}</p>
            </div>
          </div>
        </div>

        {/* Payment + status note */}
        <div className="mt-3 flex items-center justify-between rounded-2xl border border-border px-3 py-2 text-xs">
          <span className="text-muted-foreground">طريقة الدفع</span>
          <span className="font-display font-medium text-foreground">
            {order.paymentMethod === 'COD' ? 'الدفع عند الاستلام (نقداً)' : order.paymentMethod}
          </span>
        </div>
      </div>

      {/* What's next */}
      <div className="mt-5 rounded-3xl border border-accent/30 bg-accent/5 p-4">
        <div className="flex items-start gap-2">
          <Clock className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" strokeWidth={1.6} />
          <div className="text-sm">
            <p className="font-display font-medium text-foreground">الخطوات التالية</p>
            <ul className="mt-1.5 space-y-1 text-foreground/80">
              <li>• سيتصل بك فريقنا خلال 24 ساعة لتأكيد الطلب.</li>
              <li>• سيتم تجهيز الطلب بعد تأكيد المعلومات.</li>
              <li>• التوصيل عادةً خلال 24–72 ساعة بعد التأكيد.</li>
            </ul>
            <p className="mt-2 text-xs text-accent">
              ملاحظة: الطلب مسجّل ولكن غير مؤكد نهائياً حتى يتصل بك الفريق.
            </p>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
        <Button asChild size="lg" className="btn-secondary-cta h-12 rounded-full px-7 text-base font-semibold">
          <Link href="/produits">
            <ArrowRight className="ml-2 h-4 w-4" /> العودة إلى التسوق
          </Link>
        </Button>
        {waUrl && (
          <Button asChild size="lg" className="btn-primary-cta h-12 rounded-full px-7 text-base font-semibold">
            <a href={waUrl} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="ml-2 h-4 w-4" /> تواصل عبر واتساب
            </a>
          </Button>
        )}
        <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-7">
          <Link href="/contact">
            <Phone className="ml-2 h-4 w-4" /> اتصل بنا
          </Link>
        </Button>
      </div>

      {/* Reference footer */}
      <p className="mt-6 text-center text-xs text-muted-foreground">
        احتفظ برقم الطلب{' '}
        <span className="font-mono font-semibold text-foreground" dir="ltr">{order.number}</span>{' '}
        لأي استفسار.
      </p>

      {/* Noindex meta — belt-and-suspenders */}
      <meta name="robots" content="noindex, nofollow, nosnippet, noarchive" />
    </div>
  )
}
