import Link from 'next/link'
import { Phone, Mail, MapPin, MessageCircle, Clock, Facebook, Instagram, Youtube, ChevronRight, LifeBuoy } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { Button } from '@/components/ui/button'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export async function generateMetadata(): Promise<Metadata> {
  const b = await getBranding()
  return {
    title: 'Contact',
    description: `Contactez ${b.siteName} — téléphone, WhatsApp, email, adresse.`,
    alternates: { canonical: '/contact' },
    robots: { index: true, follow: true },
  }
}

export default async function ContactPage() {
  const b = await getBranding()
  const wa = b.whatsapp.replace(/[^\d]/g, '')
  const phone = b.supportPhone.replace(/[\s()-]/g, '')
  const mapUrl = b.address ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(b.address)}` : null

  const contactCards = [
    b.supportPhone && {
      icon: Phone,
      label: 'Téléphone',
      value: b.supportPhone,
      href: `tel:${phone}`,
      target: undefined as string | undefined,
    },
    wa && {
      icon: MessageCircle,
      label: 'WhatsApp',
      value: b.whatsapp,
      href: `https://wa.me/${wa}`,
      target: '_blank',
    },
    b.supportEmail && {
      icon: Mail,
      label: 'Email',
      value: b.supportEmail,
      href: `mailto:${b.supportEmail}`,
      target: undefined,
    },
    b.address && {
      icon: MapPin,
      label: 'Adresse',
      value: b.address,
      href: mapUrl || '#',
      target: '_blank',
    },
  ].filter(Boolean) as Array<{
    icon: typeof Phone
    label: string
    value: string
    href: string
    target?: string
  }>

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:py-14">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Contact</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Contact</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Contactez-nous
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Une question ? Notre équipe vous répond rapidement.
        </p>
      </header>

      {/* Contact cards */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {contactCards.map((c, i) => (
          <a
            key={i}
            href={c.href}
            target={c.target}
            rel={c.target === '_blank' ? 'noopener noreferrer' : undefined}
            className="card-hover group flex items-center gap-4 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-xs)]"
          >
            <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
              <c.icon className="h-5 w-5" strokeWidth={1.6} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                {c.label}
              </p>
              <p className="mt-0.5 font-display text-sm font-semibold tracking-tight text-foreground truncate">
                {c.value}
              </p>
            </div>
          </a>
        ))}

        {/* Working hours — not a link, just info */}
        <div className="flex items-center gap-4 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-xs)]">
          <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary">
            <Clock className="h-5 w-5" strokeWidth={1.6} />
          </span>
          <div>
            <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              Heures d'ouverture
            </p>
            <p className="mt-0.5 font-display text-sm font-semibold tracking-tight">
              {b.workingHours}
            </p>
          </div>
        </div>
      </div>

      {/* Social */}
      {(b.social.facebook || b.social.instagram || b.social.youtube) && (
        <div className="mt-10">
          <h2 className="font-display text-base font-bold tracking-tight">Suivez-nous</h2>
          <div className="mt-3 flex gap-2">
            {b.social.facebook && (
              <a
                href={b.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="grid size-11 place-items-center rounded-full border border-border bg-card text-foreground transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground hover:shadow-[var(--shadow-xs)]"
                aria-label="Facebook"
              >
                <Facebook className="h-4 w-4" />
              </a>
            )}
            {b.social.instagram && (
              <a
                href={b.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="grid size-11 place-items-center rounded-full border border-border bg-card text-foreground transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground hover:shadow-[var(--shadow-xs)]"
                aria-label="Instagram"
              >
                <Instagram className="h-4 w-4" />
              </a>
            )}
            {b.social.youtube && (
              <a
                href={b.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="grid size-11 place-items-center rounded-full border border-border bg-card text-foreground transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground hover:shadow-[var(--shadow-xs)]"
                aria-label="YouTube"
              >
                <Youtube className="h-4 w-4" />
              </a>
            )}
          </div>
        </div>
      )}

      {/* Help CTA */}
      <div className="mt-10 flex flex-col items-center gap-4 rounded-3xl border border-border bg-secondary p-8 text-center">
        <div className="grid size-12 place-items-center rounded-2xl bg-card text-accent">
          <LifeBuoy className="h-5 w-5" strokeWidth={1.6} />
        </div>
        <div>
          <p className="font-display text-lg font-bold tracking-tight text-secondary-foreground">
            Besoin d'aide pour commander ?
          </p>
          <p className="mt-1 text-sm text-secondary-foreground/70">
            Consultez notre centre d'aide — réponses aux questions fréquentes, guides d'achat, et plus.
          </p>
        </div>
        <Button asChild className="btn-secondary-cta rounded-full bg-card text-secondary hover:bg-card/90">
          <Link href="/aide">Consulter le centre d'aide</Link>
        </Button>
      </div>
    </div>
  )
}
