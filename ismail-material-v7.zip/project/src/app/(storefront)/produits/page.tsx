import Link from 'next/link'
import { getFeaturedProducts, getBestSellers, getNewArrivals, getAllProducts } from '@/services/catalog'
import { ProductCard } from '@/components/storefront/product-card'
import { ChevronRight, Wrench, PackageX } from 'lucide-react'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Catalogue — Tous les produits',
  description:
    "Découvrez tout notre catalogue d'outillage professionnel — perceuses, visseuses, meuleuses, niveaux laser, EPI. Livraison au Maroc, paiement à la livraison.",
  alternates: { canonical: '/produits' },
}

export const revalidate = 60

/**
 * Products listing page — editorial header + filter pills + grid.
 *
 * DESIGN INTENT
 * -------------
 * - Header has a "kicker" eyebrow + big display headline + product count
 *   on the right (info hierarchy, not just text)
 * - Filter pills are active/inactive with refined colors
 * - Empty state is editorial, not a generic "no items" card
 * - Grid uses the redesigned ProductCard (with depth + tilt)
 */
export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string }>
}) {
  const sp = await searchParams
  const filter = sp.filter
  let products: Awaited<ReturnType<typeof getAllProducts>> = []
  let title = 'Tous les produits'
  let subtitle = 'Catalogue complet d\'outillage professionnel'
  try {
    if (filter === 'featured') {
      products = await getFeaturedProducts(20)
      title = 'Produits en vedette'
      subtitle = 'Sélection de la rédaction'
    } else if (filter === 'best') {
      products = await getBestSellers(20)
      title = 'Meilleures ventes'
      subtitle = 'Les plus commandés par nos clients'
    } else if (filter === 'new') {
      products = await getNewArrivals(20)
      title = 'Nouveautés'
      subtitle = 'Dernières arrivées en stock'
    } else {
      products = await getAllProducts(40)
    }
  } catch {
    // DB unreachable at runtime — render empty state
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:py-14">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">
          Accueil
        </Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Produits</span>
      </nav>

      {/* Header */}
      <header className="mt-4 flex flex-col gap-4 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <span className="kicker">Catalogue</span>
          <h1 className="mt-3 font-display text-3xl font-bold leading-tight tracking-tight text-foreground sm:text-4xl">
            {title}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <div className="flex items-center gap-3 text-sm text-muted-foreground">
          <span className="font-mono tabular-nums">
            {products.length} {products.length > 1 ? 'produits' : 'produit'}
          </span>
        </div>
      </header>

      {/* Filter pills */}
      <div className="mt-6 flex flex-wrap gap-2">
        {[
          { k: undefined, l: 'Tous' },
          { k: 'featured', l: 'En vedette' },
          { k: 'best', l: 'Best-sellers' },
          { k: 'new', l: 'Nouveautés' },
        ].map((f) => {
          const active = (!filter && !f.k) || filter === f.k
          return (
            <Link
              key={f.l}
              href={f.k ? `/produits?filter=${f.k}` : '/produits'}
              className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-all ${
                active
                  ? 'border-primary bg-primary text-primary-foreground shadow-[var(--shadow-sm)]'
                  : 'border-border bg-card text-foreground hover:border-border-strong hover:shadow-[var(--shadow-xs)]'
              }`}
            >
              <Wrench className="h-3.5 w-3.5" strokeWidth={1.6} />
              {f.l}
            </Link>
          )
        })}
      </div>

      {/* Grid or empty state */}
      {products.length === 0 ? (
        <div className="mt-12 grid place-items-center rounded-3xl border border-dashed border-border bg-card/40 py-20 text-center">
          <div className="grid size-16 place-items-center rounded-full bg-muted text-muted-foreground">
            <PackageX className="h-7 w-7" strokeWidth={1.4} />
          </div>
          <p className="mt-5 font-display text-lg font-semibold">
            Aucun produit pour le moment
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Revenez bientôt — nous ajoutons de nouveaux outils chaque semaine.
          </p>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  )
}
