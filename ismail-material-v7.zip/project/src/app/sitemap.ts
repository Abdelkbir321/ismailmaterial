import type { MetadataRoute } from 'next'
import { db } from '@/lib/db'
import { unstable_cache } from 'next/cache'
import { getProductionDomain } from '@/services/settings'

/**
 * Dynamic Sitemap — Single Source of Truth for the production domain.
 *
 * ==========================================================================
 * WHAT'S INCLUDED
 * --------------
 *  - Static storefront routes (/, /produits, /categories, /contact, /aide)
 *  - PUBLISHED products where `noindex = false`
 *  - Visible categories / brands / CMS pages
 *
 * WHAT'S EXCLUDED
 * ---------------
 *  - /admin/*, /api/* (covered by robots.txt)
 *  - /cart, /checkout, /confirmation, /recherche
 *  - DRAFT / ARCHIVED / noindex products
 *  - Hidden categories / brands / pages
 *
 * ==========================================================================
 * DOMAIN HANDLING (CRITICAL)
 * --------------------------
 * The base URL comes from `getProductionDomain()` which reads from the
 * `site_url` setting in the DB (super-admin only) with `NEXT_PUBLIC_SITE_URL`
 * as fallback. If NEITHER is set/valid (e.g. Netlify preview deployment
 * without env var, or production with no DB value), we return an EMPTY
 * sitemap (`[]`) rather than fabricating a wrong domain.
 *
 * This prevents two failure modes:
 *  1. Netlify preview URLs (xxx.netlify.app) leaking into the production
 *     sitemap when Google crawls the preview.
 *  2. Localhost URLs being indexed during local development.
 *
 * ==========================================================================
 * SITEMAP INDEX + MULTI-FILE SUPPORT (Google Official Limits)
 * ------------------------------------------------------------
 * Google's official limits per sitemap file:
 *   - Maximum 50,000 URLs per file
 *   - Maximum 50MB uncompressed per file
 *
 * We use Next.js's `generateSitemaps()` to automatically split the URL list
 * into chunks of 50,000. When the total URL count is ≤ 50,000, a single
 * sitemap file is produced (no index needed) — backward compatible with the
 * original behavior. When the count exceeds 50,000, Next.js automatically
 * generates a sitemap index at `/sitemap.xml` that points to multiple
 * files: `/sitemap/0.xml`, `/sitemap/1.xml`, etc.
 *
 * This is fully automatic — the admin does not need to configure anything.
 *
 * ==========================================================================
 * CACHE & REGENERATION
 * --------------------
 * - `revalidate = 3600` — Next.js regenerates the sitemap in the background
 *   at most once per hour.
 * - `unstable_cache` wrapper shares the DB read across concurrent requests
 *   and is tagged `'sitemap'` so the admin can force-refresh it after
 *   publishing/deleting a product (via /api/admin/seo/revalidate).
 * - The admin "تحديث Sitemap فوراً" button calls `revalidateTag('sitemap')`
 *   and `revalidateTag('catalog')` so changes are visible within seconds.
 *
 * ==========================================================================
 * LASTMOD POLICY
 * --------------
 * - Static routes: use `new Date()` (the page content can change any time
 *   via the admin panel, so we report "fresh").
 * - Dynamic routes (products, categories, brands, pages): use the actual
 *   `updatedAt` (or `publishedAt` if available) from the DB. This is the
 *   REAL last-modified time, not a fabricated timestamp.
 *
 * ==========================================================================
 * DUPLICATE URL HANDLING
 * -----------------------
 * We de-duplicate by absolute URL string. If a slug exists in multiple
 * tables (e.g. a category and a brand both named "perceuses"), only the
 * first occurrence is kept.
 */

export const revalidate = 3600

const STATIC_ROUTES: Array<{
  path: string
  changeFrequency: MetadataRoute.Sitemap[number]['changeFrequency']
  priority: number
}> = [
  { path: '/', changeFrequency: 'daily', priority: 1 },
  { path: '/produits', changeFrequency: 'daily', priority: 0.9 },
  { path: '/categories', changeFrequency: 'weekly', priority: 0.7 },
  { path: '/contact', changeFrequency: 'monthly', priority: 0.5 },
  { path: '/aide', changeFrequency: 'monthly', priority: 0.5 },
]

// Google's official limit per sitemap file (50,000 URLs). We use 49,500 to
// leave headroom for static routes + new content between regenerations.
const MAX_URLS_PER_FILE = 49_500

interface SitemapEntry {
  url: string
  lastModified: Date
  changeFrequency?: MetadataRoute.Sitemap[number]['changeFrequency']
  priority?: number
}

/**
 * Build the full URL list — cached via `unstable_cache` so concurrent
 * sitemap requests share the same DB read. Tagged `'sitemap'` and
 * `'catalog'` so admin actions can invalidate it.
 */
const buildSitemapEntries = unstable_cache(
  async (): Promise<SitemapEntry[]> => {
    const siteUrl = await getProductionDomain()
    if (!siteUrl) {
      // Production domain not configured — return EMPTY sitemap.
      // We NEVER fabricate a domain. The admin must set `site_url`
      // in /admin/seo before the sitemap will contain any URLs.
      return []
    }

    const staticRoutes: SitemapEntry[] = STATIC_ROUTES.map((r) => ({
      url: `${siteUrl}${r.path}`,
      lastModified: new Date(),
      changeFrequency: r.changeFrequency,
      priority: r.priority,
    }))

    try {
      const [products, categories, brands, pages] = await Promise.all([
        db.product.findMany({
          where: { status: 'PUBLISHED', noindex: false },
          select: { slug: true, updatedAt: true, publishedAt: true },
        }),
        db.category.findMany({
          where: { isVisible: true },
          select: { slug: true, updatedAt: true },
        }),
        db.brand.findMany({
          where: { isVisible: true },
          select: { slug: true, updatedAt: true },
        }),
        db.page.findMany({
          where: { isVisible: true },
          select: { slug: true, updatedAt: true, publishedAt: true },
        }),
      ])

      const productRoutes: SitemapEntry[] = products.map((p) => ({
        url: `${siteUrl}/produits/${p.slug}`,
        lastModified: p.publishedAt ?? p.updatedAt,
        changeFrequency: 'weekly',
        priority: 0.8,
      }))
      const categoryRoutes: SitemapEntry[] = categories.map((c) => ({
        url: `${siteUrl}/categories/${c.slug}`,
        lastModified: c.updatedAt,
        changeFrequency: 'weekly',
        priority: 0.6,
      }))
      const brandRoutes: SitemapEntry[] = brands.map((b) => ({
        url: `${siteUrl}/brands/${b.slug}`,
        lastModified: b.updatedAt,
        changeFrequency: 'monthly',
        priority: 0.4,
      }))
      const pageRoutes: SitemapEntry[] = pages.map((p) => ({
        url: `${siteUrl}/page/${p.slug}`,
        lastModified: p.publishedAt ?? p.updatedAt,
        changeFrequency: 'monthly',
        priority: 0.4,
      }))

      // De-duplicate (in case a slug exists in multiple tables)
      const all = [...staticRoutes, ...productRoutes, ...categoryRoutes, ...brandRoutes, ...pageRoutes]
      const seen = new Set<string>()
      const deduped = all.filter((entry) => {
        if (seen.has(entry.url)) return false
        seen.add(entry.url)
        return true
      })
      return deduped
    } catch {
      // DB unreachable — return just static routes so build doesn't crash.
      return staticRoutes
    }
  },
  ['sitemap-rows'],
  { revalidate: 3600, tags: ['sitemap', 'catalog'] },
)

/**
 * `generateSitemaps()` — Next.js 15+ API for splitting sitemaps into
 * multiple files when the URL list exceeds Google's 50K limit.
 *
 * Returns an array of objects with an `id` property (one per chunk).
 * Next.js then calls the default export once per ID, generating
 * `/sitemap/0.xml`, `/sitemap/1.xml`, … and a sitemap index at
 * `/sitemap.xml` that references them all.
 *
 * When the total URL count is ≤ MAX_URLS_PER_FILE, we return a single
 * ID (`[{ id: 0 }]`) — Next.js still produces `/sitemap.xml` (no index
 * needed for a single file), so the public URL stays the same:
 *   https://YOUR-DOMAIN/sitemap.xml
 *
 * When the count is larger, the index is emitted automatically and Google
 * is pointed to the individual chunks. The public URL stays the same:
 *   https://YOUR-DOMAIN/sitemap.xml  (which now is the index)
 *
 * IMPORTANT: When the production domain is NOT configured (preview deploy
 * without env var, or production without DB value), `buildSitemapEntries`
 * returns an empty array. We still return a single chunk here so the
 * sitemap route emits an empty `<urlset>` rather than crashing.
 */
export async function generateSitemaps() {
  const entries = await buildSitemapEntries()
  const chunkCount = Math.max(1, Math.ceil(entries.length / MAX_URLS_PER_FILE))
  return Array.from({ length: chunkCount }, (_, i) => ({ id: i }))
}

export default async function sitemap(
  ids: { id: number } | undefined,
): Promise<MetadataRoute.Sitemap> {
  const entries = await buildSitemapEntries()

  // Determine which chunk we're generating. Next.js passes the ID via
  // the `ids` argument when `generateSitemaps` is used. When called
  // directly (no ids), default to chunk 0.
  const chunkIndex = typeof ids?.id === 'number' ? ids.id : 0
  const start = chunkIndex * MAX_URLS_PER_FILE
  const end = start + MAX_URLS_PER_FILE
  const chunk = entries.slice(start, end)

  // Map back to the MetadataRoute.Sitemap shape (Next.js requires
  // `lastModified` as a Date; the Sitemap type already accepts our shape).
  return chunk.map((entry) => ({
    url: entry.url,
    lastModified: entry.lastModified,
    changeFrequency: entry.changeFrequency,
    priority: entry.priority,
  }))
}
