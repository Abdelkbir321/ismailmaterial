import type { MetadataRoute } from 'next'
import { getBranding } from '@/services/branding'

/**
 * Dynamic PWA manifest — uses admin-configured favicon_url when available,
 * falls back to static /icon-192x192.png + /icon-512x512.png.
 *
 * This ensures the admin's custom favicon (set via /admin/site-identity)
 * propagates to the PWA manifest too — not just the <link rel="icon"> tags
 * in the HTML head. Without this, Android home-screen installs would still
 * show the OLD static icon even after the admin changed the favicon.
 *
 * The static /manifest.json is kept as a fallback for environments where
 * the dynamic route fails, but Next.js prioritizes this file-based manifest.
 */
export const dynamic = 'force-dynamic'

export default async function manifest(): Promise<MetadataRoute.Manifest> {
  let branding: Awaited<ReturnType<typeof getBranding>> | null = null
  try {
    branding = await getBranding()
  } catch {
    // DB unavailable — use static fallback
  }

  const favUrl = branding?.faviconUrl || null
  const cacheBust = branding?.faviconCacheBust ? `?v=${branding.faviconCacheBust}` : ''
  const favWithBust = favUrl
    ? (favUrl.includes('?') ? favUrl : `${favUrl}${cacheBust}`)
    : null

  const icons: MetadataRoute.Manifest['icons'] = favWithBust
    ? [
        { src: favWithBust, sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: favWithBust, sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: favWithBust, sizes: '192x192', type: 'image/png', purpose: 'maskable' },
        { src: favWithBust, sizes: '512x512', type: 'image/png', purpose: 'maskable' },
      ]
    : [
        { src: '/icon-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: '/icon-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: '/icon-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'maskable' },
        { src: '/icon-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
      ]

  return {
    name: branding?.siteName || 'Ismail Material',
    short_name: branding?.siteName || 'Ismail Material',
    description: branding?.description || 'Outillage électroportatif, accessoires et équipement professionnel au Maroc.',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#2D2D2D',
    icons,
  }
}
