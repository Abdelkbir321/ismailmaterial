import type { MetadataRoute } from 'next'
import { getProductionDomain } from '@/services/settings'

/**
 * Dynamic robots.txt
 * -------------------
 * - `Host` and `Sitemap` use the canonical production domain from
 *   `getProductionDomain()` — DB value (`site_url` setting, super-admin
 *   only) with `NEXT_PUBLIC_SITE_URL` env var fallback.
 * - When no production domain is configured (preview deployment with no
 *   env var, or production without a DB value), we omit the `Sitemap:`
 *   directive rather than point Google at a wrong URL.
 * - `Disallow` rules cover admin, API, cart, checkout, confirmation,
 *   search, and paginated/search-query URLs — none of those should ever
 *   be indexed.
 * - Allow everything else under `/` (product & category & content pages).
 *
 * Cache invalidated by the `'sitemap'` and `'settings'` tags so changes
 * to `site_url` reflect within ~60 seconds.
 */

export const revalidate = 60

export default async function robots(): Promise<MetadataRoute.Robots> {
  const siteUrl = await getProductionDomain()
  const sitemapUrl = siteUrl ? `${siteUrl}/sitemap.xml` : undefined

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/admin',
          '/admin/*',
          '/api',
          '/api/*',
          '/cart',
          '/checkout',
          '/confirmation',
          '/confirmation/*',
          '/recherche',
          '/recherche/*',
          '/*?*q=', // search-query pages
          '/*?*page=', // paginated listings (avoid duplicate content)
        ],
      },
      {
        userAgent: 'Googlebot',
        allow: '/',
        disallow: ['/admin', '/api', '/cart', '/checkout', '/confirmation', '/recherche'],
      },
      {
        userAgent: 'Googlebot-Image',
        allow: '/',
        disallow: ['/admin', '/api'],
      },
    ],
    sitemap: sitemapUrl,
    host: siteUrl || undefined,
  }
}
