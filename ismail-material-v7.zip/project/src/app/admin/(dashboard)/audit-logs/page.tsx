'use client'

import * as React from 'react'
import { ScrollText } from 'lucide-react'
import { toast } from 'sonner'

import { timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface AuditLog {
  id: string
  action: string
  entity: string
  entityId: string | null
  metadata: any
  ip: string | null
  createdAt: string
  adminUser: { email: string; fullName: string } | null
}

export default function AuditLogsPage() {
  const [logs, setLogs] = React.useState<AuditLog[]>([])
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch('/api/admin/audit-logs?take=50', {
          credentials: 'include',
        })
        const json = await res.json()
        if (json.ok) setLogs(json.logs)
        else toast.error(json.error || 'خطأ')
      } catch {
        toast.error('خطأ في الشبكة')
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  return (
    <div className="space-y-6">
      <PageHeader
        title="سجل العمليات"
        description="آخر 50 عملية مسجلة."
        breadcrumb={[
          { label: 'الإدارة', href: '/admin/dashboard' },
          { label: 'السجل' },
        ]}
      />

      {loading ? (
        <Spinner />
      ) : logs.length === 0 ? (
        <EmptyState
          title="لا توجد سجلات"
          description="ستظهر هنا عمليات الإدارة."
          icon={<ScrollText className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>متى</TableHead>
                <TableHead>المدير</TableHead>
                <TableHead>العملية</TableHead>
                <TableHead>الكيان</TableHead>
                <TableHead>المعرّف</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>البيانات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                    {timeAgoAr(l.createdAt)}
                  </TableCell>
                  <TableCell className="text-sm">
                    {l.adminUser ? (
                      <div className="flex flex-col">
                        <span className="font-medium">{l.adminUser.fullName}</span>
                        <span className="text-muted-foreground text-xs" dir="ltr">
                          {l.adminUser.email}
                        </span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-xs" dir="ltr">{l.action}</span>
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-xs" dir="ltr">{l.entity}</span>
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground" dir="ltr">
                    {l.entityId ? l.entityId.slice(0, 8) + '…' : '—'}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground" dir="ltr">
                    {l.ip || '—'}
                  </TableCell>
                  <TableCell className="text-xs">
                    <pre className="bg-muted rounded p-1.5 max-w-xs overflow-x-auto max-h-24" dir="ltr">
                      {JSON.stringify(l.metadata ?? {}, null, 2)}
                    </pre>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  )
}
