'use client'

import * as React from 'react'
import Link from 'next/link'
import { Loader2, Save, Palette, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

const GENERAL_KEYS = [
  'site_name',
  'site_tagline',
  'site_description',
  'support_phone',
  'whatsapp',
  'support_email',
  'address',
  'announcement_bar',
  'default_country',
  'primary_color',
  'accent_color',
] as const

const SEO_KEYS = ['seo_title', 'seo_description', 'og_default_image', 'og_default_title'] as const

const SOCIAL_KEYS = ['facebook_url', 'instagram_url', 'youtube_url', 'tiktok_url'] as const

const FEATURE_FLAGS = [
  { key: 'reviews', label: 'آراء العملاء' },
  { key: 'coupons', label: 'أكواد الخصم' },
  { key: 'wishlist', label: 'قائمة الرغبات' },
  { key: 'online_payments', label: 'الدفع عبر الإنترنت' },
  { key: 'cod', label: 'الدفع عند الاستلام (COD)' },
  { key: 'multi_country', label: 'متعدد الدول' },
  { key: 'maintenance_mode', label: 'وضع الصيانة' },
  { key: 'ai_assistant', label: 'المساعد الذكي' },
] as const

const GENERAL_LABELS: Record<string, string> = {
  site_name: 'اسم الموقع',
  site_tagline: 'الشعار النصي',
  site_description: 'الوصف',
  support_phone: 'هاتف الدعم',
  whatsapp: 'واتساب',
  support_email: 'بريد الدعم',
  address: 'العنوان',
  announcement_bar: 'شريط الإعلان',
  default_country: 'الدولة الافتراضية (رمز)',
  primary_color: 'اللون الأساسي',
  accent_color: 'لون التمييز',
}
const SEO_LABELS: Record<string, string> = {
  seo_title: 'عنوان SEO العام',
  seo_description: 'وصف SEO العام',
  og_default_image: 'صورة OG الافتراضية',
  og_default_title: 'عنوان OG الافتراضي',
}
const SOCIAL_LABELS: Record<string, string> = {
  facebook_url: 'فيسبوك',
  instagram_url: 'إنستغرام',
  youtube_url: 'يوتيوب',
  tiktok_url: 'تيك توك',
}

interface Country {
  id: string
  code: string
  name: string
  isEnabled: boolean
  isDefault: boolean
  currencyCode: string
  currencySymbol: string
  shippingBase: string | number
  sortOrder: number
}

export default function AdminSettingsPage() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState<'general' | 'seo' | 'social' | 'features' | null>(null)
  const [general, setGeneral] = React.useState<Record<string, string>>({})
  const [showAnnouncement, setShowAnnouncement] = React.useState(false)
  const [maintenanceMode, setMaintenanceMode] = React.useState(false)
  const [seo, setSeo] = React.useState<Record<string, string>>({})
  const [social, setSocial] = React.useState<Record<string, string>>({})
  const [flags, setFlags] = React.useState<Record<string, boolean>>({})
  const [countries, setCountries] = React.useState<Country[]>([])

  async function load() {
    setLoading(true)
    try {
      const [setRes, cntRes] = await Promise.all([
        fetch('/api/admin/settings', { credentials: 'include' }),
        fetch('/api/admin/countries', { credentials: 'include' }),
      ])
      const setJson = await setRes.json()
      const cntJson = await cntRes.json()
      if (setJson.ok) {
        const s: Record<string, string> = setJson.settings || {}
        setGeneral(Object.fromEntries(GENERAL_KEYS.map((k) => [k, s[k] ?? ''])))
        setSeo(Object.fromEntries(SEO_KEYS.map((k) => [k, s[k] ?? ''])))
        setSocial(Object.fromEntries(SOCIAL_KEYS.map((k) => [k, s[k] ?? ''])))
        setShowAnnouncement((s['show_announcement'] ?? 'false') === 'true')
        setMaintenanceMode((s['maintenance_mode'] ?? 'false') === 'true')
        setFlags(setJson.featureFlags || {})
      }
      if (cntJson.ok) {
        setCountries(cntJson.countries || [])
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  function setSetting<K extends string>(
    bucket: 'general' | 'seo' | 'social',
    key: K,
    value: string,
  ) {
    if (bucket === 'general') setGeneral((s) => ({ ...s, [key]: value }))
    if (bucket === 'seo') setSeo((s) => ({ ...s, [key]: value }))
    if (bucket === 'social') setSocial((s) => ({ ...s, [key]: value }))
  }

  async function saveSettings(bucket: 'general' | 'seo' | 'social') {
    const map =
      bucket === 'general'
        ? general
        : bucket === 'seo'
          ? seo
          : social
    const extra: Record<string, string> = {}
    if (bucket === 'general') {
      extra.show_announcement = String(showAnnouncement)
      extra.maintenance_mode = String(maintenanceMode)
    }
    setSaving(bucket)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { ...map, ...extra } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم حفظ الإعدادات')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(null)
    }
  }

  async function saveFlags() {
    setSaving('features')
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ featureFlags: flags }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم تحديث الميزات')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(null)
    }
  }

  async function patchCountry(id: string, patch: Partial<Country>) {
    try {
      const res = await fetch('/api/admin/countries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...patch }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم تحديث الدولة')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  if (loading) return <Spinner />

  return (
    <div className="space-y-6">
      <PageHeader
        title="إعدادات المتجر"
        description="تهيئة المتجر والبلدان والميزات."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'إعدادات المتجر' }]}
      />

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="flex w-full overflow-x-auto justify-start">
          <TabsTrigger value="general">عام</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="social">شبكات التواصل</TabsTrigger>
          <TabsTrigger value="countries">الدول</TabsTrigger>
          <TabsTrigger value="features">الميزات</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card className="border-amber-200 bg-amber-50">
            <CardContent className="flex items-center justify-between gap-3 p-4">
              <div className="flex items-start gap-3">
                <Palette className="size-5 text-amber-700 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-800">
                    إدارة الشعار والألوان والهوية البصرية
                  </p>
                  <p className="text-xs text-amber-700">
                    انتقل إلى قسم الهوية البصرية لرفع الشعار وتعيين الألوان الرئيسية.
                  </p>
                </div>
              </div>
              <Button asChild variant="outline" size="sm" className="border-amber-300 bg-white">
                <Link href="/admin/visual-identity">
                  الذهاب إلى الهوية البصرية
                  <ArrowLeft className="size-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">معلومات عامة</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              {GENERAL_KEYS.map((k) => (
                <div key={k} className="space-y-1.5">
                  <Label htmlFor={`g-${k}`}>{GENERAL_LABELS[k]}</Label>
                  {k === 'site_description' || k === 'address' || k === 'announcement_bar' ? (
                    <Textarea
                      id={`g-${k}`}
                      rows={k === 'announcement_bar' ? 2 : 3}
                      value={general[k] ?? ''}
                      onChange={(e) => setSetting('general', k, e.target.value)}
                    />
                  ) : (
                    <Input
                      id={`g-${k}`}
                      value={general[k] ?? ''}
                      onChange={(e) => setSetting('general', k, e.target.value)}
                      dir={k === 'support_email' || k === 'whatsapp' ? 'ltr' : undefined}
                      className={k === 'support_email' || k === 'whatsapp' ? 'text-left' : undefined}
                    />
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">العرض</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">إظهار شريط الإعلان</p>
                  <p className="text-muted-foreground text-xs">
                    شريط في أعلى الموقع بالنص أعلاه.
                  </p>
                </div>
                <Switch checked={showAnnouncement} onCheckedChange={setShowAnnouncement} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">وضع الصيانة</p>
                  <p className="text-muted-foreground text-xs">
                    لن يكون المتجر متاحاً للزوار.
                  </p>
                </div>
                <Switch checked={maintenanceMode} onCheckedChange={setMaintenanceMode} />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-start">
            <Button
              onClick={() => saveSettings('general')}
              disabled={saving !== null}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {saving === 'general' ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Save className="size-4" />
              )}
              حفظ التغييرات
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">SEO العام</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              {SEO_KEYS.map((k) => (
                <div key={k} className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor={`s-${k}`}>{SEO_LABELS[k]}</Label>
                  {k === 'seo_description' ? (
                    <Textarea
                      id={`s-${k}`}
                      rows={3}
                      value={seo[k] ?? ''}
                      onChange={(e) => setSetting('seo', k, e.target.value)}
                    />
                  ) : (
                    <Input
                      id={`s-${k}`}
                      value={seo[k] ?? ''}
                      onChange={(e) => setSetting('seo', k, e.target.value)}
                      dir="ltr"
                      className="text-left"
                    />
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
          <div className="flex justify-start">
            <Button
              onClick={() => saveSettings('seo')}
              disabled={saving !== null}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {saving === 'seo' ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Save className="size-4" />
              )}
              حفظ التغييرات
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="social" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">شبكات التواصل الاجتماعي</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              {SOCIAL_KEYS.map((k) => (
                <div key={k} className="space-y-1.5">
                  <Label htmlFor={`so-${k}`}>{SOCIAL_LABELS[k]}</Label>
                  <Input
                    id={`so-${k}`}
                    value={social[k] ?? ''}
                    onChange={(e) => setSetting('social', k, e.target.value)}
                    placeholder="https://…"
                    dir="ltr"
                    className="text-left"
                  />
                </div>
              ))}
            </CardContent>
          </Card>
          <div className="flex justify-start">
            <Button
              onClick={() => saveSettings('social')}
              disabled={saving !== null}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {saving === 'social' ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Save className="size-4" />
              )}
              حفظ التغييرات
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="countries" className="space-y-4">
          <Card className="p-0 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الدولة</TableHead>
                  <TableHead>الرمز</TableHead>
                  <TableHead>العملة</TableHead>
                  <TableHead>الشحن الأساسي</TableHead>
                  <TableHead>مُفعّل</TableHead>
                  <TableHead>افتراضي</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {countries.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell className="font-mono text-xs">{c.code}</TableCell>
                    <TableCell>
                      {c.currencyCode} ({c.currencySymbol})
                    </TableCell>
                    <TableCell>
                      <Input
                        defaultValue={String(c.shippingBase ?? '0')}
                        className="h-8 w-24"
                        onBlur={(e) => {
                          const v = Number(e.target.value)
                          if (!Number.isNaN(v) && v !== Number(c.shippingBase)) {
                            patchCountry(c.id, { shippingBase: v as any })
                          }
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={c.isEnabled}
                        onCheckedChange={(v) =>
                          patchCountry(c.id, { isEnabled: v as any })
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={c.isDefault}
                        onCheckedChange={(v) => {
                          if (v) patchCountry(c.id, { isDefault: true as any })
                        }}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="features" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">الميزات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {FEATURE_FLAGS.map((f) => (
                <div
                  key={f.key}
                  className="flex items-center justify-between rounded-lg border p-3"
                >
                  <div>
                    <p className="text-sm font-medium">{f.label}</p>
                    <p className="text-muted-foreground text-xs font-mono">{f.key}</p>
                  </div>
                  <Switch
                    checked={!!flags[f.key]}
                    onCheckedChange={(v) =>
                      setFlags((s) => ({ ...s, [f.key]: v }))
                    }
                  />
                </div>
              ))}
            </CardContent>
          </Card>
          <div className="flex justify-start">
            <Button
              onClick={saveFlags}
              disabled={saving !== null}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {saving === 'features' ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Save className="size-4" />
              )}
              حفظ التغييرات
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
