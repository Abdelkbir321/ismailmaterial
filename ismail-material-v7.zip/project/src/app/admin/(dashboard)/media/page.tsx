'use client'

import * as React from 'react'
import { toast } from 'sonner'
import {
  Upload,
  Loader2,
  Image as ImageIcon,
  Link as LinkIcon,
  Trash2,
  Pencil,
} from 'lucide-react'

import { timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

interface MediaAsset {
  id: string
  sourceType: string
  publicId: string | null
  externalUrl: string | null
  secureUrl: string
  url: string
  width: number | null
  height: number | null
  format: string | null
  bytes: number | null
  resourceType: string | null
  altText: string | null
  tags: string[]
  uploadedByAdminId: string | null
  createdAt: string
}

function sourceBadge(sourceType: string) {
  if (sourceType === 'cloudinary') {
    return (
      <span className="bg-emerald-600 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
        Cloudinary
      </span>
    )
  }
  if (sourceType === 'external') {
    return (
      <span className="bg-orange-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
        رابط خارجي
      </span>
    )
  }
  return (
    <span className="bg-zinc-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">
      مؤقت
    </span>
  )
}

function formatBytes(n: number | null): string {
  if (!n) return '—'
  if (n < 1024) return `${n} ب`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} كب`
  return `${(n / (1024 * 1024)).toFixed(1)} مب`
}

export default function MediaPage() {
  const [assets, setAssets] = React.useState<MediaAsset[]>([])
  const [loading, setLoading] = React.useState(true)
  const [uploading, setUploading] = React.useState(false)
  const fileRef = React.useRef<HTMLInputElement>(null)

  // Add by URL state
  const [externalUrl, setExternalUrl] = React.useState('')
  const [externalAlt, setExternalAlt] = React.useState('')
  const [addingExternal, setAddingExternal] = React.useState(false)

  // Detail dialog state
  const [detail, setDetail] = React.useState<MediaAsset | null>(null)
  const [altEdit, setAltEdit] = React.useState('')
  const [savingAlt, setSavingAlt] = React.useState(false)
  const [deleting, setDeleting] = React.useState(false)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/media?take=50', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setAssets(json.assets)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function uploadFiles(files: FileList | null) {
    if (!files || files.length === 0) return
    setUploading(true)
    try {
      for (const file of Array.from(files)) {
        const formData = new FormData()
        formData.append('file', file)
        if (externalAlt) formData.append('altText', externalAlt)
        const res = await fetch('/api/admin/upload', {
          method: 'POST',
          body: formData,
          credentials: 'include',
        })
        const json = await res.json()
        if (!res.ok || !json.ok) {
          toast.error(json.error || 'فشل الرفع')
          continue
        }
      }
      toast.success('تم رفع الصور')
      load()
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  async function addExternal() {
    const url = externalUrl.trim()
    if (!url) {
      toast.error('أدخل رابط الصورة.')
      return
    }
    if (!/^https?:\/\//i.test(url)) {
      toast.error('الرابط غير صالح (يجب أن يبدأ بـ http أو https).')
      return
    }
    setAddingExternal(true)
    try {
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          externalUrl: url,
          altText: externalAlt || undefined,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'الرابط لا يشير لصورة صالحة.')
        return
      }
      toast.success('تمت إضافة الصورة')
      setExternalUrl('')
      setExternalAlt('')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setAddingExternal(false)
    }
  }

  function openDetail(a: MediaAsset) {
    setDetail(a)
    setAltEdit(a.altText || '')
  }

  async function saveAlt() {
    if (!detail) return
    setSavingAlt(true)
    try {
      const res = await fetch(`/api/admin/media/${detail.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ altText: altEdit }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم حفظ النص البديل')
      setDetail(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSavingAlt(false)
    }
  }

  async function removeAsset() {
    if (!detail) return
    if (!confirm('حذف هذا الأصل من مكتبة الوسائط؟')) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin/media/${detail.id}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحذف')
        return
      }
      toast.success('تم الحذف')
      setDetail(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="الوسائط"
        description="مكتبة الصور المرفوعة عبر Cloudinary أو الروابط الخارجية."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الوسائط' }]}
      />

      {/* Upload card */}
      <Card className="p-4 space-y-4">
        <div>
          <Label className="mb-1.5 block">رفع صورة</Label>
          <div
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
          >
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => uploadFiles(e.target.files)}
            />
            {uploading ? (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Loader2 className="size-6 animate-spin" />
                <p className="text-sm">جارٍ الرفع…</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Upload className="size-6" />
                <p className="text-sm font-medium">
                  اسحب الصور هنا أو اضغط لتصفح الملفات
                </p>
                <p className="text-xs">PNG، JPG، WEBP — حد أقصى 5 ميغابايت</p>
              </div>
            )}
          </div>
        </div>

        <div className="border-t pt-4">
          <Label className="mb-1.5 block">إضافة برابط</Label>
          <div className="grid gap-2 sm:grid-cols-3">
            <Input
              placeholder="https://example.com/image.jpg"
              value={externalUrl}
              onChange={(e) => setExternalUrl(e.target.value)}
              dir="ltr"
              className="text-left"
            />
            <Input
              placeholder="النص البديل — اختياري"
              value={externalAlt}
              onChange={(e) => setExternalAlt(e.target.value)}
            />
            <Button
              onClick={addExternal}
              disabled={addingExternal || !externalUrl}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {addingExternal ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <LinkIcon className="size-4" />
              )}
              إضافة
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            يتم التحقق من الرابط على الخادم عند الإضافة.
          </p>
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : assets.length === 0 ? (
        <EmptyState
          title="لا توجد وسائط"
          description="ارفع أول صورة أو أضفها برابط."
          icon={<ImageIcon className="size-5" />}
        />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {assets.map((a) => (
            <button
              key={a.id}
              onClick={() => openDetail(a)}
              className="group border rounded-lg overflow-hidden bg-muted hover:shadow-md transition-shadow text-right"
            >
              <div className="aspect-square relative">
                <img
                  src={a.secureUrl}
                  alt={a.altText || ''}
                  className="size-full object-cover"
                  loading="lazy"
                />
                <div className="absolute top-1 right-1">
                  {sourceBadge(a.sourceType)}
                </div>
              </div>
              <div className="p-2 space-y-0.5 text-xs">
                <p className="font-mono truncate text-muted-foreground" dir="ltr">
                  {a.publicId || a.externalUrl || '—'}
                </p>
                <p className="text-muted-foreground">
                  {a.width && a.height ? `${a.width}×${a.height}` : '—'}
                  {a.format ? ` · ${a.format}` : ''}
                </p>
                <p className="text-muted-foreground">{timeAgoAr(a.createdAt)}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Detail dialog */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>تفاصيل الأصل</DialogTitle>
            <DialogDescription>
              راجع البيانات وعدّل النص البديل.
            </DialogDescription>
          </DialogHeader>
          {detail && (
            <div className="space-y-3">
              <div className="bg-muted rounded-lg overflow-hidden flex items-center justify-center min-h-48">
                <img
                  src={detail.secureUrl}
                  alt={detail.altText || ''}
                  className="max-h-64 max-w-full object-contain"
                />
              </div>
              <div className="grid gap-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">المصدر</span>
                  <span className="font-mono text-xs">{detail.sourceType}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">المعرّف</span>
                  <span className="font-mono text-xs truncate max-w-[60%]" dir="ltr">
                    {detail.publicId || detail.externalUrl || '—'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">الأبعاد</span>
                  <span className="text-xs">
                    {detail.width && detail.height
                      ? `${detail.width}×${detail.height}`
                      : '—'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">الحجم</span>
                  <span className="text-xs">{formatBytes(detail.bytes)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">الصيغة</span>
                  <span className="font-mono text-xs">{detail.format || '—'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">أُنشئ</span>
                  <span className="text-xs">{timeAgoAr(detail.createdAt)}</span>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="alt">النص البديل (alt)</Label>
                <Input
                  id="alt"
                  value={altEdit}
                  onChange={(e) => setAltEdit(e.target.value)}
                  placeholder="وصف الصورة لقارئات الشاشة"
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2 sm:justify-between">
            <Button
              variant="outline"
              onClick={removeAsset}
              disabled={deleting || savingAlt}
              className="text-rose-600 border-rose-200 hover:bg-rose-50"
            >
              {deleting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Trash2 className="size-4" />
              )}
              حذف
            </Button>
            <Button
              onClick={saveAlt}
              disabled={savingAlt}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {savingAlt ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Pencil className="size-4" />
              )}
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
