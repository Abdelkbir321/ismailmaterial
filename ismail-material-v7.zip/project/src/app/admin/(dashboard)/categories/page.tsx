'use client'

import * as React from 'react'
import { Plus, Loader2, Tag } from 'lucide-react'
import { toast } from 'sonner'

import { slugify, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

interface Category {
  id: string
  slug: string
  name: string
  nameAr: string | null
  description: string | null
  isVisible: boolean
  sortOrder: number
  _count?: { products: number }
  createdAt?: string
}

export default function AdminCategoriesPage() {
  const [items, setItems] = React.useState<Category[]>([])
  const [loading, setLoading] = React.useState(true)
  const [open, setOpen] = React.useState(false)
  const [name, setName] = React.useState('')
  const [slug, setSlug] = React.useState('')
  const [nameAr, setNameAr] = React.useState('')
  const [description, setDescription] = React.useState('')
  const [isVisible, setIsVisible] = React.useState(true)
  const [slugTouched, setSlugTouched] = React.useState(false)
  const [saving, setSaving] = React.useState(false)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/categories', { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setItems(json.categories)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          slug: slug || slugify(name),
          nameAr,
          description,
          isVisible,
          sortOrder: 0,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الإنشاء')
        return
      }
      toast.success('تم إنشاء الفئة')
      setOpen(false)
      setName('')
      setSlug('')
      setNameAr('')
      setDescription('')
      setIsVisible(true)
      setSlugTouched(false)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="الفئات"
        description="نظّم كتالوجك حسب الفئات."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الفئات' }]}
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="bg-zinc-900 hover:bg-zinc-800">
                <Plus className="size-4" />
                فئة جديدة
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>فئة جديدة</DialogTitle>
                <DialogDescription>
                  الفئات تتيح تجميع منتجاتك.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <div className="space-y-1.5">
                  <Label htmlFor="c-name">الاسم</Label>
                  <Input
                    id="c-name"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value)
                      if (!slugTouched) setSlug(slugify(e.target.value))
                    }}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-slug">الرابط (Slug)</Label>
                  <Input
                    id="c-slug"
                    value={slug}
                    onChange={(e) => {
                      setSlugTouched(true)
                      setSlug(slugify(e.target.value))
                    }}
                    dir="ltr"
                    className="text-left"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-nameAr">الاسم بالعربية</Label>
                  <Input
                    id="c-nameAr"
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-desc">الوصف</Label>
                  <Textarea
                    id="c-desc"
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <span className="text-sm font-medium">ظاهرة</span>
                  <Switch checked={isVisible} onCheckedChange={setIsVisible} />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
                    {saving ? <Loader2 className="size-4 animate-spin" /> : null}
                    إنشاء
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد فئات"
          description="أنشئ أول فئة."
          icon={<Tag className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الاسم</TableHead>
                <TableHead>الرابط</TableHead>
                <TableHead className="text-left">المنتجات</TableHead>
                <TableHead>ظاهرة</TableHead>
                <TableHead>أُنشئت</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell className="font-mono text-xs" dir="ltr">/{c.slug}</TableCell>
                  <TableCell className="text-left tabular-nums">
                    {c._count?.products ?? 0}
                  </TableCell>
                  <TableCell>
                    {c.isVisible ? (
                      <span className="text-emerald-700 text-xs font-medium">نعم</span>
                    ) : (
                      <span className="text-muted-foreground text-xs">لا</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {c.createdAt ? timeAgoAr(c.createdAt) : '—'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  )
}
