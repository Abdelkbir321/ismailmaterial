'use client'

import * as React from 'react'
import { Globe } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Country {
  id: string
  code: string
  name: string
  isEnabled: boolean
  isDefault: boolean
  currencyCode: string
  currencySymbol: string
  phonePrefix: string
  shippingBase: string | number
  shippingPerKg: string | number
  taxRate: string | number
  sortOrder: number
}

export default function AdminCountriesPage() {
  const [items, setItems] = React.useState<Country[]>([])
  const [loading, setLoading] = React.useState(true)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/countries', { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setItems(json.countries)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function patch(id: string, patch: Partial<Country>) {
    try {
      const res = await fetch('/api/admin/countries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...patch }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم تحديث الدولة')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="الدول والعملات"
        description="فعّل الدول التي تشحن إليها."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الدول' }]}
      />

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد دول"
          description="أضف دولاً من قاعدة البيانات."
          icon={<Globe className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الدولة</TableHead>
                <TableHead>الرمز</TableHead>
                <TableHead>العملة</TableHead>
                <TableHead>البادئة</TableHead>
                <TableHead>الشحن</TableHead>
                <TableHead>الضريبة (%)</TableHead>
                <TableHead>مُفعّل</TableHead>
                <TableHead>افتراضي</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell className="font-mono text-xs">{c.code}</TableCell>
                  <TableCell>
                    {c.currencyCode} ({c.currencySymbol})
                  </TableCell>
                  <TableCell className="text-sm" dir="ltr">{c.phonePrefix}</TableCell>
                  <TableCell>
                    <Input
                      defaultValue={String(c.shippingBase ?? '0')}
                      className="h-8 w-24"
                      onBlur={(e) => {
                        const v = Number(e.target.value)
                        if (!Number.isNaN(v) && v !== Number(c.shippingBase)) {
                          patch(c.id, { shippingBase: v as any })
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      defaultValue={String(c.taxRate ?? '0')}
                      className="h-8 w-16"
                      onBlur={(e) => {
                        const v = Number(e.target.value)
                        if (!Number.isNaN(v) && v !== Number(c.taxRate)) {
                          patch(c.id, { taxRate: v as any })
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={c.isEnabled}
                      onCheckedChange={(v) => patch(c.id, { isEnabled: v as any })}
                    />
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={c.isDefault}
                      onCheckedChange={(v) => {
                        if (v) patch(c.id, { isDefault: true as any })
                      }}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  )
}
