'use client'

import * as React from 'react'
import { Plus, Loader2, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'

import { slugify, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

interface Brand {
  id: string
  slug: string
  name: string
  nameAr: string | null
  countryOfOrigin: string | null
  isVisible: boolean
  _count?: { products: number }
  createdAt?: string
}

export default function AdminBrandsPage() {
  const [items, setItems] = React.useState<Brand[]>([])
  const [loading, setLoading] = React.useState(true)
  const [open, setOpen] = React.useState(false)
  const [name, setName] = React.useState('')
  const [slug, setSlug] = React.useState('')
  const [nameAr, setNameAr] = React.useState('')
  const [countryOfOrigin, setCountryOfOrigin] = React.useState('')
  const [description, setDescription] = React.useState('')
  const [isVisible, setIsVisible] = React.useState(true)
  const [slugTouched, setSlugTouched] = React.useState(false)
  const [saving, setSaving] = React.useState(false)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/brands', { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setItems(json.brands)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/brands', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          slug: slug || slugify(name),
          nameAr,
          description,
          countryOfOrigin,
          isVisible,
          sortOrder: 0,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم إنشاء الماركة')
      setOpen(false)
      setName('')
      setSlug('')
      setNameAr('')
      setCountryOfOrigin('')
      setDescription('')
      setIsVisible(true)
      setSlugTouched(false)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="الماركات"
        description="إدارة ماركات الكتالوج."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الماركات' }]}
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="bg-zinc-900 hover:bg-zinc-800">
                <Plus className="size-4" />
                ماركة جديدة
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>ماركة جديدة</DialogTitle>
                <DialogDescription>
                  مثال: Ingco، Total Tools، Crown، Würth.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <div className="space-y-1.5">
                  <Label htmlFor="b-name">الاسم</Label>
                  <Input
                    id="b-name"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value)
                      if (!slugTouched) setSlug(slugify(e.target.value))
                    }}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="b-slug">الرابط (Slug)</Label>
                  <Input
                    id="b-slug"
                    value={slug}
                    onChange={(e) => {
                      setSlugTouched(true)
                      setSlug(slugify(e.target.value))
                    }}
                    dir="ltr"
                    className="text-left"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="b-nameAr">الاسم بالعربية</Label>
                  <Input
                    id="b-nameAr"
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="b-country">بلد المنشأ</Label>
                  <Input
                    id="b-country"
                    value={countryOfOrigin}
                    onChange={(e) => setCountryOfOrigin(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="b-desc">الوصف</Label>
                  <Textarea
                    id="b-desc"
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <span className="text-sm font-medium">ظاهرة</span>
                  <Switch checked={isVisible} onCheckedChange={setIsVisible} />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
                    {saving ? <Loader2 className="size-4 animate-spin" /> : null}
                    إنشاء
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد ماركات"
          description="أضف أول ماركة."
          icon={<ShieldCheck className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الاسم</TableHead>
                <TableHead>الرابط</TableHead>
                <TableHead>البلد</TableHead>
                <TableHead className="text-left">المنتجات</TableHead>
                <TableHead>ظاهرة</TableHead>
                <TableHead>أُنشئت</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="font-medium">{b.name}</TableCell>
                  <TableCell className="font-mono text-xs" dir="ltr">/{b.slug}</TableCell>
                  <TableCell className="text-sm">{b.countryOfOrigin || '—'}</TableCell>
                  <TableCell className="text-left tabular-nums">
                    {b._count?.products ?? 0}
                  </TableCell>
                  <TableCell>
                    {b.isVisible ? (
                      <span className="text-emerald-700 text-xs font-medium">نعم</span>
                    ) : (
                      <span className="text-muted-foreground text-xs">لا</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {b.createdAt ? timeAgoAr(b.createdAt) : '—'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  )
}
