'use client'

import * as React from 'react'
import { toast } from 'sonner'
import {
  Loader2,
  Save,
  UserCircle,
  KeyRound,
  Eye,
  EyeOff,
  ShieldCheck,
  Clock,
  AlertCircle,
} from 'lucide-react'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { timeAgoAr, formatDateAr } from '@/lib/format'
import { cn } from '@/lib/utils'

interface MyAccount {
  id: string
  email: string
  fullName: string
  role: { slug: string; name: string; permissions: Record<string, string[]> }
  status: 'ACTIVE' | 'DISABLED' | 'LOCKED'
  lastLoginAt: string | null
  lastLoginIp?: string | null
}

/** Roughly estimate password strength. Returns 0..4. */
function passwordStrength(pw: string): number {
  if (!pw) return 0
  let score = 0
  if (pw.length >= 8) score++
  if (pw.length >= 12) score++
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++
  if (/\d/.test(pw)) score++
  if (/[^A-Za-z0-9]/.test(pw)) score++
  return Math.min(score, 4)
}

const STRENGTH_LABEL: Array<{ label: string; class: string }> = [
  { label: 'قصيرة جدًا', class: 'bg-rose-500' },
  { label: 'ضعيفة', class: 'bg-rose-500' },
  { label: 'متوسطة', class: 'bg-amber-500' },
  { label: 'جيدة', class: 'bg-teal-500' },
  { label: 'قوية', class: 'bg-emerald-500' },
]

const STATUS_BADGE: Record<string, string> = {
  ACTIVE: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  DISABLED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  LOCKED: 'bg-amber-50 text-amber-700 ring-amber-600/20',
}
const STATUS_LABEL: Record<string, string> = {
  ACTIVE: 'نشط',
  DISABLED: 'معطّل',
  LOCKED: 'مقفل',
}

export default function MyAccountPage() {
  const [account, setAccount] = React.useState<MyAccount | null>(null)
  const [loading, setLoading] = React.useState(true)

  // Profile form state
  const [fullName, setFullName] = React.useState('')
  const [email, setEmail] = React.useState('')
  const [profileSaving, setProfileSaving] = React.useState(false)
  const [profileErrors, setProfileErrors] = React.useState<Record<string, string>>({})

  // Password form state
  const [currentPassword, setCurrentPassword] = React.useState('')
  const [newPassword, setNewPassword] = React.useState('')
  const [confirmPassword, setConfirmPassword] = React.useState('')
  const [showCurrent, setShowCurrent] = React.useState(false)
  const [showNew, setShowNew] = React.useState(false)
  const [showConfirm, setShowConfirm] = React.useState(false)
  const [pwSaving, setPwSaving] = React.useState(false)
  const [pwErrors, setPwErrors] = React.useState<Record<string, string>>({})

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/my-account', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setAccount(json.account as MyAccount)
      setFullName(json.account.fullName)
      setEmail(json.account.email)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault()
    if (profileSaving) return
    setProfileErrors({})
    setProfileSaving(true)
    try {
      const res = await fetch('/api/admin/my-account', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, email }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        if (json.fieldErrors) {
          setProfileErrors(json.fieldErrors as Record<string, string>)
        }
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success('تم تحديث الملف الشخصي')
      // Refresh topbar (admin name) — server components will re-render on router refresh
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setProfileSaving(false)
    }
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault()
    if (pwSaving) return
    setPwErrors({})
    if (newPassword.length < 8) {
      setPwErrors({ newPassword: 'كلمة المرور الجديدة 8 أحرف على الأقل' })
      return
    }
    if (newPassword !== confirmPassword) {
      setPwErrors({ confirmPassword: 'كلمتا المرور غير متطابقتين' })
      return
    }
    setPwSaving(true)
    try {
      const res = await fetch('/api/admin/my-account/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        if (json.fieldErrors) {
          setPwErrors(json.fieldErrors as Record<string, string>)
        }
        toast.error(json.error || 'فشل تغيير كلمة المرور')
        return
      }
      toast.success('تم تغيير كلمة المرور. ستحتاج لتسجيل الدخول من جديد على الأجهزة الأخرى')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setPwSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title="حسابي" description="ملفك الشخصي وإعدادات الأمان." />
        <Spinner />
      </div>
    )
  }

  if (!account) {
    return (
      <div className="space-y-6">
        <PageHeader title="حسابي" description="ملفك الشخصي وإعدادات الأمان." />
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-12 text-center">
          <AlertCircle className="size-6 text-amber-600" />
          <p className="text-sm text-muted-foreground">تعذّر تحميل بيانات حسابك.</p>
          <Button variant="outline" size="sm" onClick={load}>إعادة المحاولة</Button>
        </div>
      </div>
    )
  }

  const isSuper = account.role.slug === 'super-admin'
  const strength = passwordStrength(newPassword)
  const strengthInfo = STRENGTH_LABEL[strength]

  return (
    <div className="space-y-6">
      <PageHeader
        title="حسابي"
        description="ملفك الشخصي وإعدادات الأمان."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'حسابي' }]}
      />

      {/* Identity card */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <div
                className={cn(
                  'rounded-full size-12 flex items-center justify-center font-bold text-white',
                  isSuper ? 'bg-amber-500' : 'bg-zinc-900',
                )}
              >
                {(account.fullName || '?')
                  .split(' ')
                  .map((s) => s[0])
                  .join('')
                  .slice(0, 2)
                  .toUpperCase()}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-lg">{account.fullName}</p>
                  <span
                    className={cn(
                      'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset',
                      isSuper
                        ? 'bg-amber-100 text-amber-800 ring-amber-600/30'
                        : 'bg-zinc-100 text-zinc-700 ring-zinc-600/20',
                    )}
                  >
                    {isSuper && <ShieldCheck className="size-3 mr-1" />}
                    {account.role.name}
                  </span>
                </div>
                <p className="text-muted-foreground text-sm" dir="ltr">
                  {account.email}
                </p>
              </div>
            </div>
            <div className="flex flex-col gap-2 sm:items-end text-sm">
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">الحالة:</span>
                <span
                  className={cn(
                    'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset',
                    STATUS_BADGE[account.status],
                  )}
                >
                  {STATUS_LABEL[account.status]}
                </span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-xs">
                <Clock className="size-3.5" />
                {account.lastLoginAt ? (
                  <span>آخر دخول: {timeAgoAr(account.lastLoginAt)}</span>
                ) : (
                  <span>لا يوجد دخول سابق</span>
                )}
              </div>
              {account.lastLoginIp && (
                <span
                  className="text-muted-foreground text-[11px] font-mono"
                  dir="ltr"
                >
                  {account.lastLoginIp}
                </span>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="profile">
        <TabsList>
          <TabsTrigger value="profile">
            <UserCircle className="size-4" />
            المعلومات الشخصية
          </TabsTrigger>
          <TabsTrigger value="password">
            <KeyRound className="size-4" />
            كلمة المرور
          </TabsTrigger>
        </TabsList>

        {/* Profile tab */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>المعلومات الشخصية</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={saveProfile} className="space-y-4 max-w-lg">
                <div className="space-y-1.5">
                  <Label htmlFor="ma-full">الاسم الكامل</Label>
                  <Input
                    id="ma-full"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    minLength={2}
                    maxLength={120}
                  />
                  {profileErrors.fullName && (
                    <p className="text-rose-600 text-xs">{profileErrors.fullName}</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ma-email">البريد الإلكتروني</Label>
                  <Input
                    id="ma-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    dir="ltr"
                    className="text-left"
                  />
                  {profileErrors.email && (
                    <p className="text-rose-600 text-xs">{profileErrors.email}</p>
                  )}
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <Button
                    type="submit"
                    className="bg-zinc-900 hover:bg-zinc-800"
                    disabled={profileSaving}
                  >
                    {profileSaving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                    حفظ التغييرات
                  </Button>
                  <p className="text-muted-foreground text-xs">
                    آخر تحديث للملف: {formatDateAr(new Date())}
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Password tab */}
        <TabsContent value="password">
          <Card>
            <CardHeader>
              <CardTitle>تغيير كلمة المرور</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={savePassword} className="space-y-4 max-w-lg">
                <div className="space-y-1.5">
                  <Label htmlFor="ma-current">كلمة المرور الحالية</Label>
                  <div className="relative">
                    <Input
                      id="ma-current"
                      type={showCurrent ? 'text' : 'password'}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                      dir="ltr"
                      className="text-left pl-9"
                      autoComplete="current-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrent((v) => !v)}
                      className="absolute left-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      aria-label={showCurrent ? 'إخفاء' : 'إظهار'}
                    >
                      {showCurrent ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                    </button>
                  </div>
                  {pwErrors.currentPassword && (
                    <p className="text-rose-600 text-xs">{pwErrors.currentPassword}</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ma-new">كلمة المرور الجديدة</Label>
                  <div className="relative">
                    <Input
                      id="ma-new"
                      type={showNew ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      required
                      dir="ltr"
                      className="text-left pl-9"
                      autoComplete="new-password"
                      minLength={8}
                    />
                    <button
                      type="button"
                      onClick={() => setShowNew((v) => !v)}
                      className="absolute left-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      aria-label={showNew ? 'إخفاء' : 'إظهار'}
                    >
                      {showNew ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                    </button>
                  </div>
                  {newPassword && (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                        <div
                          className={cn('h-full transition-all', strengthInfo.class)}
                          style={{ width: `${(strength / 4) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground">{strengthInfo.label}</span>
                    </div>
                  )}
                  {pwErrors.newPassword && (
                    <p className="text-rose-600 text-xs">{pwErrors.newPassword}</p>
                  )}
                  <p className="text-muted-foreground text-[11px]">
                    8 أحرف على الأقل. يُنصح بمزج الأحرف الكبيرة والصغيرة والأرقام والرموز.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ma-confirm">تأكيد كلمة المرور</Label>
                  <div className="relative">
                    <Input
                      id="ma-confirm"
                      type={showConfirm ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                      dir="ltr"
                      className="text-left pl-9"
                      autoComplete="new-password"
                      minLength={8}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirm((v) => !v)}
                      className="absolute left-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      aria-label={showConfirm ? 'إخفاء' : 'إظهار'}
                    >
                      {showConfirm ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                    </button>
                  </div>
                  {pwErrors.confirmPassword && (
                    <p className="text-rose-600 text-xs">{pwErrors.confirmPassword}</p>
                  )}
                </div>
                <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-3 text-amber-800 text-xs flex items-start gap-2">
                  <AlertCircle className="size-4 shrink-0 mt-0.5" />
                  <p>
                    عند تغيير كلمة المرور، سيتم إنهاء جميع جلساتك على الأجهزة الأخرى. ستحتاج
                    لتسجيل الدخول من جديد عليها باستخدام كلمة المرور الجديدة.
                  </p>
                </div>
                <Button
                  type="submit"
                  className="bg-zinc-900 hover:bg-zinc-800"
                  disabled={pwSaving}
                >
                  {pwSaving ? <Loader2 className="size-4 animate-spin" /> : <KeyRound className="size-4" />}
                  تغيير كلمة المرور
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
