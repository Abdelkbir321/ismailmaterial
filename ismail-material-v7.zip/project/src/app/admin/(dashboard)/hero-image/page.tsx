'use client'

import * as React from 'react'
import { Loader2, Save, Globe, ImageIcon, RotateCcw, Upload, AlertTriangle } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'

const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/svg+xml', 'image/gif']
const MAX_IMAGE_SIZE = 5 * 1024 * 1024

export default function HeroImagePage() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState(false)
  const [heroImageUrl, setHeroImageUrl] = React.useState<string | null>(null)
  const [urlInput, setUrlInput] = React.useState('')
  const [previewUrl, setPreviewUrl] = React.useState<string | null>(null)
  const [previewError, setPreviewError] = React.useState(false)
  const [uploading, setUploading] = React.useState(false)
  const [cloudinaryConfigured, setCloudinaryConfigured] = React.useState(true)
  const fileRef = React.useRef<HTMLInputElement>(null)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/visual-identity', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setHeroImageUrl(json.settings?.hero_image_url || null)
      setCloudinaryConfigured(!!json.cloudinaryConfigured)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function uploadImage(file: File) {
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      toast.error(`صيغة غير مدعومة. المسموح: ${ALLOWED_IMAGE_TYPES.join(', ')}`)
      return
    }
    if (file.size > MAX_IMAGE_SIZE) {
      toast.error(`حجم الملف كبير جداً. الحد الأقصى: ${MAX_IMAGE_SIZE / 1024 / 1024} MB`)
      return
    }
    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل رفع الصورة')
        return
      }
      const secureUrl = json.asset?.secureUrl || json.image?.secureUrl
      if (!secureUrl) {
        toast.error('لم يرجع الخادم رابط الصورة')
        return
      }
      // Save to DB
      const putRes = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { hero_image_url: secureUrl } }),
        credentials: 'include',
      })
      const putJson = await putRes.json()
      if (!putRes.ok || !putJson.ok) {
        toast.error(putJson.error || 'فشل حفظ الصورة')
        return
      }
      setHeroImageUrl(secureUrl)
      setPreviewUrl(secureUrl)
      setPreviewError(false)
      setUrlInput('')
      toast.success('تم رفع الصورة وحفظها — ستظهر في الواجهة الرئيسية')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  function previewUrlHandler() {
    const url = urlInput.trim()
    if (!url) {
      toast.error('أدخل رابط الصورة أولاً')
      return
    }
    if (!/^https?:\/\/[^\s]+$/.test(url) && !url.startsWith('/')) {
      toast.error('الرابط غير صالح (يجب أن يبدأ بـ http(s):// أو /)')
      return
    }
    setPreviewError(false)
    setPreviewUrl(url)
  }

  async function saveUrl() {
    const url = urlInput.trim()
    if (!url) {
      toast.error('أدخل رابط الصورة')
      return
    }
    if (!/^https?:\/\/[^\s]+$/.test(url) && !url.startsWith('/')) {
      toast.error('الرابط غير صالح')
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { hero_image_url: url } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      setHeroImageUrl(url)
      setUrlInput('')
      setPreviewUrl(null)
      toast.success('تم حفظ صورة الواجهة الرئيسية — ستظهر للزوار')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  async function removeImage() {
    if (!confirm('متأكد من إزالة صورة الواجهة الرئيسية؟ ستعود الصورة الافتراضية.')) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { hero_image_url: '' } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحذف')
        return
      }
      setHeroImageUrl(null)
      setPreviewUrl(null)
      setUrlInput('')
      toast.success('تم إزالة الصورة — ستعود الصورة الافتراضية')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <Spinner />

  return (
    <div className="space-y-6">
      <PageHeader
        title="صورة الواجهة الرئيسية"
        description="الصورة التي تظهر في الجهة اليمنى للواجهة الرئيسية (بدلاً من المشهد ثلاثي الأبعاد القديم)."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'صورة الواجهة الرئيسية' }]}
      />

      {!cloudinaryConfigured && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="size-5 text-amber-700 mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-amber-800">Cloudinary غير مهيأ</p>
            <p className="text-xs text-amber-700">
              عيّن CLOUDINARY_CLOUD_NAME، CLOUDINARY_API_KEY، CLOUDINARY_API_SECRET في Environment Variables لتفعيل رفع الصور من الجهاز.
              يمكنك مؤقتاً استعمال روابط خارجية مباشرة.
            </p>
          </div>
        </div>
      )}

      {/* Current image preview */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ImageIcon className="size-4" /> الصورة الحالية
          </CardTitle>
          <CardDescription>
            هذه الصورة تظهر للزوار في الواجهة الرئيسية. حالياً: {heroImageUrl ? 'مخصصة' : 'افتراضية (لوغو)'}.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-xl border border-border bg-muted/30 p-4">
            <div className="mx-auto max-w-md aspect-[4/3] overflow-hidden rounded-lg bg-card grid place-items-center">
              {heroImageUrl ? (
                <img
                  src={heroImageUrl}
                  alt="صورة الواجهة الرئيسية"
                  className="h-full w-full object-contain"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).style.display = 'none'
                  }}
                />
              ) : (
                <div className="grid size-24 place-items-center rounded-xl bg-[#1A1410]">
                  <img src="/logo.svg" alt="default" className="size-16 object-contain" />
                </div>
              )}
            </div>
            {heroImageUrl && (
              <div className="mt-3 flex items-center justify-between gap-3">
                <a
                  href={heroImageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="truncate text-xs font-mono text-muted-foreground hover:underline"
                  dir="ltr"
                >
                  {heroImageUrl}
                </a>
                <Button variant="outline" size="sm" onClick={removeImage} disabled={saving}>
                  <RotateCcw className="mr-1.5 size-3.5" /> إزالة الصورة
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Upload from computer */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">رفع صورة من الجهاز</CardTitle>
          <CardDescription>ارفع صورة مباشرة من حاسوبك (يستعمل Cloudinary إذا كان مهيأ).</CardDescription>
        </CardHeader>
        <CardContent>
          <div
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
          >
            <input
              ref={fileRef}
              type="file"
              accept={ALLOWED_IMAGE_TYPES.join(',')}
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) uploadImage(f)
              }}
            />
            {uploading ? (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Loader2 className="size-6 animate-spin" />
                <p className="text-sm">جارٍ الرفع…</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Upload className="size-6" />
                <p className="text-sm font-medium">اضغط لاختيار صورة</p>
                <p className="text-xs">PNG, JPG, WebP, SVG — حد أقصى 5MB</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* External URL */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">رابط مباشر للصورة</CardTitle>
          <CardDescription>أدخل رابط صورة مباشر (Image URL) من أي خدمة استضافة صور.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="hero-url">رابط الصورة (Image URL)</Label>
            <Input
              id="hero-url"
              placeholder="https://example.com/hero-image.jpg"
              value={urlInput}
              onChange={(e) => {
                setUrlInput(e.target.value)
                setPreviewUrl(null)
                setPreviewError(false)
              }}
              dir="ltr"
              className="text-left"
            />
          </div>

          {/* Preview */}
          {previewUrl && (
            <div className="rounded-lg border border-border bg-muted/30 p-3">
              <p className="mb-2 text-xs font-medium text-muted-foreground">معاينة:</p>
              {previewError ? (
                <p className="p-4 text-center text-sm text-rose-600">
                  تعذر تحميل الصورة — تأكد من صحة الرابط وأن الصورة متاحة للوصول العام.
                </p>
              ) : (
                <div className="mx-auto max-w-sm aspect-[4/3] overflow-hidden rounded-lg bg-card grid place-items-center">
                  <img
                    src={previewUrl}
                    alt="معاينة"
                    className="h-full w-full object-contain"
                    onError={() => setPreviewError(true)}
                  />
                </div>
              )}
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" size="sm" onClick={previewUrlHandler} disabled={!urlInput || uploading}>
              <Globe className="mr-1.5 size-4" /> معاينة الصورة
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={saveUrl}
              disabled={saving || !urlInput}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />}
              حفظ الصورة
            </Button>
          </div>

          <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
            <strong>ملاحظة:</strong> عند حفظ رابط جديد، يتم التحقق من صيغته فقط. تتعرض الصورة الفعلية في الواجهة مباشرة بعد الحفظ.
            إذا كان الرابط غير صالح، لن تُستبدل الصورة الحالية — استعمل زر «معاينة الصورة» للتأكد قبل الحفظ.
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
