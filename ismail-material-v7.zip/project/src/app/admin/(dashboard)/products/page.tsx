'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  Plus,
  Search,
  Package,
  MoreHorizontal,
  Pencil,
  Archive,
  Star,
} from 'lucide-react'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { ProductStatusBadge } from '@/components/admin/status-badge'
import { TablePagination } from '@/components/admin/table-pagination'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

interface ProductItem {
  id: string
  slug: string
  name: string
  sku: string
  price: number
  compareAtPrice: number | null
  stockQuantity: number
  status: string
  categoryName: string | null
  brandName: string | null
  isFeatured: boolean
  mainImage: string | null
  createdAt: string
}

const PAGE_SIZE = 20

export default function AdminProductsPage() {
  const [items, setItems] = React.useState<ProductItem[]>([])
  const [total, setTotal] = React.useState(0)
  const [page, setPage] = React.useState(1)
  const [q, setQ] = React.useState('')
  const [status, setStatus] = React.useState<string>('all')
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load(p = page, query = q, st = status) {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(p),
        pageSize: String(PAGE_SIZE),
      })
      if (query) params.set('q', query)
      if (st && st !== 'all') params.set('status', st)
      const res = await fetch(`/api/admin/products?${params.toString()}`, {
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setItems(json.items)
      setTotal(json.total)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load(1, '', 'all')
  }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      if (searchInput !== q) {
        setQ(searchInput)
        setPage(1)
        load(1, searchInput, status)
      }
    }, 350)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [searchInput])

  function onStatusChange(s: string) {
    setStatus(s)
    setPage(1)
    load(1, q, s)
  }

  async function archive(id: string) {
    if (!confirm('هل تريد أرشفة هذا المنتج؟ لن يكون مرئياً بعد الآن.')) return
    try {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الأرشفة')
        return
      }
      toast.success('تمت أرشفة المنتج')
      load(page, q, status)
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="المنتجات"
        description="إدارة كتالوج المنتجات."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'المنتجات' }]}
        actions={
          <Button asChild className="bg-zinc-900 hover:bg-zinc-800">
            <Link href="/admin/products/new">
              <Plus className="size-4" />
              إضافة منتج
            </Link>
          </Button>
        }
      />

      <Card className="p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
            <Input
              placeholder="ابحث بالاسم، الرمز (SKU) أو الرابط…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-8"
            />
          </div>
          <Select value={status} onValueChange={onStatusChange}>
            <SelectTrigger className="w-full sm:w-44">
              <SelectValue placeholder="كل الحالات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الحالات</SelectItem>
              <SelectItem value="PUBLISHED">منشور</SelectItem>
              <SelectItem value="DRAFT">مسودة</SelectItem>
              <SelectItem value="OUT_OF_STOCK">نفذ المخزون</SelectItem>
              <SelectItem value="ARCHIVED">مؤرشف</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد منتجات"
          description="أضف أول منتج أو عدّل عوامل التصفية."
          icon={<Package className="size-5" />}
          action={
            <Button asChild className="bg-zinc-900 hover:bg-zinc-800">
              <Link href="/admin/products/new">
                <Plus className="size-4" />
                إضافة منتج
              </Link>
            </Button>
          }
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead>المنتج</TableHead>
                <TableHead>الرمز</TableHead>
                <TableHead>الفئة</TableHead>
                <TableHead>الماركة</TableHead>
                <TableHead className="text-left">السعر</TableHead>
                <TableHead className="text-left">المخزون</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead className="text-left">أُنشئ</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((p) => (
                <TableRow key={p.id}>
                  <TableCell>
                    <div className="bg-muted rounded-md size-10 shrink-0 overflow-hidden border">
                      {p.mainImage ? (
                        <img
                          src={p.mainImage}
                          alt={p.name}
                          className="size-full object-cover"
                        />
                      ) : (
                        <div className="size-full grid place-items-center text-muted-foreground">
                          <Package className="size-4" />
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-0.5">
                      <div className="flex items-center gap-1.5">
                        <Link
                          href={`/admin/products/${p.id}`}
                          className="font-medium hover:underline"
                        >
                          {p.name}
                        </Link>
                        {p.isFeatured && (
                          <Star className="size-3.5 fill-amber-400 text-amber-500" />
                        )}
                      </div>
                      <span className="text-muted-foreground text-[11px] font-mono">
                        /{p.slug}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-xs" dir="ltr">{p.sku}</TableCell>
                  <TableCell className="text-sm">{p.categoryName || '—'}</TableCell>
                  <TableCell className="text-sm">{p.brandName || '—'}</TableCell>
                  <TableCell className="text-left">
                    <div className="flex flex-col items-start">
                      <span className="font-medium tabular-nums">
                        {formatPrice(p.price)}
                      </span>
                      {p.compareAtPrice && p.compareAtPrice > p.price && (
                        <span className="text-muted-foreground text-xs line-through tabular-nums">
                          {formatPrice(p.compareAtPrice)}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-left">
                    <span
                      className={
                        p.stockQuantity <= 5
                          ? 'text-rose-600 font-medium tabular-nums'
                          : 'tabular-nums'
                      }
                    >
                      {p.stockQuantity}
                    </span>
                  </TableCell>
                  <TableCell>
                    <ProductStatusBadge status={p.status} />
                  </TableCell>
                  <TableCell className="text-left text-xs text-muted-foreground">
                    {timeAgoAr(p.createdAt)}
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="size-8">
                          <MoreHorizontal className="size-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="start">
                        <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href={`/admin/products/${p.id}`}>
                            <Pencil className="size-4" />
                            تعديل
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => archive(p.id)}
                          className="text-rose-600 focus:text-rose-700"
                        >
                          <Archive className="size-4" />
                          أرشفة
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="border-t p-3">
            <TablePagination
              page={page}
              pageSize={PAGE_SIZE}
              total={total}
              onPage={(p) => {
                setPage(p)
                load(p, q, status)
              }}
            />
          </div>
        </Card>
      )}
    </div>
  )
}
