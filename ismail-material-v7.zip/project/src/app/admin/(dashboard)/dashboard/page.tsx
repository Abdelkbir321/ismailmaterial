'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  ShoppingCart,
  Package,
  AlertTriangle,
  Banknote,
  Clock,
  CheckCircle2,
  XCircle,
  Truck,
  ArrowLeft,
  Loader2,
} from 'lucide-react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
} from 'recharts'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { CardStat, EmptyState, Spinner } from '@/components/admin/page-header'
import { OrderStatusBadge } from '@/components/admin/status-badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface DashboardData {
  stats: {
    totalOrders: number
    todayOrders: number
    totalSales: number
    pendingOrders: number
    confirmedOrders: number
    deliveredOrders: number
    cancelledOrders: number
    totalProducts: number
    lowStockProducts: number
    currencyCode: string
  }
  activity: {
    recentOrders: Array<{
      id: string
      number: string
      customerFullName: string
      status: string
      total: number
      placedAt: string
    }>
    bestSellers: Array<{
      id: string
      name: string
      slug: string
      salesCount: number
      stockQuantity: number
      mainImage: string | null
      price: number
    }>
  }
}

const STATUS_BAR_COLOR: Record<string, string> = {
  NEW: '#f59e0b',
  CONTACTED: '#f97316',
  CONFIRMED: '#0d9488',
  PROCESSING: '#8b5cf6',
  SHIPPED: '#06b6d4',
  DELIVERED: '#10b981',
  CANCELLED: '#f43f5e',
  RETURNED: '#fb923c',
  UNREACHABLE: '#71717a',
}

const STATUS_LABEL: Record<string, string> = {
  NEW: 'جديدة',
  CONTACTED: 'تم التواصل',
  CONFIRMED: 'مؤكدة',
  PROCESSING: 'قيد التحضير',
  SHIPPED: 'تم الشحن',
  DELIVERED: 'تم التسليم',
  CANCELLED: 'ملغاة',
  RETURNED: 'مُعادة',
  UNREACHABLE: 'غير قابلة للوصول',
}

export default function DashboardPage() {
  const [data, setData] = React.useState<DashboardData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)

  React.useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const res = await fetch('/api/admin/dashboard', { credentials: 'include' })
        const json = await res.json()
        if (!active) return
        if (!res.ok || !json.ok) {
          setError(json.error || 'فشل التحميل')
        } else {
          setData(json)
        }
      } catch (e: any) {
        setError(e?.message || 'خطأ في الشبكة')
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => {
      active = false
    }
  }, [])

  if (loading) return <Spinner />
  if (error || !data) {
    return (
      <EmptyState
        title="تعذر تحميل لوحة التحكم"
        description={error || 'خطأ غير معروف'}
        icon={<AlertTriangle className="size-5" />}
      />
    )
  }

  const { stats, activity } = data
  const currency = { code: stats.currencyCode, symbol: stats.currencyCode === 'MAD' ? 'DH' : stats.currencyCode }
  const chartData = [
    { status: 'NEW', count: stats.pendingOrders },
    { status: 'CONFIRMED', count: stats.confirmedOrders },
    { status: 'DELIVERED', count: stats.deliveredOrders },
    { status: 'CANCELLED', count: stats.cancelledOrders },
  ].filter((d) => d.count > 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">الرئيسية</h1>
        <p className="text-muted-foreground text-sm">
          نظرة عامة على أداء متجرك.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <CardStat
          label="إجمالي الطلبات"
          value={stats.totalOrders}
          hint={`${stats.todayOrders} اليوم`}
          icon={<ShoppingCart className="size-5" />}
          accent="zinc"
        />
        <CardStat
          label="إجمالي المبيعات"
          value={formatPrice(stats.totalSales, currency)}
          hint="مؤكدة + مشحونة + مُسلمة"
          icon={<Banknote className="size-5" />}
          accent="emerald"
        />
        <CardStat
          label="إجمالي المنتجات"
          value={stats.totalProducts}
          hint={`${stats.lowStockProducts} بمخزون منخفض`}
          icon={<Package className="size-5" />}
          accent="teal"
        />
        <CardStat
          label="قيد الانتظار"
          value={stats.pendingOrders}
          hint="طلبات جديدة"
          icon={<Clock className="size-5" />}
          accent="amber"
        />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <CardStat
          label="مؤكدة"
          value={stats.confirmedOrders}
          icon={<CheckCircle2 className="size-5" />}
          accent="emerald"
        />
        <CardStat
          label="مُسلمة"
          value={stats.deliveredOrders}
          icon={<Truck className="size-5" />}
          accent="emerald"
        />
        <CardStat
          label="ملغاة"
          value={stats.cancelledOrders}
          icon={<XCircle className="size-5" />}
          accent="rose"
        />
        <CardStat
          label="مخزون منخفض"
          value={stats.lowStockProducts}
          hint="عدد المنتجات المعنية"
          icon={<AlertTriangle className="size-5" />}
          accent="amber"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">أحدث الطلبات</CardTitle>
            <CardDescription>آخر 8 طلبات مسجلة.</CardDescription>
          </CardHeader>
          <CardContent>
            {activity.recentOrders.length === 0 ? (
              <p className="text-muted-foreground text-sm py-8 text-center">
                لا توجد طلبات حتى الآن.
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الرقم</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead className="text-left">الإجمالي</TableHead>
                    <TableHead className="text-left">التاريخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activity.recentOrders.map((o) => (
                    <TableRow key={o.id}>
                      <TableCell className="font-mono text-xs">
                        <Link
                          href={`/admin/orders/${o.id}`}
                          className="hover:underline text-zinc-900"
                        >
                          {o.number}
                        </Link>
                      </TableCell>
                      <TableCell className="max-w-[160px] truncate">
                        {o.customerFullName}
                      </TableCell>
                      <TableCell>
                        <OrderStatusBadge status={o.status} />
                      </TableCell>
                      <TableCell className="text-left font-medium tabular-nums">
                        {formatPrice(o.total, currency)}
                      </TableCell>
                      <TableCell className="text-left text-xs text-muted-foreground">
                        {timeAgoAr(o.placedAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            <div className="mt-4 flex justify-start">
              <Link
                href="/admin/orders"
                className="text-xs text-zinc-900 hover:underline inline-flex items-center gap-1"
              >
                عرض كل الطلبات
                <ArrowLeft className="size-3" />
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">الأكثر مبيعاً</CardTitle>
            <CardDescription>أفضل 5 منتجات حسب المبيعات.</CardDescription>
          </CardHeader>
          <CardContent>
            {activity.bestSellers.length === 0 ? (
              <p className="text-muted-foreground text-sm py-8 text-center">
                لا توجد مبيعات بعد.
              </p>
            ) : (
              <ul className="space-y-3">
                {activity.bestSellers.map((p, idx) => (
                  <li key={p.id} className="flex items-center gap-3">
                    <span className="text-muted-foreground text-xs font-mono w-4">
                      {idx + 1}
                    </span>
                    <div className="bg-muted rounded-md size-10 shrink-0 overflow-hidden border">
                      {p.mainImage ? (
                        <img
                          src={p.mainImage}
                          alt={p.name}
                          className="size-full object-cover"
                        />
                      ) : (
                        <div className="size-full grid place-items-center text-muted-foreground">
                          <Package className="size-4" />
                        </div>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <Link
                        href={`/admin/products/${p.id}`}
                        className="text-sm font-medium truncate block hover:underline"
                        title={p.name}
                      >
                        {p.name}
                      </Link>
                      <p className="text-xs text-muted-foreground">
                        {p.salesCount} مبيعات · {p.stockQuantity} في المخزون
                      </p>
                    </div>
                    <span className="text-sm font-semibold tabular-nums">
                      {formatPrice(p.price, currency)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      {chartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">توزيع الطلبات حسب الحالة</CardTitle>
            <CardDescription>
              عدد الطلبات في كل مرحلة من مراحل المعالجة.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e4e4e7" />
                  <XAxis
                    dataKey="status"
                    tickFormatter={(s) => STATUS_LABEL[s] ?? s}
                    tick={{ fontSize: 11 }}
                    stroke="#71717a"
                  />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} stroke="#71717a" />
                  <Tooltip
                    cursor={{ fill: 'rgba(0,0,0,0.04)' }}
                    contentStyle={{
                      borderRadius: 8,
                      border: '1px solid #e4e4e7',
                      fontSize: 12,
                    }}
                    labelFormatter={(s) => STATUS_LABEL[s as string] ?? s}
                  />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                    {chartData.map((entry) => (
                      <Cell key={entry.status} fill={STATUS_BAR_COLOR[entry.status] ?? '#3f3f46'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
