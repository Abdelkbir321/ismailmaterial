'use client'

import * as React from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  UserCog,
  Plus,
  Loader2,
  Search,
  MoreHorizontal,
  Pencil,
  ShieldCheck,
  Trash2,
  Eye,
  EyeOff,
  Lock,
  ShieldX,
} from 'lucide-react'

import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { timeAgoAr } from '@/lib/format'
import { cn } from '@/lib/utils'
import {
  PermissionPicker,
  type PermissionMap,
  type PermissionSection,
} from '@/components/admin/permission-picker'

interface RoleOption {
  id: string
  slug: string
  name: string
  description?: string | null
}

interface AdminUserRow {
  id: string
  email: string
  fullName: string
  roleId: string
  role: { id: string; slug: string; name: string }
  status: 'ACTIVE' | 'DISABLED' | 'LOCKED'
  lastLoginAt: string | null
  lastLoginIp?: string | null
  createdAt: string
}

interface CurrentAdmin {
  id: string
  fullName: string
  email: string
  role: { slug: string; name: string; permissions: Record<string, string[]> }
}

function hasPerm(admin: CurrentAdmin | null, section: string, action: string): boolean {
  if (!admin) return false
  if (admin.role.slug === 'super-admin') return true
  const acts = admin.role.permissions?.[section]
  return Array.isArray(acts) && acts.includes(action)
}

const STATUS_BADGE: Record<string, string> = {
  ACTIVE: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  DISABLED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  LOCKED: 'bg-amber-50 text-amber-700 ring-amber-600/20',
}
const STATUS_LABEL: Record<string, string> = {
  ACTIVE: 'نشط',
  DISABLED: 'معطّل',
  LOCKED: 'مقفل',
}

const STATUS_OPTIONS = [
  { value: 'ACTIVE', label: 'نشط' },
  { value: 'DISABLED', label: 'معطّل' },
  { value: 'LOCKED', label: 'مقفل' },
]

function initials(name: string): string {
  return (name || '?')
    .split(' ')
    .map((s) => s[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()
}

function roleBadgeClass(slug: string): string {
  if (slug === 'super-admin') return 'bg-amber-100 text-amber-800 ring-amber-600/30'
  return 'bg-zinc-100 text-zinc-700 ring-zinc-600/20'
}

export default function AdminUsersPage() {
  const [list, setList] = React.useState<AdminUserRow[]>([])
  const [roles, setRoles] = React.useState<RoleOption[]>([])
  const [current, setCurrent] = React.useState<CurrentAdmin | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [sessionLoading, setSessionLoading] = React.useState(true)
  const [q, setQ] = React.useState('')

  // Dialogs
  const [createOpen, setCreateOpen] = React.useState(false)
  const [editTarget, setEditTarget] = React.useState<AdminUserRow | null>(null)
  const [permTarget, setPermTarget] = React.useState<AdminUserRow | null>(null)
  const [deleteTarget, setDeleteTarget] = React.useState<AdminUserRow | null>(null)

  // Permission dialog data
  const [permSections, setPermSections] = React.useState<PermissionSection[]>([])
  const [permValue, setPermValue] = React.useState<PermissionMap>({})
  const [permLoading, setPermLoading] = React.useState(false)
  const [permSaving, setPermSaving] = React.useState(false)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/admin-users', { credentials: 'include' })
      const json = await res.json()
      if (res.status === 403) {
        toast.error('ماعندكش الصلاحية لهذه العملية')
        return
      }
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل تحميل المسؤولين')
        return
      }
      setList(json.users as AdminUserRow[])
      setRoles(json.roles as RoleOption[])
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  async function loadSession() {
    setSessionLoading(true)
    try {
      const res = await fetch('/api/admin/auth/session', { credentials: 'include' })
      if (!res.ok) return
      const json = await res.json()
      if (json.ok) setCurrent(json.admin as CurrentAdmin)
    } catch {
      // ignore — UI will fall back to "no perms" view
    } finally {
      setSessionLoading(false)
    }
  }

  React.useEffect(() => {
    loadSession()
    load()
  }, [])

  // Open the permissions dialog — fetch /api/admin/roles (for sections) + /api/admin/admin-users/[id] (for current value)
  async function openPermissions(target: AdminUserRow) {
    setPermTarget(target)
    setPermLoading(true)
    setPermValue({})
    setPermSections([])
    try {
      const [rolesRes, userRes] = await Promise.all([
        fetch('/api/admin/roles', { credentials: 'include' }),
        fetch(`/api/admin/admin-users/${target.id}`, { credentials: 'include' }),
      ])
      if (rolesRes.status === 403 || userRes.status === 403) {
        toast.error('ماعندكش الصلاحية لهذه العملية')
        setPermTarget(null)
        return
      }
      const rJson = await rolesRes.json()
      const uJson = await userRes.json()
      if (!rJson.ok || !uJson.ok) {
        toast.error(rJson.error || uJson.error || 'فشل التحميل')
        setPermTarget(null)
        return
      }
      setPermSections(rJson.sections as PermissionSection[])
      setPermValue((uJson.user.permissions as PermissionMap) ?? {})
    } catch {
      toast.error('خطأ في الشبكة')
      setPermTarget(null)
    } finally {
      setPermLoading(false)
    }
  }

  async function savePermissions() {
    if (!permTarget) return
    setPermSaving(true)
    try {
      const res = await fetch(`/api/admin/admin-users/${permTarget.id}/permissions`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ permissions: permValue }),
        credentials: 'include',
      })
      const json = await res.json()
      if (res.status === 403) {
        toast.error('ماعندكش الصلاحية لهذه العملية')
        return
      }
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success('تم تحديث صلاحيات الدور')
      setPermTarget(null)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setPermSaving(false)
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return
    try {
      const res = await fetch(`/api/admin/admin-users/${deleteTarget.id}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      const json = await res.json()
      if (res.status === 403) {
        toast.error('ماعندكش الصلاحية لهذه العملية')
        return
      }
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحذف')
        return
      }
      toast.success('تم حذف المسؤول')
      setDeleteTarget(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  // Permission gate — if session loaded but no view permission, show ممنوع card.
  if (!sessionLoading && current && !hasPerm(current, 'admin_users', 'view')) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="المسؤولون والصلاحيات"
          description="إدارة حسابات المسؤولين وأدوارهم وصلاحياتهم."
          breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'المسؤولون' }]}
        />
        <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-rose-300 bg-rose-50/40 p-12 text-center">
          <div className="bg-rose-100 text-rose-600 rounded-full p-3">
            <ShieldX className="size-6" />
          </div>
          <div className="space-y-1">
            <p className="font-medium text-rose-700">ممنوع</p>
            <p className="text-muted-foreground text-sm">
              لا تملك صلاحية عرض هذه الصفحة. تواصل مع المسؤول المطلق.
            </p>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link href="/admin/dashboard">العودة للوحة الرئيسية</Link>
          </Button>
        </div>
      </div>
    )
  }

  const canCreate = hasPerm(current, 'admin_users', 'create')
  const canEdit = hasPerm(current, 'admin_users', 'edit')
  const canDelete = hasPerm(current, 'admin_users', 'delete')
  const canManagePerms = hasPerm(current, 'permissions', 'manage_settings')

  const filtered = list.filter((u) => {
    if (!q) return true
    const needle = q.toLowerCase()
    return (
      u.fullName.toLowerCase().includes(needle) ||
      u.email.toLowerCase().includes(needle)
    )
  })

  return (
    <div className="space-y-6">
      <PageHeader
        title="المسؤولون والصلاحيات"
        description="إدارة حسابات المسؤولين وأدوارهم وصلاحياتهم."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'المسؤولون' }]}
        actions={
          canCreate ? (
            <Button className="bg-zinc-900 hover:bg-zinc-800" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" />
              إضافة مسؤول
            </Button>
          ) : null
        }
      />

      <Card className="p-3">
        <div className="relative">
          <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
          <Input
            placeholder="ابحث بالاسم أو البريد…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pr-8"
          />
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="لا يوجد مسؤولون"
          description={q ? 'لا نتائج مطابقة للبحث.' : 'أضف أول مسؤول لتبدأ.'}
          icon={<UserCog className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[220px]">المسؤول</TableHead>
                  <TableHead>الدور</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>آخر دخول</TableHead>
                  <TableHead>أُنشئ</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((u) => {
                  const isSelf = current?.id === u.id
                  const isSuper = u.role.slug === 'super-admin'
                  return (
                    <TableRow key={u.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="size-9">
                            <AvatarFallback
                              className={cn(
                                'text-xs',
                                isSuper
                                  ? 'bg-amber-500 text-white'
                                  : 'bg-zinc-900 text-white',
                              )}
                            >
                              {initials(u.fullName)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-1.5">
                              <span className="font-medium">{u.fullName}</span>
                              {isSelf && (
                                <Badge className="bg-emerald-100 text-emerald-700 border-transparent text-[10px]">
                                  أنت
                                </Badge>
                              )}
                            </div>
                            <span
                              className="text-muted-foreground text-xs"
                              dir="ltr"
                            >
                              {u.email}
                            </span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span
                          className={cn(
                            'inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap',
                            roleBadgeClass(u.role.slug),
                          )}
                        >
                          {isSuper && <ShieldCheck className="size-3" />}
                          {u.role.name}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span
                          className={cn(
                            'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap',
                            STATUS_BADGE[u.status],
                          )}
                        >
                          {STATUS_LABEL[u.status]}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {u.lastLoginAt ? timeAgoAr(u.lastLoginAt) : '—'}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {timeAgoAr(u.createdAt)}
                      </TableCell>
                      <TableCell>
                        {(canEdit || canManagePerms || canDelete) ? (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="size-8">
                                <MoreHorizontal className="size-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="start">
                              <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              {canEdit && (
                                <DropdownMenuItem onClick={() => setEditTarget(u)}>
                                  <Pencil className="size-4" />
                                  تعديل
                                </DropdownMenuItem>
                              )}
                              {canManagePerms && (
                                <DropdownMenuItem onClick={() => openPermissions(u)}>
                                  <Lock className="size-4" />
                                  إدارة الصلاحيات
                                </DropdownMenuItem>
                              )}
                              {canDelete && (
                                <DropdownMenuItem
                                  onClick={() => setDeleteTarget(u)}
                                  className="text-rose-600 focus:text-rose-700"
                                  disabled={isSelf}
                                >
                                  <Trash2 className="size-4" />
                                  حذف
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Create dialog */}
      {createOpen && (
        <AdminUserForm
          mode="create"
          roles={roles}
          onClose={() => setCreateOpen(false)}
          onSaved={() => {
            setCreateOpen(false)
            load()
          }}
        />
      )}

      {/* Edit dialog */}
      {editTarget && (
        <AdminUserForm
          mode="edit"
          roles={roles}
          initial={editTarget}
          onClose={() => setEditTarget(null)}
          onSaved={() => {
            setEditTarget(null)
            load()
          }}
        />
      )}

      {/* Permissions dialog */}
      <Dialog open={!!permTarget} onOpenChange={(o) => !o && setPermTarget(null)}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>إدارة صلاحيات: {permTarget?.fullName}</DialogTitle>
            <DialogDescription>
              تُحفظ الصلاحيات على الدور «{permTarget?.role.name}» — كل المسؤولين الذين يحملون
              نفس الدور يشاركونها. لتخصيص صلاحيات مسؤول بعينه، أنشئ دورًا مخصصًا له.
            </DialogDescription>
          </DialogHeader>
          {permLoading ? (
            <Spinner />
          ) : (
            <PermissionPicker
              sections={permSections}
              value={permValue}
              onChange={setPermValue}
              disabled={permSaving}
            />
          )}
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setPermTarget(null)}
              disabled={permSaving}
            >
              إلغاء
            </Button>
            <Button
              type="button"
              className="bg-zinc-900 hover:bg-zinc-800"
              onClick={savePermissions}
              disabled={permSaving || permLoading}
            >
              {permSaving ? <Loader2 className="size-4 animate-spin" /> : null}
              حفظ الصلاحيات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف المسؤول «{deleteTarget?.fullName}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيُحذف حساب المسؤول نهائيًا مع جميع جلساته. لا يمكن التراجع عن هذا الإجراء.
              {deleteTarget?.role.slug === 'super-admin' && (
                <span className="block mt-2 text-amber-700">
                  تحذير: هذا مسؤول مطلق — تأكد من وجود مسؤول مطلق آخر نشط قبل الحذف.
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Admin User form (Create / Edit) — used inside a Dialog
// ============================================================

interface AdminUserFormProps {
  mode: 'create' | 'edit'
  roles: RoleOption[]
  initial?: AdminUserRow
  onClose: () => void
  onSaved: () => void
}

function AdminUserForm({ mode, roles, initial, onClose, onSaved }: AdminUserFormProps) {
  const [fullName, setFullName] = React.useState(initial?.fullName ?? '')
  const [email, setEmail] = React.useState(initial?.email ?? '')
  const [password, setPassword] = React.useState('')
  const [showPassword, setShowPassword] = React.useState(false)
  const [roleId, setRoleId] = React.useState(initial?.roleId ?? roles[0]?.id ?? '')
  const [status, setStatus] = React.useState<'ACTIVE' | 'DISABLED' | 'LOCKED'>(
    initial?.status ?? 'ACTIVE',
  )
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [saving, setSaving] = React.useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return
    setErrors({})
    if (mode === 'create' && password.length < 8) {
      setErrors({ password: 'كلمة المرور 8 أحرف على الأقل' })
      return
    }
    if (mode === 'edit' && password && password.length < 8) {
      setErrors({ password: 'كلمة المرور 8 أحرف على الأقل' })
      return
    }
    setSaving(true)
    try {
      const body: Record<string, unknown> = {
        fullName,
        email,
        roleId,
        status,
      }
      if (mode === 'create') {
        body.password = password
      } else if (password) {
        body.password = password
      }
      const url =
        mode === 'create'
          ? '/api/admin/admin-users'
          : `/api/admin/admin-users/${initial!.id}`
      const method = mode === 'create' ? 'POST' : 'PUT'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        credentials: 'include',
      })
      const json = await res.json()
      if (res.status === 403) {
        toast.error('ماعندكش الصلاحية لهذه العملية')
        return
      }
      if (!res.ok || !json.ok) {
        if (json.fieldErrors) {
          setErrors(json.fieldErrors as Record<string, string>)
        }
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success(mode === 'create' ? 'تم إنشاء المسؤول' : 'تم تحديث المسؤول')
      onSaved()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? 'إضافة مسؤول جديد' : `تعديل: ${initial?.fullName}`}
          </DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? 'أنشئ حساب مسؤول جديد وحدد دوره وحالته.'
              : 'عدّل بيانات المسؤول. اترك كلمة المرور فارغة إذا لم ترد تغييرها.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="au-full">الاسم الكامل</Label>
            <Input
              id="au-full"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
              minLength={2}
              maxLength={120}
            />
            {errors.fullName && (
              <p className="text-rose-600 text-xs">{errors.fullName}</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="au-email">البريد الإلكتروني</Label>
            <Input
              id="au-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              dir="ltr"
              className="text-left"
            />
            {errors.email && (
              <p className="text-rose-600 text-xs">{errors.email}</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="au-pass">كلمة المرور</Label>
            <div className="relative">
              <Input
                id="au-pass"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required={mode === 'create'}
                dir="ltr"
                className="text-left pl-9"
                placeholder={mode === 'edit' ? 'اتركها فارغة للإبقاء عليها' : '8 أحرف على الأقل'}
                minLength={mode === 'create' ? 8 : undefined}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute left-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label={showPassword ? 'إخفاء' : 'إظهار'}
              >
                {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
            {errors.password && (
              <p className="text-rose-600 text-xs">{errors.password}</p>
            )}
            {mode === 'create' && (
              <p className="text-muted-foreground text-[11px]">
                8 أحرف على الأقل. سيُحفظ الهاش فقط.
              </p>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="au-role">الدور</Label>
              <Select value={roleId} onValueChange={setRoleId}>
                <SelectTrigger id="au-role" className="w-full">
                  <SelectValue placeholder="اختر دورًا" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name}
                      {r.slug === 'super-admin' ? ' — مطلق' : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.roleId && (
                <p className="text-rose-600 text-xs">{errors.roleId}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="au-status">الحالة</Label>
              <Select value={status} onValueChange={(v: 'ACTIVE' | 'DISABLED' | 'LOCKED') => setStatus(v)}>
                <SelectTrigger id="au-status" className="w-full">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((s) => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={saving}>
              إلغاء
            </Button>
            <Button
              type="submit"
              className="bg-zinc-900 hover:bg-zinc-800"
              disabled={saving}
            >
              {saving ? <Loader2 className="size-4 animate-spin" /> : null}
              {mode === 'create' ? 'إنشاء' : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
