'use client'

import * as React from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  Users,
  Search,
  Mail,
  Phone,
} from 'lucide-react'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Customer {
  id: string
  fullName: string
  email: string | null
  phone: string | null
  status: string
  createdAt: string
  country: {
    name: string
    code: string
    currencySymbol: string
    currencyCode: string
  } | null
  orderCount: number
  totalSpent: number
  currencyCode: string
  currencySymbol: string
}

export default function CustomersPage() {
  const [items, setItems] = React.useState<Customer[]>([])
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load(q = '') {
    setLoading(true)
    try {
      const url = q
        ? `/api/admin/customers?q=${encodeURIComponent(q)}`
        : '/api/admin/customers'
      const res = await fetch(url, { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setItems(json.customers)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      load(searchInput)
    }, 350)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [searchInput])

  return (
    <div className="space-y-6">
      <PageHeader
        title="العملاء"
        description="قائمة العملاء وإحصائيات الطلبات."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'العملاء' }]}
      />

      <Card className="p-3">
        <div className="relative">
          <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
          <Input
            placeholder="ابحث بالاسم أو الهاتف أو البريد…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pr-8"
          />
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا يوجد عملاء"
          description="العملاء الذين يقدمون طلبات سيظهرون هنا."
          icon={<Users className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الاسم</TableHead>
                <TableHead>الهاتف</TableHead>
                <TableHead>البريد</TableHead>
                <TableHead>الدولة</TableHead>
                <TableHead className="text-left">الطلبات</TableHead>
                <TableHead className="text-left">إجمالي الإنفاق</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead className="text-left">أُنشئ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.fullName}</TableCell>
                  <TableCell>
                    {c.phone ? (
                      <a
                        href={`tel:${c.phone}`}
                        className="text-sm hover:underline inline-flex items-center gap-1"
                        dir="ltr"
                      >
                        <Phone className="size-3 text-muted-foreground" />
                        {c.phone}
                      </a>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {c.email ? (
                      <a
                        href={`mailto:${c.email}`}
                        className="text-sm hover:underline inline-flex items-center gap-1"
                        dir="ltr"
                      >
                        <Mail className="size-3 text-muted-foreground" />
                        {c.email}
                      </a>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-sm">
                    {c.country?.name || '—'}
                  </TableCell>
                  <TableCell className="text-left tabular-nums">
                    {c.orderCount}
                  </TableCell>
                  <TableCell className="text-left font-medium tabular-nums">
                    {formatPrice(c.totalSpent, {
                      code: c.currencyCode,
                      symbol: c.currencySymbol,
                    })}
                  </TableCell>
                  <TableCell>
                    {c.status === 'ACTIVE' ? (
                      <Badge className="bg-emerald-100 text-emerald-700">نشط</Badge>
                    ) : c.status === 'BLOCKED' ? (
                      <Badge className="bg-rose-100 text-rose-700">محظور</Badge>
                    ) : (
                      <span className="text-xs text-muted-foreground">{c.status}</span>
                    )}
                  </TableCell>
                  <TableCell className="text-left text-xs text-muted-foreground">
                    {timeAgoAr(c.createdAt)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  )
}
