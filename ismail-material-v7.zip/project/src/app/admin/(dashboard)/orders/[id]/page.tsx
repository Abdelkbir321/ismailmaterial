'use client'

import * as React from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowRight,
  Loader2,
  Save,
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  User,
  Clock,
  Package,
} from 'lucide-react'
import { toast } from 'sonner'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { OrderStatusBadge, PaymentStatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

const ORDER_STATUSES = [
  'NEW',
  'CONTACTED',
  'CONFIRMED',
  'PROCESSING',
  'SHIPPED',
  'DELIVERED',
  'CANCELLED',
  'RETURNED',
  'UNREACHABLE',
]
const STATUS_LABEL: Record<string, string> = {
  NEW: 'جديدة',
  CONTACTED: 'تم التواصل',
  CONFIRMED: 'مؤكدة',
  PROCESSING: 'قيد التحضير',
  SHIPPED: 'تم الشحن',
  DELIVERED: 'تم التسليم',
  CANCELLED: 'ملغاة',
  RETURNED: 'مُعادة',
  UNREACHABLE: 'غير قابلة للوصول',
}

interface OrderItem {
  id: string
  productName: string
  productSku: string
  productImage: string | null
  variantName: string | null
  unitPrice: number
  quantity: number
  lineTotal: number
}

interface StatusHistory {
  id: string
  status: string
  note: string | null
  createdAt: string
  adminUserId: string | null
}

interface OrderDetail {
  id: string
  number: string
  status: string
  paymentMethod: string
  paymentStatus: string
  customerFullName: string
  customerPhone: string
  customerEmail: string | null
  subtotal: number
  shippingCost: number
  discountTotal: number
  taxTotal: number
  total: number
  currencyCode: string
  placedAt: string
  shippingCity: string
  shippingAddress: string
  shippingPostalCode: string | null
  notes: string | null
  adminNotes: string | null
  country: { name: string; code: string; currencySymbol: string }
  items: OrderItem[]
  statusHistory: StatusHistory[]
}

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>()
  const router = useRouter()
  const [order, setOrder] = React.useState<OrderDetail | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [status, setStatus] = React.useState<string>('NEW')
  const [note, setNote] = React.useState('')
  const [adminNotes, setAdminNotes] = React.useState('')
  const [saving, setSaving] = React.useState<'status' | 'notes' | null>(null)

  React.useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const res = await fetch(`/api/admin/orders/${params.id}`, {
          credentials: 'include',
        })
        const json = await res.json()
        if (!active) return
        if (!res.ok || !json.ok) {
          setError(json.error || 'الطلب غير موجود')
          return
        }
        const o = json.order
        setOrder(o)
        setStatus(o.status)
        setAdminNotes(o.adminNotes || '')
      } catch (e: any) {
        setError(e?.message || 'خطأ في الشبكة')
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => {
      active = false
    }
  }, [params.id])

  async function patchStatus() {
    if (!order) return
    setSaving('status')
    try {
      const res = await fetch(`/api/admin/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, note, adminNotes }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم تحديث الحالة')
      setNote('')
      // reload
      const r2 = await fetch(`/api/admin/orders/${order.id}`, {
        credentials: 'include',
      })
      const j2 = await r2.json()
      if (r2.ok && j2.ok) {
        setOrder(j2.order)
        setStatus(j2.order.status)
        setAdminNotes(j2.order.adminNotes || '')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(null)
    }
  }

  async function saveNotes() {
    if (!order) return
    setSaving('notes')
    try {
      const res = await fetch(`/api/admin/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: order.status, adminNotes }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم حفظ الملاحظات')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(null)
    }
  }

  if (loading) return <Spinner />
  if (error || !order) {
    return (
      <EmptyState
        title="الطلب غير موجود"
        description={error || 'خطأ غير معروف'}
        icon={<Package className="size-5" />}
        action={
          <Button asChild variant="outline">
            <Link href="/admin/orders">العودة إلى الطلبات</Link>
          </Button>
        }
      />
    )
  }

  const currency = {
    code: order.currencyCode,
    symbol: order.country.currencySymbol,
  }
  const phoneDigits = order.customerPhone.replace(/[^\d+]/g, '')
  const waNumber = phoneDigits.replace(/^\+/, '')
  const waUrl = `https://wa.me/${waNumber}`

  return (
    <div className="space-y-6">
      <PageHeader
        title={order.number}
        description={`تم الطلب ${timeAgoAr(order.placedAt)}`}
        breadcrumb={[
          { label: 'الإدارة', href: '/admin/dashboard' },
          { label: 'الطلبات', href: '/admin/orders' },
          { label: order.number },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => router.push('/admin/orders')}>
            <ArrowRight className="size-4" />
            رجوع
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-base">عناصر الطلب</CardTitle>
              <OrderStatusBadge status={order.status} />
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-14"></TableHead>
                    <TableHead>المنتج</TableHead>
                    <TableHead>الرمز</TableHead>
                    <TableHead className="text-left">الكمية</TableHead>
                    <TableHead className="text-left">س. الوحدة</TableHead>
                    <TableHead className="text-left">الإجمالي</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {order.items.map((it) => (
                    <TableRow key={it.id}>
                      <TableCell>
                        <div className="bg-muted rounded-md size-10 overflow-hidden border">
                          {it.productImage ? (
                            <img
                              src={it.productImage}
                              alt={it.productName}
                              className="size-full object-cover"
                            />
                          ) : (
                            <div className="size-full grid place-items-center text-muted-foreground">
                              <Package className="size-4" />
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{it.productName}</div>
                        {it.variantName && (
                          <div className="text-xs text-muted-foreground">
                            {it.variantName}
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs" dir="ltr">
                        {it.productSku}
                      </TableCell>
                      <TableCell className="text-left tabular-nums">
                        {it.quantity}
                      </TableCell>
                      <TableCell className="text-left tabular-nums">
                        {formatPrice(it.unitPrice, currency)}
                      </TableCell>
                      <TableCell className="text-left font-medium tabular-nums">
                        {formatPrice(it.lineTotal, currency)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">ملخص الفاتورة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">المجموع الفرعي</span>
                <span className="tabular-nums">
                  {formatPrice(order.subtotal, currency)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">الشحن</span>
                <span className="tabular-nums">
                  {formatPrice(order.shippingCost, currency)}
                </span>
              </div>
              {Number(order.discountTotal) > 0 && (
                <div className="flex justify-between text-sm text-emerald-700">
                  <span>الخصم</span>
                  <span className="tabular-nums">
                    -{formatPrice(order.discountTotal, currency)}
                  </span>
                </div>
              )}
              {Number(order.taxTotal) > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">الضرائب</span>
                  <span className="tabular-nums">
                    {formatPrice(order.taxTotal, currency)}
                  </span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>الإجمالي</span>
                <span className="tabular-nums">
                  {formatPrice(order.total, currency)}
                </span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-muted-foreground text-sm">الدفع</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{order.paymentMethod}</span>
                  <PaymentStatusBadge status={order.paymentStatus} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="size-4" /> سجل الحالات
              </CardTitle>
            </CardHeader>
            <CardContent>
              {order.statusHistory.length === 0 ? (
                <p className="text-muted-foreground text-sm">
                  لا يوجد سجل مسجل.
                </p>
              ) : (
                <ol className="relative border-r border-muted mr-3 space-y-4">
                  {order.statusHistory.map((h) => (
                    <li key={h.id} className="pr-4 relative">
                      <span className="absolute -right-[7px] top-1.5 bg-zinc-900 size-3 rounded-full ring-2 ring-background" />
                      <div className="flex items-center gap-2 flex-wrap">
                        <OrderStatusBadge status={h.status} />
                        <span className="text-muted-foreground text-xs">
                          {timeAgoAr(h.createdAt)}
                        </span>
                      </div>
                      {h.note && (
                        <p className="text-sm text-zinc-700 mt-1">{h.note}</p>
                      )}
                    </li>
                  ))}
                </ol>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <User className="size-4" /> العميل
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <p className="text-muted-foreground text-xs">الاسم</p>
                <p className="font-medium">{order.customerFullName}</p>
              </div>
              <div className="flex items-start gap-2">
                <Phone className="size-4 text-muted-foreground mt-0.5" />
                <a
                  href={`tel:${order.customerPhone}`}
                  className="font-medium hover:underline"
                  dir="ltr"
                >
                  {order.customerPhone}
                </a>
              </div>
              {order.customerEmail && (
                <div className="flex items-start gap-2">
                  <Mail className="size-4 text-muted-foreground mt-0.5" />
                  <a
                    href={`mailto:${order.customerEmail}`}
                    className="text-sm hover:underline break-all"
                    dir="ltr"
                  >
                    {order.customerEmail}
                  </a>
                </div>
              )}
              <Separator />
              <div className="space-y-1">
                <p className="text-muted-foreground text-xs flex items-center gap-1.5">
                  <MapPin className="size-3.5" /> عنوان الشحن
                </p>
                <div className="text-sm">
                  <p>{order.shippingAddress}</p>
                  <p>
                    {order.shippingCity}
                    {order.shippingPostalCode ? `، ${order.shippingPostalCode}` : ''}
                  </p>
                  <p className="text-muted-foreground">{order.country.name}</p>
                </div>
                {order.notes && (
                  <div className="mt-2 rounded-md bg-muted p-2 text-xs">
                    <p className="font-medium text-muted-foreground mb-1">
                      ملاحظة العميل
                    </p>
                    <p>{order.notes}</p>
                  </div>
                )}
              </div>
              <Button asChild className="w-full bg-emerald-600 hover:bg-emerald-700">
                <a href={waUrl} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="size-4" />
                  فتح واتساب
                </a>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">تغيير الحالة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="status">الحالة</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger id="status" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ORDER_STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {STATUS_LABEL[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="note">ملاحظة (اختياري)</Label>
                <Textarea
                  id="note"
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="تُضاف إلى السجل…"
                />
              </div>
              <Button
                onClick={patchStatus}
                disabled={saving !== null}
                className="w-full bg-zinc-900 hover:bg-zinc-800"
              >
                {saving === 'status' ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Save className="size-4" />
                )}
                تحديث
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">ملاحظات داخلية</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Textarea
                rows={4}
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                placeholder="ملاحظات يراها الفريق فقط."
              />
              <Button
                variant="outline"
                onClick={saveNotes}
                disabled={saving !== null}
                className="w-full"
              >
                {saving === 'notes' ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Save className="size-4" />
                )}
                حفظ الملاحظات
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
