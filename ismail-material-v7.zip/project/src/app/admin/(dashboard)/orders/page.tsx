'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  Search,
  ShoppingCart,
  MoreHorizontal,
} from 'lucide-react'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { OrderStatusBadge, PaymentStatusBadge } from '@/components/admin/status-badge'
import { TablePagination } from '@/components/admin/table-pagination'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { toast } from 'sonner'

interface OrderItem {
  id: string
  number: string
  customerFullName: string
  customerPhone: string
  status: string
  paymentMethod: string
  paymentStatus: string
  total: number
  currencyCode: string
  currencySymbol: string
  itemCount: number
  placedAt: string
  countryName: string
}

const PAGE_SIZE = 20
const STATUSES = [
  { value: 'all', label: 'الكل' },
  { value: 'NEW', label: 'جديدة' },
  { value: 'CONTACTED', label: 'تم التواصل' },
  { value: 'CONFIRMED', label: 'مؤكدة' },
  { value: 'PROCESSING', label: 'قيد التحضير' },
  { value: 'SHIPPED', label: 'تم الشحن' },
  { value: 'DELIVERED', label: 'تم التسليم' },
  { value: 'CANCELLED', label: 'ملغاة' },
  { value: 'UNREACHABLE', label: 'غير قابلة للوصول' },
]

export default function AdminOrdersPage() {
  const [items, setItems] = React.useState<OrderItem[]>([])
  const [total, setTotal] = React.useState(0)
  const [page, setPage] = React.useState(1)
  const [q, setQ] = React.useState('')
  const [status, setStatus] = React.useState('all')
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load(p = page, query = q, st = status) {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(p),
        pageSize: String(PAGE_SIZE),
      })
      if (query) params.set('q', query)
      if (st && st !== 'all') params.set('status', st)
      const res = await fetch(`/api/admin/orders?${params.toString()}`, {
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'خطأ')
        return
      }
      setItems(json.items)
      setTotal(json.total)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load(1, '', 'all')
  }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      if (searchInput !== q) {
        setQ(searchInput)
        setPage(1)
        load(1, searchInput, status)
      }
    }, 350)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [searchInput])

  function onStatusChange(s: string) {
    setStatus(s)
    setPage(1)
    load(1, q, s)
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="الطلبات"
        description="قائمة ومتابعة طلبات الزبائن."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الطلبات' }]}
      />

      <Card className="p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
            <Input
              placeholder="رقم الطلب، الاسم، الهاتف…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-8"
            />
          </div>
          <Select value={status} onValueChange={onStatusChange}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="كل الحالات" />
            </SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد طلبات"
          description="ستظهر هنا الطلبات التي يقدمها الزبائن."
          icon={<ShoppingCart className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الرقم</TableHead>
                <TableHead>العميل</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>الدفع</TableHead>
                <TableHead className="text-left">العناصر</TableHead>
                <TableHead className="text-left">الإجمالي</TableHead>
                <TableHead>الدولة</TableHead>
                <TableHead className="text-left">التاريخ</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((o) => (
                <TableRow key={o.id} className="cursor-pointer">
                  <TableCell className="font-mono text-xs" dir="ltr">
                    <Link
                      href={`/admin/orders/${o.id}`}
                      className="hover:underline text-zinc-900"
                    >
                      {o.number}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium">{o.customerFullName}</span>
                      <span className="text-muted-foreground text-xs" dir="ltr">
                        {o.customerPhone}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <OrderStatusBadge status={o.status} />
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-0.5">
                      <span className="text-xs">{o.paymentMethod}</span>
                      <PaymentStatusBadge status={o.paymentStatus} />
                    </div>
                  </TableCell>
                  <TableCell className="text-left tabular-nums">
                    {o.itemCount}
                  </TableCell>
                  <TableCell className="text-left font-medium tabular-nums">
                    {formatPrice(o.total, {
                      code: o.currencyCode,
                      symbol: o.currencySymbol,
                    })}
                  </TableCell>
                  <TableCell className="text-sm">{o.countryName}</TableCell>
                  <TableCell className="text-left text-xs text-muted-foreground">
                    {timeAgoAr(o.placedAt)}
                  </TableCell>
                  <TableCell>
                    <Button asChild variant="ghost" size="icon" className="size-8">
                      <Link href={`/admin/orders/${o.id}`}>
                        <MoreHorizontal className="size-4" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="border-t p-3">
            <TablePagination
              page={page}
              pageSize={PAGE_SIZE}
              total={total}
              onPage={(p) => {
                setPage(p)
                load(p, q, status)
              }}
            />
          </div>
        </Card>
      )}
    </div>
  )
}
